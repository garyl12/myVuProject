<template>
  <div style="height:100%">
    <div class="left">
      <grid
        :columns="calendarColumns"
        :data="calendar.data"
        :need-index="true"
        :need-searcher="true"
        :repeat-select="true"
        :condition="calendar.searchBy"
        @search="searchCalendar"   
        @select="selectCalendar"
        ref="calendarGrid">
        </grid>
    </div>
    <resizer axis="x" />
    <div class="right">
      <tree-grid
        :columns="translationColumns"
        :data="translation.data"
        :data-loader="dataLoader"
        :child-attribute="translation.childAttribute"
        :repeat-select="false"
        :needSearcher="false"
        :plain="false"
        :need-searcher="false"
        ref="translationGrid"
        >
      </tree-grid>
    </div>
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import Resizer from "@/components/common/Resizer";
import Alert from "@/components/common/Alert";
import TreeGrid from "@/components/common/TreeGrid";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import { mapGetters } from "vuex";
import { RESPONSE_CODE, DATA_TYPES, EDITOR_STATUS, FILE_TYPES } from "@/consts";
import mixin from "../mixin";
export default {
  name: "CalendarManagement",
  components: { Grid, Resizer, TreeGrid },
  mixins: [mixin],
  data() {
    return {
      calendar: {
        data: [],
        pageNumber: 0,
        pageCount: 0,
        selectedItem: null,
        selectedIndex: -1,
        searchBy: null
      },
      translation: {
        childAttribute: "children",
        data: [{attributes:{Name:{value:'2222'},ID:{value:'2222'}}}],
        plain: false
      },
      alert: {
        visible: false,
        title: "warning",
        message: "",
        logs: [],
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      currentNav: "getCurrentNav"
    }),
    view() {
      return this.views["CALENDAR_MANAGEMENT"] || null;
    },
    calendarColumns() {
      return [
        {
          attributeName: "Name",
          displayName: "Name",
          dataType: "STRING"
        },
        {
          attributeName: "ID",
          displayName: "ID",
          dataType: "STRING"
        }
      ];
      let columns = [];
      if (this.view) {
        (columns = this.view[0]),
          attributesInMainGrid.split(";").map(attr => {
            return {
              attributeName: attr,
              displayName: attr,
              dataType: "STRING"
            };
          });
      }
      return columns;
    },
    translationColumns() {
      return [
        // {
        //   attributeName: "Name",
        //   displayName: "Name",
        //   dataType: "STRING"
        // },
        {
          attributeName: "ID",
          displayName: "ID",
          dataType: "STRING"
        }
      ];
    },
    baseConditions() {
      return [{}];
    }
  },
  mounted() {
    this.loadCalendar();
  },
  methods: {
    loadCalendar() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.calendar.data = cacheData.calendar;
        this.translation = cacheData.translation;
      } else {
        this.requestCalendarData();
      }
    },
    requestCalendarData(searchBy, searchFields) {
      let requestParam = productApiHelper.getRequestData(
        null,
        this.baseConditions,
        searchBy || null,
        null,
        searchFields || null,
        DATA_TYPES.CALENDER,
        1
      );
      this.$api
        .request(endpoints.getProductData, requestParam)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.calendar.data = data.records;
            if (data.records.length) this.$refs.calendarGrid.selectDefault();
          } else {
            this.alert.visible = true;
            this.alert.message = "";
            this.alert.title = code;
            this.alert.logs = messages;
          }
        });
    },
    searchCalendar({ searchBy }) {
      this.requestCalendarData(searchBy);
    },
    selectCalendar({ currentItem }) {},
    dataLoader() {},
    getCacheData() {
      return {
        calendar: this.calendar,
        translation: this.translation
      };
    }
  }
};
</script>

<style scoped>
.left {
  height: 100%;
  width: 50%;
  float: left;
}
.right {
  height: 100%;
  width: calc(50% - 8px);
  width: -ms-calc(50% -8px);
  width: -moz-calc(50% - 8px);
  width: -webkit-calc(50% - 8px);
  float: left;
}
</style>