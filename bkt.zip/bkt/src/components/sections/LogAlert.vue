<template>
  <el-dialog
    width="30%"
    class="dark"
    :title="$t_(title)"
    :visible="visible"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    :append-to-body="true"
    >
    <div v-if="!isStringArray">
      <a href="dist/popout.html" target="_blank" style="display:none" ref="popper"></a>
      <div v-for="index in Math.min(logs.length, 5)" :key="index" class="log">
        <i class="iconfont icon-log-ex exception" v-if="logs[index-1].type===RESPONSE_CODE.EXCEPTION" :title="RESPONSE_CODE.EXCEPTION"></i>
        <i class="iconfont icon-log-error error" v-else-if="logs[index-1].type===RESPONSE_CODE.ERROR" :title="RESPONSE_CODE.ERROR"></i>
        <i class="iconfont icon-log-warning warning" v-else-if="logs[index-1].type===RESPONSE_CODE.WARNING" :title="RESPONSE_CODE.WARNING"></i>
        <i class="iconfont icon-log-info" v-else :title="RESPONSE_CODE.INFO"></i>
        <span :title="logs[index-1].msg">{{logs[index-1].msg}}</span>
      </div>
      <div class="log-footer">
        <div class="group">
          <span>{{$t_('total_logs')}}</span>
          <span class="link" @click="viewAll">{{logs.length}}</span>
        </div>
        <div class="group">
          <i class="iconfont icon-log-ex exception" :title="$t_('exception_logs')"></i>
          <span class="link" @click="viewEx">{{exceptionLogs.length}}</span>
        </div>
        <div class="group">
          <i class="iconfont icon-log-error error" :title="$t_('error_logs')"></i>
          <span class="link" @click="viewError">{{errorLogs.length}}</span>
        </div>
        <div class="group">
          <i class="iconfont icon-log-warning warning" :title="$t_('warning_logs')"></i>
          <span class="link" @click="viewWarning">{{warningLogs.length}}</span>
        </div>
        <div class="group">
          <i class="iconfont icon-log-info" :title="$t_('information_logs')"></i>
          <span class="link" @click="viewInfo">{{infoLogs.length}}</span>
        </div>
      </div>
    </div>
    <div v-else>
      <div v-for="(log,index) in logs" :key="index">
        <span>{{log}}</span>
      </div>
    </div>
    <span slot="footer">
      <el-button :title="$t_('OK')" @click="visible=false">{{$t_('OK')}}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import {
  RESPONSE_CODE,
  POPOUT_TAB_DATA,
  TAB_TYPES,
  POPOUT_TAB_TYPE
} from "@/consts";

export default {
  name: "LogAlert",
  props: {
    logs: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      visible: false
    };
  },
  computed: {
    RESPONSE_CODE() {
      return RESPONSE_CODE;
    },
    title() {
      return this.isStringArray ? RESPONSE_CODE.EXCEPTION : "operation_logs";
    },
    isStringArray() {
      let isStringArray = false;
      if (this.logs.length) {
        if (typeof this.logs[0] === "string") {
          isStringArray = true;
        }
      }
      return isStringArray;
    },
    exceptionLogs() {
      let logs = [];
      this.logs.forEach(l => {
        if (l.type === RESPONSE_CODE.EXCEPTION) {
          logs.push(l);
        }
      });
      return logs;
    },
    errorLogs() {
      let logs = [];
      this.logs.forEach(l => {
        if (l.type === RESPONSE_CODE.ERROR) {
          logs.push(l);
        }
      });
      return logs;
    },
    warningLogs() {
      let logs = [];
      this.logs.forEach(l => {
        if (l.type === RESPONSE_CODE.WARNING) {
          logs.push(l);
        }
      });
      return logs;
    },
    infoLogs() {
      let logs = [];
      this.logs.forEach(l => {
        if (l.type === RESPONSE_CODE.INFO) {
          logs.push(l);
        }
      });
      return logs;
    }
  },
  watch: {
    logs() {
      if (this.logs.length) this.visible = true;
    }
  },
  mounted() {
    if (this.logs.length) this.visible = true;
  },
  methods: {
    viewAll() {
      this.viewLogs();
    },
    viewEx() {
      this.viewLogs(RESPONSE_CODE.EXCEPTION);
    },
    viewError() {
      this.viewLogs(RESPONSE_CODE.ERROR);
    },
    viewWarning() {
      this.viewLogs(RESPONSE_CODE.WARNING);
    },
    viewInfo() {
      this.viewLogs(RESPONSE_CODE.INFO);
    },
    viewLogs(type) {
      let logs = [];
      switch (type) {
        case RESPONSE_CODE.EXCEPTION:
          logs = this.exceptionLogs;
          break;
        case RESPONSE_CODE.ERROR:
          logs = this.errorLogs;
          break;
        case RESPONSE_CODE.WARNING:
          logs = this.warningLogs;
          break;
        case RESPONSE_CODE.INFO:
          logs = this.infoLogs;
          break;
        default:
          logs = this.logs;
          break;
      }
      if (!logs.length) return;
      localStorage.setItem(POPOUT_TAB_TYPE, TAB_TYPES.LOG);
      localStorage.setItem(POPOUT_TAB_DATA, JSON.stringify(logs));
      this.$refs.popper.click();
    }
  }
};
</script>

<style scoped>
.link {
  text-decoration: underline;
  cursor: pointer;
  color: #abb6d5;
}
.log {
  line-height: 20px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.log-footer {
  margin-top: 20px;
  margin-bottom: -30px;
}
.log-footer .group {
  display: inline-block;
  padding: 0 5px;
}
.exception {
  color: darkred;
}
.error {
  color: red;
}
.warning {
  color: yellow;
}
</style>