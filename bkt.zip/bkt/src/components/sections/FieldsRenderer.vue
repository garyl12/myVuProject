<template>
  <div class="clearfix" v-if="isDataBean">
    <div
      v-for="(field,index) in fields"
      :key="index"
      v-if="field.visible&&field.dataType!==FIELD_TYPES.TABLE"
      class="field-default"
      :style="columnWidthStyle"
      >
      <display-field
        v-if="field.output||(adding&&!field.editableInNew)||(!adding&&!field.editableInEdit)"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]|formatDisplay(field.displayFormat)"
        />
      <tree-selector-field
        v-else-if="field.dataType===FIELD_TYPES.STRING&&field.reference&&field.type===REFERENCE_FIELD_TYPE.TREE"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :required="field.occurs.minOccurs>0"
        :tree-loader="field.options.treeLoader"
        :search-resolver="field.options.searchResolver"
        :value-resolver="field.options.valueResolver"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <reference-selector-field
        v-else-if="field.name===REFERENCE_FIELDS.MODEL||field.reference"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :required="field.occurs.minOccurs>0"
        :allow-multi="field.list"
        :columns="field.options.columns"
        :references-resolver="field.options.resolver"
        :ref-attribute="field.options.refAttribute"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field
        v-else-if="field.dataType===FIELD_TYPES.BOOLEAN"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :options="[]"
        :for-boolean="true"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field 
        v-else-if="field.dataType===FIELD_TYPES.STRING&&!field.reference&&field.options"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :options="field.options"
        :for-boolean="field.dataType===FIELD_TYPES.BOOLEAN"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field 
        v-else-if="field.dataType===FIELD_TYPES.STRING&&field.enumRef"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :options="dictionary | lookup(field.enumRef)"
        :for-boolean="field.dataType===FIELD_TYPES.BOOLEAN"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <text-field
        v-else-if="field.dataType===FIELD_TYPES.STRING"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :required="field.occurs.minOccurs>0"
        :allow-multi="field.list"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <date-field
        v-else-if="field.dataType===FIELD_TYPES.DATE"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <number-field
        v-else-if="field.dataType===FIELD_TYPES.DOUBLE||field.dataType===FIELD_TYPES.INTEGER"
        :field-val="entry[field.name]"
        v-model="entry[field.name]"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :format="field.displayFormat"
        :allow-multi="field.list"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
    </div>
  </div>
  <div class="clearfix" v-else>
    <div
      v-for="(field,index) in fields"
      :key="index" 
      v-if="field.visible&&field.dataType!==FIELD_TYPES.TABLE"
      class="field-default"
      :style="columnWidthStyle"
      >
      <display-field
        v-if="field.output||(adding&&!field.editableInNew)||(!adding&&!field.editableInEdit)"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value|formatDisplay(field.displayFormat)"
        />
      <tree-selector-field
        v-else-if="field.dataType===FIELD_TYPES.STRING&&field.reference&&field.type===REFERENCE_FIELD_TYPE.TREE"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :required="field.occurs.minOccurs>0"
        :tree-loader="field.options.treeLoader"
        :search-resolver="field.options.searchResolver"
        :value-resolver="field.options.valueResolver"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <reference-selector-field
        v-else-if="field.name===REFERENCE_FIELDS.MODEL||field.reference"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :required="field.occurs.minOccurs>0"
        :allow-multi="field.list"
        :columns="field.options.columns"
        :references-resolver="field.options.resolver"
        :ref-attribute="field.options.refAttribute"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field 
        v-else-if="field.dataType===FIELD_TYPES.BOOLEAN"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :options="[]"
        :for-boolean="true"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field 
        v-else-if="field.dataType===FIELD_TYPES.STRING&&!field.reference&&field.options"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :options="field.options"
        :for-boolean="true"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <dropdownlist-field 
        v-else-if="field.dataType===FIELD_TYPES.STRING&&field.enumRef"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :options="dictionary | lookup(field.enumRef)"
        :for-boolean="field.dataType===FIELD_TYPES.BOOLEAN"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <text-field
        v-else-if="field.dataType===FIELD_TYPES.STRING"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :required="field.occurs.minOccurs>0"
        :allow-multi="field.list"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <date-field
        v-else-if="field.dataType===FIELD_TYPES.DATE"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
      <number-field
        v-else-if="field.dataType===FIELD_TYPES.DOUBLE||field.dataType===FIELD_TYPES.INTEGER"
        :field-val="entry.attributes[field.name].value"
        v-model="entry.attributes[field.name].value"
        :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
        :format="field.displayFormat"
        :allow-multi="field.list"
        :required="field.occurs.minOccurs>0"
        :driveExt="field.driveExt"
        :validate-ext="field.validateExt"
        @validate="updateValidationMap"
        />
    </div>
  </div>
</template>

<script>
import {
  FIELD_TYPES,
  DATA_TYPES,
  REFERENCE_FIELDS,
  REFERENCE_FIELD_TYPE,
  RESPONSE_CODE
} from "@/consts";
import endpoints from "@/api/endpoints";
import { clone } from "@/utils";
import { mapGetters } from "vuex";
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import NumberField from "@/components/fields/NumberUIField";
import DateField from "@/components/fields/DateUIField";
import DisplayField from "@/components/fields/DisplayField";
import ReferenceSelectorField from "@/components/fields/ReferenceSelectorUIField";
import TreeSelectorField from "@/components/fields/TreeSelectorUIField";
import productApiHelper from "@/utils/productApiHelper";

export default {
  name: "FieldsRenderer",
  components: {
    TextField,
    DropdownlistField,
    NumberField,
    DateField,
    DisplayField,
    ReferenceSelectorField,
    TreeSelectorField
  },
  props: {
    fields: {
      type: Array,
      required: true
    },
    entry: {
      type: Object,
      required: true
    },
    adding: Boolean,
    isDataBean: Boolean,
    columnCount: {
      type: Number,
      default: 4
    }
  },
  computed: {
    ...mapGetters({
      dictionary: "getDicts"
    }),
    REFERENCE_FIELDS() {
      return REFERENCE_FIELDS;
    },
    FIELD_TYPES() {
      return FIELD_TYPES;
    },
    REFERENCE_FIELD_TYPE() {
      return REFERENCE_FIELD_TYPE;
    },
    columnWidthStyle() {
      let width = 100 / this.columnCount + "%";
      return {
        width
      };
    }
  },
  watch: {
    fields() {
      this.validationMap = {};
    }
  },
  data() {
    return {
      validationMap: {}
    };
  },
  methods: {
    updateValidationMap({ fieldName, isValid }) {
      this.validationMap[fieldName] = isValid;
    },
    reset() {
      this.validationMap = {};
      this.$children.forEach(vm => {
        vm.isValid = true;
      });
    },
    validate() {
      this.$children.forEach(vm => {
        if (vm.validate) {
          vm.validate();
        }
      });
      let result = {
        isValid: true,
        invalidFields: []
      };
      for (let field in this.validationMap) {
        if (!this.validationMap[field]) {
          result.invalidFields.push(field);
        }
      }
      result.isValid = result.invalidFields.length === 0;
      return result;
    }
  }
};

export const generateReferenceSelectorOption4Model = (api, templateName) => {
  let option = {
    columns: [
      {
        attributeName: "name",
        displayName: "name",
        width: 150
      }
    ],
    refAttribute: "name"
  };
  let models = [];
  option.resolver = searchingCondition => {
    if (models.length) {
      return new Promise(resolve => {
        let tempModels = [];
        models.forEach(model => {
          if (searchingCondition.name) {
            if (model.name.indexOf(searchingCondition.name) !== -1) {
              tempModels.push(model);
            }
          } else {
            tempModels.push(model);
          }
        });
        let pageCount = Math.ceil(tempModels / 10);
        resolve({
          data: tempModels,
          pageCount
        });
      });
    } else {
      return api
        .request(endpoints.getPricingModels, {
          appliance: templateName
        })
        .then(
          ({ data }) => {
            models = data.map(d => {
              return {
                name: d
              };
            });
            let tempModels = [];
            models.forEach(model => {
              if (searchingCondition.name) {
                if (model.name.indexOf(searchingCondition.name) !== -1) {
                  tempModels.push(model);
                }
              } else {
                tempModels.push(model);
              }
            });
            let pageCount = Math.ceil(tempModels / 10);
            return Promise.resolve({
              data: tempModels,
              pageCount
            });
          },
          _ => {
            return Promise.resolve({
              data: [],
              pageCount: 0
            });
          }
        );
    }
  };
  return option;
};
export const generateReferenceSelectorOption = (field, api) => {
  let option = {
      columns: [],
      refAttribute: ""
    },
    dataType = "",
    searchObjects = JSON.parse(field.refOptions),
    baseCondition = null,
    defaultConditions = [];
  dataType = field.refTypes
    ? field.refTypes[0].split(".")[0].toUpperCase()
    : DATA_TYPES.MARKETDATA;
  if (searchObjects) {
    searchObjects.cols.forEach((col, index) => {
      option.columns.push({
        attributeName: col,
        displayName: col,
        width: 100
      });
      if (!index) {
        option.refAttribute = col;
      }
    });
    searchObjects.baseConditions.forEach(c => {
      if (c.searchType === "Customized") {
        defaultConditions.push(c);
      } else {
        baseCondition = c;
      }
    });
  }
  option.resolver = (pageIndex, searchingCondition) => {
    let searchBy = [];
    for (let key in searchingCondition) {
      let searchObj = {
        value: searchingCondition[key],
        valueType: FIELD_TYPES.STRING,
        key
      };
      searchBy.push(searchObj);
    }
    let requestParameters = productApiHelper.getRequestData(
      baseCondition,
      defaultConditions,
      searchBy,
      null,
      null,
      dataType,
      pageIndex,
      10
    );
    return api.request(endpoints.getProductData, requestParameters).then(
      ({ code, data }) => {
        if (code === RESPONSE_CODE.INFO) {
          let pageCount = Math.ceil(data.recordCount / 10);
          let refs = data.records.map(res => {
            let data = {};
            for (let attr in res.attributes) {
              data[attr] = res.attributes[attr].value;
            }
            return data;
          });
          return Promise.resolve({
            data: refs,
            pageCount
          });
        }
      },
      _ => {
        return Promise.resolve({
          data: [],
          pageCount: 0
        });
      }
    );
  };
  return option;
};
export const generateTreeSelectorOption = (field, api, rootId = 0) => {
  let option = {};
  field.type = REFERENCE_FIELD_TYPE.TREE;
  option.treeLoader = parent => {
    let parentId = parent ? parent.id : rootId,
      baseCondition = {
        attributeName: "Parent ID",
        searchValues: [parentId]
      },
      requestParameters = productApiHelper.getRequestData(
        null,
        [baseCondition],
        null,
        null,
        null,
        DATA_TYPES.PORTFOLIO,
        1
      );
    requestParameters.queryRequests.startIndex = 0;
    requestParameters.queryRequests.pageSize = null;
    return api.request(endpoints.getProductData, requestParameters).then(
      ({ data }) => {
        return Promise.resolve(data.records);
      },
      _ => {
        return Promise.resolve([]);
      }
    );
  };
  option.searchResolver = searchValue => {
    let searchableAttributes = ["ID", "Name"],
      fields = [];
    if (searchValue) {
      searchableAttributes.forEach(attribute => {
        let field = {
          dataType: FIELD_TYPES.STRING,
          attributeName: attribute
        };
        fields.push(field);
      });
    }
    let requestParameters = productApiHelper.getRequestData(
      null,
      null,
      searchValue,
      null,
      fields,
      DATA_TYPES.PORTFOLIO,
      1
    );
    requestParameters.queryRequests.startIndex = 0;
    requestParameters.queryRequests.pageSize = null;
    return api.request(endpoints.getProductData, requestParameters).then(
      ({ data }) => {
        return Promise.resolve(data.records);
      },
      _ => {
        return Promise.resolve([]);
      }
    );
  };
  option.valueResolver = node => {
    return node.id;
  };
  return option;
};
export const assembleTemplateCategories = (
  template,
  api,
  skipFieldCallback,
  externalDriver,
  externalValidator
) => {
  let categories = [];
  let detected = {};
  template.measures.forEach(measure => {
    if (
      !measure.visible ||
      measure.dataType === FIELD_TYPES.TABLE ||
      measure.dataType === FIELD_TYPES.SURFACE
    )
      return;
    if (!measure.groupName) return;
    if (skipFieldCallback && skipFieldCallback(measure)) return;
    let field = clone(measure);
    if (field.name === REFERENCE_FIELDS.MODEL) {
      field.options = generateReferenceSelectorOption4Model(api, template.name);
    } else if (field.reference) {
      if (field.name === REFERENCE_FIELDS.PORTFOLIO_ID) {
        field.options = generateTreeSelectorOption(field, api);
      } else {
        field.options = generateReferenceSelectorOption(field, api);
      }
    }
    if (externalDriver && externalDriver[field.name]) {
      field.driveExt = externalDriver[field.name];
    }
    if (externalValidator && externalValidator[field.name]) {
      field.validateExt = externalValidator[field.name];
    }
    if (field.groupName in detected) {
      categories[detected[field.groupName]].fields.push(field);
    } else {
      detected[field.groupName] = categories.length;
      categories.push({
        groupName: field.groupName,
        fields: [field]
      });
    }
  });
  return categories;
};
export const assembleFields = (
  templateName,
  measures,
  api,
  skipFieldCallback,
  externalDriver
) => {
  let fields = [];
  measures.forEach(measure => {
    if (
      !measure.visible ||
      measure.dataType === FIELD_TYPES.TABLE ||
      measure.dataType === FIELD_TYPES.SURFACE
    )
      return;
    if (skipFieldCallback && skipFieldCallback(measure)) return;
    let field = clone(measure);
    if (field.name === REFERENCE_FIELDS.MODEL) {
      field.options = generateReferenceSelectorOption4Model(api, templateName);
    } else if (field.reference) {
      if (field.name === REFERENCE_FIELDS.PORTFOLIO_ID) {
        field.options = generateTreeSelectorOption(field, api);
      } else {
        field.options = generateReferenceSelectorOption(field, api);
      }
    }
    if (externalDriver[field.name]) {
      field.driveExt = externalDriver[field.name];
    }
    if (externalValidator[field.name]) {
      field.validateExt = externalValidator[field.name];
    }
    fields.push(field);
  });
  return fields;
};
</script>

<style scoped>
.field-default {
  float: left;
  width: 25%;
  margin: 2px 0 0;
}
</style>