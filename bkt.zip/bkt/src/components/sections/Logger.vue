<template>
  <div :class="['host',{'host-rich':visible}]">
    <div class="panel" v-show="visible">
      <div class="close" @click="close">
        <i class="iconfont icon-close"></i>
      </div>
      <div class="log-area">
        <div v-for="({msg,type},index) in logs" :key="index" class="clearfix">
          <div class="log-type">
            <i class="iconfont icon-log-error btn-error" v-show="type===RESPONSE_CODE.ERROR"></i>
            <i class="iconfont icon-log-warning btn-warning" v-show="type===RESPONSE_CODE.WARNING"></i>
            <i class="iconfont icon-log-info btn-info" v-show="type===RESPONSE_CODE.INFO"></i>
          </div>
          <span>{{msg}}</span>
        </div>
      </div>
    </div>
    <div class="btn-area">
      <div class="btn active" @click="toggle(true)" :title="$t_('view')">
        <i class="iconfont icon-chakan"></i>
      </div>
      <div class="btn" @click="toggleIgnoring('error')" :title="$t_('error')">
        <i :class="['iconfont','icon-log-error',{'btn-error':!ignoring.error}]"></i>
        <span class="active">{{logCount.error}}</span>
      </div>
      <div class="btn" @click="toggleIgnoring('warning')" :title="$t_('warning')">
        <i :class="['iconfont','icon-log-warning',{'btn-warning':!ignoring.warning}]"></i>
        <span class="active">{{logCount.warning}}</span>
      </div>
      <div class="btn" @click="toggleIgnoring('info')" :title="$t_('information')">
        <i :class="['iconfont','icon-log-info',{'btn-info':!ignoring.info}]"></i>
        <span class="active">{{logCount.info}}</span>
      </div>
      <div class="btn active" @click="clearLog" :title="$t_('clear')">
        <i class="iconfont icon-clear"></i>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { RESPONSE_CODE } from "@/consts";

export default {
  name: "Logger",
  data() {
    return {
      RESPONSE_CODE,
      visible: false,
      ignoring: {
        info: false,
        warning: false,
        error: false
      }
    };
  },
  computed: {
    ...mapGetters({
      logs: "getLogs"
    }),
    logCount() {
      let logCount = { error: 0, warning: 0, info: 0 };
      this.logs.forEach(log => {
        switch (log.type) {
          case RESPONSE_CODE.ERROR:
            logCount.error++;
            break;
          case RESPONSE_CODE.WARNING:
            logCount.warning++;
            break;
          case RESPONSE_CODE.INFO:
            logCount.info++;
            break;
        }
      });
      return logCount;
    }
  },
  methods: {
    close() {
      this.visible = false;
      this.$emit("toggle", this.visible);
    },
    toggle() {
      this.visible = !this.visible;
      this.$emit("toggle", this.visible);
    },
    toggleIgnoring(filterName) {
      this.ignoring[filterName] = !this.ignoring[filterName];
      this.$store.commit("setIgnoring", this.ignoring);
    },
    clearLog() {
      this.$store.commit("clearLogs");
    }
  }
};
</script>

<style scoped>
.host {
  position: relative;
  height: 20px;
  background-color: #535c6d;
  color: #fff;
}
.host-rich {
  height: 220px;
}
.panel {
  height: 200px;
  overflow: auto;
}
.close {
  float: right;
  height: 20px;
  line-height: 20px;
  width: 20px;
  text-align: center;
  cursor: pointer;
}
.log-area {
  cursor: auto;
  padding: 10px 20px 0 20px;
  height: 190px;
  line-height: 22px;
  background-color: #575e6b;
}
.btn-area {
  position: absolute;
  left: 0;
  bottom: 0;
  height: 20px;
  line-height: 20px;
}
.btn {
  height: 20px;
  line-height: 20px;
  float: left;
  text-align: center;
  cursor: pointer;
  margin-left: 10px;
  color: grey;
}
.active {
  color: #fff;
}
.btn-error {
  color: red;
}
.btn-warning {
  color: yellow;
}
.btn-info {
  color: #fff;
}
.log-type {
  float: left;
  width: 22px;
  height: 22px;
  text-align: center;
}
</style>