<template>
  <div class="sub-window-view clearfix" ref="view">
    <a href="popout.html" target="_blank" style="display:none" ref="popper"></a>
    <div :class="['tab-cluster', {'full-size':rightTabs.length===0}]" :style="leftStyle" ref="left">
      <div class="tab-title-container clearfix">
        <div class="popper" @click="popout(true)">
          <i class="iconfont icon-spread popper-size"></i>
        </div>
        <div
          v-for="(tab,index) in leftTabs"
          :key="index"
          :class="['tab-title',{'active-tab-title':index===leftActiveIndex}]"
          @click.stop="clickTab(tab,index,true)"
          :title="$t_(tab)"
          ref="leftTabs"
          >
          {{$t_(tab)}}
        </div>
      </div>
      <div class="tab-content-container">
        <div v-for="(tab,index) in leftTabs" :key="index" style="height:100%" v-show="leftActiveIndex===index">
          <basic-info v-if="tab===TAB_TYPES.BASIC_INFO" :ref="tab" />
          <cashflow v-else-if="tab===TAB_TYPES.CASHFLOW" :ref="tab" />
          <counterparty v-else-if="tab===TAB_TYPES.COUNTERPARTY" :ref="tab" />
          <curve v-else-if="tab===TAB_TYPES.CURVE" :ref="tab" />
          <issue-records v-else-if="tab===TAB_TYPES.ISSUE_RECORD" :ref="tab" />
          <portfolio-chart v-else-if="tab===TAB_TYPES.PORTFOLIO_CHART" :ref="tab" />
          <rating v-else-if="tab===TAB_TYPES.RATING" :ref="tab" />
          <term-structure v-else-if="tab===TAB_TYPES.TERM_STRUCTURE" :ref="tab" />
          <underlying v-else-if="tab===TAB_TYPES.UNDERLYING" :ref="tab" />
          <valuation v-else-if="tab===TAB_TYPES.VALUATION" :ref="tab" />
          <collateral-bond-info v-else-if="tab===TAB_TYPES.COLLATERAL_BOND_INFO" :ref="tab" />
        </div>
      </div>
    </div>
    <resizer axis="x" @resize="resizeLR" v-if="rightTabs.length"></resizer>
    <div class="tab-cluster" v-if="rightTabs.length" :style="rightStyle" ref="right">
      <div class="tab-title-container clearfix">
        <div class="popper" @click="popout(false)">
          <i class="iconfont icon-spread popper-size"></i>
        </div>
        <div
          v-for="(tab,index) in rightTabs"
          :key="index"
          :class="['tab-title',{'active-tab-title':rightActiveIndex===index}]"
          @click.stop="clickTab(tab,index,false)"
          :title="$t_(tab)"
          ref="rightTabs"
          >
          {{$t_(tab)}}
        </div>
      </div>
      <div class="tab-content-container">
        <div v-for="(tab,index) in rightTabs" :key="index" style="height:100%" v-show="rightActiveIndex===index">
          <basic-info v-if="tab===TAB_TYPES.BASIC_INFO" :ref="tab" />
          <cashflow v-else-if="tab===TAB_TYPES.CASHFLOW" :ref="tab" />
          <counterparty v-else-if="tab===TAB_TYPES.COUNTERPARTY" :ref="tab" />
          <curve v-else-if="tab===TAB_TYPES.CURVE" :ref="tab" />
          <issue-records v-else-if="tab===TAB_TYPES.ISSUE_RECORD" :ref="tab" />
          <portfolio-chart v-else-if="tab===TAB_TYPES.PORTFOLIO_CHART" :ref="tab" />
          <rating v-else-if="tab===TAB_TYPES.RATING" :ref="tab" />
          <term-structure v-else-if="tab===TAB_TYPES.TERM_STRUCTURE" :ref="tab" />
          <underlying v-else-if="tab===TAB_TYPES.UNDERLYING" :ref="tab" />
          <valuation v-else-if="tab===TAB_TYPES.VALUATION" :ref="tab" />
          <collateral-bond-info v-else-if="tab===TAB_TYPES.COLLATERAL_BOND_INFO" :ref="tab" />       
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import BasicInfo from "./subWindowTabs/BasicInfo";
import Cashflow from "./subWindowTabs/Cashflow";
import Curve from "./subWindowTabs/Curve";
import IssueRecords from "./subWindowTabs/IssueRecords";
import Valuation from "./subWindowTabs/Valuation";
import Rating from "./subWindowTabs/Rating";
import TermStructure from "./subWindowTabs/TermStructure";
import Underlying from "./subWindowTabs/Underlying";
import Counterparty from "./subWindowTabs/Counterparty";
import PortfolioChart from "./subWindowTabs/PortfolioChart";
import CollateralBondInfo from "./subWindowTabs/CollateralBondInfo";
import Resizer from "@/components/common/Resizer";
import { mapGetters } from "vuex";
import { POPOUT_TAB_TYPE, TAB_TYPES } from "@/consts";

export default {
  name: "SubWindowView",
  props: {
    defaultLeftWidth: {
      type: String,
      validator: function(value) {
        let regexp = /^[1-9]([0-9])?%$/;
        return regexp.test(value);
      }
    }
  },
  components: {
    BasicInfo,
    Cashflow,
    Curve,
    IssueRecords,
    Valuation,
    Rating,
    TermStructure,
    Underlying,
    Counterparty,
    PortfolioChart,
    CollateralBondInfo,
    Resizer
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      currentNav: "getCurrentNav"
    }),
    leftTabs() {
      let tabs = [];
      if (this.currentNav.subWindowsList) {
        tabs = this.currentNav.subWindowsList.split("|")[0].split(";");
      }
      return tabs;
    },
    rightTabs() {
      let tabs = [];
      if (this.currentNav.subWindowsList) {
        let leftRightArr = this.currentNav.subWindowsList.split("|");
        if (leftRightArr.length > 1) {
          tabs = leftRightArr[1].split(";");
        }
      }
      return tabs;
    },
    leftStyle() {
      let width = "calc(" + this.leftWidth + " - 4px)";
      return {
        width
      };
    },
    rightStyle() {
      let width = "calc(" + this.rightWidth + " - 4px)";
      return {
        width
      };
    }
  },
  watch: {
    entry() {
      this.$nextTick(function() {
        if (this.rightTabs.length) {
          for (var i = 0; i < this.leftTabs.length; i++) {
            this.$refs[this.leftTabs[i]][0].reset();
          }
          for (var i = 0; i < this.rightTabs.length; i++) {
            this.$refs[this.rightTabs[i]][0].reset();
          }
          if (this.leftTabs.length > this.leftActiveIndex) {
            this.$refs[this.leftTabs[this.leftActiveIndex]][0].load();
          } else {
            this.leftActiveIndex = 0;
            this.$refs[this.leftTabs[0]][0].load();
          }
          if (this.rightTabs.length > this.rightActiveIndex) {
            this.$refs[this.rightTabs[this.rightActiveIndex]][0].load();
          } else {
            this.rightActiveIndex = 0;
            this.$refs[this.rightTabs[0]][0].load();
          }
        }
      });
    }
  },
  data() {
    return {
      leftWidth: "50%",
      rightWidth: "50%",
      leftActiveIndex: 0,
      rightActiveIndex: 0,
      TAB_TYPES: TAB_TYPES
    };
  },
  beforeMount() {
    if (this.$options.propsData.defaultLeftWidth) {
      let defaultLeftWidth = this.$options.propsData.defaultLeftWidth;
      let leftPercent = Number(
        defaultLeftWidth.substr(0, defaultLeftWidth.length - 1)
      );
      let rightPercent = 100 - leftPercent;
      this.$data.leftWidth = defaultLeftWidth;
      this.$data.rightWidth = rightPercent + "%";
    }
  },
  methods: {
    popout(flag) {
      // flag: true => left, false => right
      let tab = flag
        ? this.leftTabs[this.leftActiveIndex]
        : this.rightTabs[this.rightActiveIndex];
      var index = flag ? this.leftActiveIndex : this.rightActiveIndex;
      localStorage.setItem(POPOUT_TAB_TYPE, tab);
      if (flag) {
        this.$refs[this.leftTabs[this.leftActiveIndex]][0].persistData();
      } else {
        this.$refs[this.rightTabs[this.rightActiveIndex]][0].persistData();
      }
      this.$refs.popper.click();
    },
    clickTab(tab, index, flag) {
      // flag: true => left, false => right
      if (flag) {
        this.leftActiveIndex = index;
      } else {
        this.rightActiveIndex = index;
      }
      if (this.entry.id) {
        this.$nextTick(function() {
          // to fix the bug that curve is too small
          if (flag) {
            this.$refs[this.leftTabs[this.leftActiveIndex]][0].load();
          } else {
            this.$refs[this.rightTabs[this.rightActiveIndex]][0].load();
          }
        });
      }
    },
    resizeLR(offset) {
      let containerWidth = this.$refs.view.clientWidth,
        paddingLeft = 10,
        tabTitlePadding = 20,
        tabTitleMargin = 5,
        popperWidth = 40,
        popperMargin = 4,
        draggerWidth = 8,
        leftMinWidth = paddingLeft + popperWidth + popperMargin,
        rightMinWidth = paddingLeft + popperWidth + popperMargin,
        leftWidth = 0,
        rightWidth = 0;
      this.$refs.leftTabs.forEach(tab => {
        leftMinWidth += tab.clientWidth + tabTitlePadding + tabTitleMargin;
      });
      this.$refs.rightTabs.forEach(tab => {
        leftMinWidth += tab.clientWidth + tabTitlePadding + tabTitleMargin;
      });
      leftMinWidth = Math.ceil(leftMinWidth);
      rightMinWidth = Math.ceil(rightMinWidth);
      leftWidth = this.$refs.left.clientWidth + offset;
      rightWidth = this.$refs.right.clientWidth - offset;
      if (leftWidth < leftMinWidth) {
        leftWidth = leftMinWidth;
        rightWidth = containerWidth - leftWidth - draggerWidth;
      } else if (rightWidth < rightMinWidth) {
        rightWidth = rightMinWidth;
        leftWidth = containerWidth - rightWidth - draggerWidth;
      }
      this.leftWidth = leftWidth / (leftWidth + rightWidth) * 100 + "%";
      this.rightWidth = rightWidth / (leftWidth + rightWidth) * 100 + "%";
      this.resizeSubWindow();
    },
    resize() {
      this.resizeSubWindow();
    },
    resizeSubWindow() {
      this.leftTabs.forEach(tab => {
        if (this.$refs[tab][0].resize) {
          this.$refs[tab][0].resize();
        }
      });
      this.rightTabs.forEach(tab => {
        if (this.$refs[tab][0].resize) {
          this.$refs[tab][0].resize();
        }
      });
    }
  }
};
</script>
<style scoped>
.sub-window-view {
  height: 100%;
  width: 100%;
}
.tab-cluster {
  height: 100%;
  float: left;
  width: calc(50% - 4px);
  width: -ms-calc(50% - 4px);
  width: -moz-calc(50% - 4px);
  width: -webkit-calc(50% - 4px);
}
.full-size {
  width: 100%;
}
.tab-title-container {
  height: 40px;
  border-bottom: 1px solid #ccc;
  padding-left: 10px;
}
.popper {
  float: right;
  line-height: 40px;
  width: 40px;
  cursor: pointer;
  text-align: center;
  height: 40px;
}
.popper:hover {
  color: #bf0535;
}
.popper-size {
  font-size: 26px;
}
.tab-title {
  height: 30px;
  margin-top: 10px;
  cursor: pointer;
  float: left;
  line-height: 30px;
  padding: 0 10px;
  background-color: #eeeeee;
  border-top-left-radius: 6px;
  border-top-right-radius: 6px;
  margin-right: 5px;
}
.tab-title:hover {
  background-color: #bf0535;
  color: #fff;
}
.active-tab-title {
  background-color: #4e586f;
  color: #fff;
}
.tab-content-container {
  height: calc(100% - 41px);
  height: -ms-calc(100% - 41px);
  height: -moz-calc(100% - 41px);
  height: -webkit-calc(100% - 41px);
  overflow: auto;
}
</style>
