<template>
  <div class="section">
    <span class="category-title">{{$t_('operation_logs')}} :</span>
    <div v-for="(log,index) in logs" :key="index" class="log">
      <i class="iconfont icon-log-error error" v-if="log.type===RESPONSE_CODE.ERROR"></i>
      <i class="iconfont icon-log-warning warning" v-else-if="log.type===RESPONSE_CODE.WARNING"></i>
      <i class="iconfont icon-log-info" v-else></i>
      <span>{{log.msg}}</span>
    </div>
  </div>
</template>

<script>
import { RESPONSE_CODE, POPOUT_TAB_DATA } from "@/consts";

export default {
  name: "Log",
  data() {
    return {
      logs: []
    };
  },
  computed: {
    RESPONSE_CODE() {
      return RESPONSE_CODE;
    }
  },
  mounted() {
    this.logs = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
  }
};
</script>

<style scoped>
.section {
  margin: 0 10px;
}
.error {
  color: red;
}
.warning {
  color: yellow;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-top: 6px;
}
.log {
  border: 1px solid #ccc;
  line-height: 24px;
}
</style>