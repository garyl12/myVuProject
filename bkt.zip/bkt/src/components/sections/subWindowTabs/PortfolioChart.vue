<template>
  <div style="height:100%;width:100%">
    <div class="half-area clearfix">
      <div class="chart-top">
        <label>{{$t_("factor")+":"}}</label>
        <select v-model="selectedFactor">
          <option :value="factor" v-for="(factor,i) in factors" :key="i">{{$t_(factor)}}</option>
        </select>
      </div>
      <div ref="chart" style="height:100%"></div>
    </div>
    <div class="half-area clearfix">
       <div class="chart-top">
        <label>{{$t_("chart")+":"}}</label>
        <select v-model="selectedChartType">
          <option :value="chartType.value" v-for="(chartType,i) in chartTypes" :key="i">{{chartType.text}}</option>
        </select>
      </div>
      {{factorDetails}}
      <div v-for="(item, i) in factorDetails" :key="i">{{item}}</div>
    </div>
  </div>
</template>

<script>
import echarts from "echarts/dist/echarts.common.min.js";
import { mapGetters } from "vuex";
import { PORTFOLIO_DATA_KEYS as KEYS, FIELD_TYPES } from "@/consts";
import { clone } from "@/utils";

export default {
  name: "PortfolioChart",
  props: {
    popout: Boolean
  },
  data() {
    return {
      selectedFactor: "",
      selectedChartType: -1,
      chartApp: null
    };
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    tableColumns() {},
    factors() {
      let portfolioTemplate = this.templates[KEYS.TEMPLATES.PORTFOLIO];
      let factors = [];
      if (portfolioTemplate) {
        portfolioTemplate.measures.forEach(measure => {
          if (
            !measure.input &&
            (measure.dataType === FIELD_TYPES.DOUBLE ||
              measure.dataType === FIELD_TYPES.INTEGER)
          ) {
            factors.push(measure.name);
          }
        });
      }
      return factors;
    },
    chartTypes() {
      return [
        {
          text: this.$t_("pie"),
          value: 0
        },
        {
          text: this.$t_("histogram"),
          value: 1
        },
        {
          text: this.$t_("curve"),
          value: 2
        }
      ];
    },
    factorDetails() {
      if (this.selectedFactor) {
        return this.entry.attributes[this.selectedFactor];
      }
      return [];
    }
  },
  watch: {
    selectedFactor() {
      this.draw();
    }
  },
  methods: {
    draw() {
      switch (this.selectedChartType) {
        case 0:
          this.drawPie();
          break;
        case 1:
          this.drawHistogram();
          break;
        case 2:
          this.drawCurve();
          break;
        default:
          break;
      }
    },
    initApp() {
      this.chartApp = echarts.init(this.$refs.chart, {});
    },
    drawPie() {
      if (this.chartApp) {
        this.chartApp.dispose();
        this.chartApp = null;
      }
      this.initApp();
      let option = clone(CHART_OPTION.PIE);
      this.chartApp.setOption();
    },
    drawHistogram() {
      if (this.chartApp) {
        this.chartApp.dispose();
        this.chartApp = null;
      }
      this.initApp();
      let option = clone(CHART_OPTION.BAR);
    },
    drawCurve() {
      if (this.chartApp) {
        this.chartApp.dispose();
        this.chartApp = null;
      }
      this.initApp();
      let option = clone(CHART_OPTION.CURVE);
    },
    load() {},
    reset() {}
  }
};
</script>

<style scoped>
.half-area {
  float: left;
  width: 50%;
  height: 100%;
  position: relative;
}
.chart-top {
  height: 20px;
}
</style>
