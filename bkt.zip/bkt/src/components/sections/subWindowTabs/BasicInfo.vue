<template>
  <div class="section">
    <div class="clearfix" v-for="(item,zIndex) in fields" :key="zIndex">
      <p><span class="category-title">{{$t_(item[0].groupName)}} :</span></p>
      <div v-for="(field,index) in item" :key="index" class="float-cell" v-if="field.dataType!=='TABLE'&&field.dataType!=='LIST'&&field.dataType!=='SURFACE'&&displayingEntry.attributes[field.name]">
        <div class="left" :title="$t_(field.name)|decorateFieldName(field.displayFormat)">{{$t_(field.name)|decorateFieldName(field.displayFormat)}}</div>
        <div class="right" :title="(displayingEntry.attributes[field.name]||{value:''}).value|formatDisplay(field.displayFormat)">{{(displayingEntry.attributes[field.name]||{value:''}).value|formatDisplay(field.displayFormat)}}</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { POPOUT_TAB_DATA } from "@/consts";

export default {
  name: "BasicInfo",
  props: {
    popout: Boolean
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    fields() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.fields;
      }
      let allCategory = [],
        typeList = [],
        index = null,
        categoryArr = [],
        showFields = [],
        template = this.templates[this.entry.templateName];
      if (template) {
        template.measures.forEach(item => {
          item.groupName = item.groupName ? item.groupName : "default";
          index = typeList.indexOf(item.groupName);
          if (index === -1) {
            typeList.push(item.groupName);
            categoryArr = [];
            categoryArr.push(item);
            allCategory.push(categoryArr);
          } else {
            allCategory[index].push(item);
          }
        });
        allCategory.forEach((attributes, index) => {
          let isGroupVisible = false;
          attributes.forEach(attribute => {
            let item = this.entry.attributes[attribute["name"]];
            if (item && item.value && item.value !== "") {
              isGroupVisible = true;
            }
          });
          if (isGroupVisible) showFields.push(attributes);
        });
      }
      return showFields;
    },
    displayingEntry() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.entry;
      }
      return this.entry;
    }
  },
  methods: {
    load() {},
    reset() {},
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          fields: this.fields,
          entry: this.entry
        })
      );
    }
  }
};
</script>

<style scoped>
.section {
  margin: 0 10px;
}
.float-cell {
  float: left;
  width: 50%;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  line-height: 22px;
}
.left {
  border: 1px solid #ccc;
  float: left;
  width: 40%;
  text-align: right;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
.right {
  border: 1px solid #ccc;
  float: left;
  width: 60%;
  text-align: left;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-top: 6px;
}
</style>
