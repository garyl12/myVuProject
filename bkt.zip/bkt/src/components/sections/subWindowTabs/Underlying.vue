<template>
    <vertical-grid
      v-if="displayingData.length > 1"
      :data="displayingData"
      :rows="fields"
      />
    <div class="section" v-else-if="displayingData.length === 1">
      <div v-for="(field, index) in fields" :key="index" class="float-cell clearfix">
        <div class="left" :title="$t_(field.name) | decorateFieldName(field.displayFormat)">
          {{ $t_(field.name) | decorateFieldName(field.displayFormat) }}
        </div>
        <div class="right" :title="(displayingData[0].attributes[field.name] || { value: '' }).value | formatDisplay(field.displayFormat)">
          {{ (displayingData[0].attributes[field.name] || { value: '' }).value | formatDisplay(field.displayFormat) }}
        </div>
      </div>
    </div>
    <p class="section" v-else>
      {{$t_("no record")}}
    </p>
</template>
<script>
import VerticalGrid from "@/components/common/VerticalGrid";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import { clone } from "@/utils";
import {
  DATA_KEYS as Keys,
  DATA_TYPES,
  RESPONSE_CODE,
  POPOUT_TAB_DATA
} from "@/consts";

export default {
  name: "Underlying",
  components: { VerticalGrid },
  props: {
    popout: Boolean
  },
  data() {
    return {
      data: [],
      loaded: true,
      multiple: false
    };
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    template() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.template;
      }
      let template = null;
      if (this.data.length) {
        template = this.templates[this.data[0].templateName];
      }
      return template;
    },
    displayingData() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.data;
      }
      return this.data;
    },
    fields() {
      let fields = [];
      if (this.template) {
        this.template.measures.forEach(field => {
          if (
            !field.visible ||
            field.dataType === "TABLE" ||
            field.dataType === "SURFACE"
          )
            return;
          fields.push(field);
        });
      }
      return fields;
    }
  },
  watch: {
    entry() {
      this.loaded = false;
    }
  },
  methods: {
    reset() {},
    load() {
      if (this.loaded) return;
      this.loaded = true;
      if (this.entry.attributes) {
        let underlyingIDs = [];
        if (this.entry.attributes[Keys.UNDERLYING_IDS]) {
          underlyingIDs = this.entry.attributes[Keys.UNDERLYING_IDS].value;
        } else if (this.entry.attributes[Keys.UNDERLYING_ID]) {
          underlyingIDs = [this.entry.attributes[Keys.UNDERLYING_ID].value];
        } else if (this.entry.attributes[Keys.UNDERLYING_BOND_ID]) {
          underlyingIDs = [
            this.entry.attributes[Keys.UNDERLYING_BOND_ID].value
          ];
        } else if (this.entry.attributes[Keys.BOND_ID]) {
          underlyingIDs = [this.entry.attributes[Keys.BOND_ID].value];
        }
        if (underlyingIDs.length) {
          let defaultCondition = {
              searchType: "ID",
              searchValues: underlyingIDs
            },
            requestParameters = productApiHelper.getRequestData(
              defaultCondition,
              null,
              null,
              null,
              null,
              DATA_TYPES.MARKETDATA,
              null
            );
          requestParameters.queryRequests.pageSize = null;
          requestParameters.queryRequests.startIndex = 0;

          this.$api.request(endpoints.getProductData, requestParameters).then(
            ({ data }) => {
              this.data = data.records;
            },
            _ => {
              this.data = [];
            }
          );
        } else {
          this.data = [];
        }
      }
    },
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          template: this.template,
          data: this.data
        })
      );
    }
  }
};
</script>
<style scoped>
.section {
  padding: 0 10px;
}
.float-cell {
  float: left;
  width: 50%;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  line-height: 24px;
}
.left {
  border: 1px solid #ccc;
  float: left;
  width: 40%;
  text-align: right;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
.right {
  border: 1px solid #ccc;
  float: left;
  width: 60%;
  text-align: left;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
</style>
