<template>
  <div class="issue-record-tab">
    <grid
      :need-index="true"
      :columns="gridColumns"
      :data="gridData"
      ref="grid"
      />
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import { mapGetters } from "vuex";
import { clone, parseEntityTableFieldValueToEntity } from "@/utils";
import { DATA_KEYS, POPOUT_TAB_DATA } from "@/consts";

export default {
  name: "IssueRecordTab",
  components: {
    Grid
  },
  props: {
    popout: Boolean
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    gridColumns() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.gridColumns;
      }
      let columns = [],
        template = {};
      if (this.entry.id && this.templates[this.entry.templateName]) {
        template = this.templates[this.entry.templateName];
        template.measures.forEach(measure => {
          if (measure.name === DATA_KEYS.BOND_ISSUANCE_AND_GUARANTEE) {
            measure.subMeasures.forEach(subMeasure => {
              subMeasure.isSortable = false;
              columns.push(subMeasure);
            });
          }
        });
      }
      return columns;
    },
    gridData() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.gridData;
      }
      let data = [];
      if (
        this.entry.id &&
        this.entry.attributes[DATA_KEYS.BOND_ISSUANCE_AND_GUARANTEE]
      ) {
        data = parseEntityTableFieldValueToEntity(
          clone(
            this.entry.attributes[DATA_KEYS.BOND_ISSUANCE_AND_GUARANTEE].value
          )
        );
      }
      return data;
    }
  },
  methods: {
    load() {
      this.$refs.grid.resize();
    },
    reset() {},
    resize() {
      this.$refs.grid.resize();
    },
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          gridData: this.gridData,
          gridColumns: this.gridColumns
        })
      );
    }
  }
};
</script>

<style scoped>
.issue-record-tab {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
</style>
