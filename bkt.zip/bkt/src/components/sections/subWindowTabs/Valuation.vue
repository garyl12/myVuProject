<template>
  <vertical-grid
    :rows="gridColumns"
    :data="gridData"
    key-row="Valuation Organization"
    ref="grid"
    />
</template>

<script>
import Grid from "@/components/common/Grid";
import VerticalGrid from "@/components/common/VerticalGrid";
import { mapGetters } from "vuex";
import { DATA_KEYS, POPOUT_TAB_DATA } from "@/consts";
import { parseEntityTableFieldValueToEntity } from "@/utils";

export default {
  name: "Valuation",
  components: {
    Grid,
    VerticalGrid
  },
  props: {
    popout: Boolean
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    gridColumns() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.gridColumns;
      }
      let columns = [],
        detected = {},
        template = {};
      if (this.entry.id && this.templates[this.entry.templateName]) {
        template = this.templates[this.entry.templateName];
        template.measures.forEach(measure => {
          if (measure.groupName === DATA_KEYS.BKT_VALUATION) {
            columns.push(measure);
            detected[measure.name] = true;
          }
        });
        //to make bkt evaluation attributes ahead of thirdparty evaluation attributes
        template.measures.forEach(measure => {
          if (measure.name === DATA_KEYS.THIRDPARTY_VALUATION) {
            measure.subMeasures.forEach(subMeasure => {
              if (!detected[subMeasure.name]) {
                columns.push(subMeasure);
              }
            });
          }
        });
      }
      return columns;
    },
    gridData() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.gridData;
      }
      let data = [],
        thirdpartyData = [],
        hasMeaningfulAttr = false,
        bktValuationData = { attributes: {} };
      if (this.entry.id) {
        //assemble BKT Valuation Data
        this.gridColumns.forEach(column => {
          if (
            column.groupName === DATA_KEYS.BKT_VALUATION &&
            this.entry.attributes[column.attributeName]
          ) {
            hasMeaningfulAttr = true;
            bktValuationData.attributes[
              column.attributeName
            ] = this.entry.attributes[column.attributeName];
          }
        });
        if (hasMeaningfulAttr) {
          bktValuationData.attributes[DATA_KEYS.VALUATION_ORGANIZATION] = {
            value: "BKT"
          };
          data.push(bktValuationData);
        }
        if (this.entry.attributes[DATA_KEYS.THIRDPARTY_VALUATION]) {
          let value = this.entry.attributes[DATA_KEYS.THIRDPARTY_VALUATION]
            .value;
          if (value) {
            thirdpartyData = parseEntityTableFieldValueToEntity(value);
          }
        }
      }
      return data.concat(thirdpartyData);
    }
  },
  methods: {
    load() {
      this.resize();
    },
    reset() {},
    resize() {
      if (this.$refs.grid) this.$refs.grid.resize();
    },
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          gridData: this.gridData,
          gridColumns: this.gridColumns
        })
      );
    }
  }
};
</script>
