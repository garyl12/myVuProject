<template>
  <div class="section">
    <div v-for="(field,index) in template.measures" :key="index" class="float-cell clearfix" 
      v-if="field.dataType!=='TABLE'&&field.dataType!=='LIST'&&field.dataType!=='SURFACE'&&displayingData.attributes[field.name]">
      <div class="left" :title="$t_(field.name)|decorateFieldName(field.displayFormat)">{{$t_(field.name)|decorateFieldName(field.displayFormat)}}</div>
      <div class="right" :title="(displayingData.attributes[field.name]||{value:''}).value|formatDisplay(field.displayFormat)">{{(displayingData.attributes[field.name]||{value:''}).value|formatDisplay(field.displayFormat)}}</div>
    </div>
    <p class="no-record" v-show="displayingData.attributes.id">
      {{$t_("no record")}}
    </p>
  </div>
</template>
<script>
import endpoints from "@/api/endpoints";
import { clone } from "@/utils";
import { mapGetters } from "vuex";
import { DATA_KEYS as Keys, DATA_TYPES, POPOUT_TAB_DATA } from "@/consts";
import productApiHelper from "@/utils/productApiHelper";

export default {
  name: "Counterparty",
  props: {
    popout: Boolean
  },
  data() {
    return {
      data: {
        attributes: {}
      },
      loaded: true
    };
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    template() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.template;
      }
      let template = { measures: [] };
      if (this.data.templateName) {
        template = this.templates[this.data.templateName];
      }
      return template;
    },
    displayingData() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.data;
      }
      return this.data;
    }
  },
  watch: {
    entry() {
      this.loaded = false;
    }
  },
  methods: {
    reset() {},
    load() {
      if (this.loaded) return;
      this.data = { attributes: {} };
      this.loaded = true;
      if (this.entry.attributes) {
        let counterpartyId = (this.entry.attributes[Keys.COUNTERPARTY] || {})
          .value;
        if (counterpartyId) {
          let defaultCondition = {
              searchType: "ID",
              searchValues: [counterpartyId]
            },
            requestParams = productApiHelper.getRequestData(
              defaultCondition,
              null,
              null,
              null,
              null,
              DATA_TYPES.LEGALENTITY,
              1
            );

          this.$api.request(endpoints.getProductData, requestParams).then(
            ({ code, data, messages }) => {
              if (data.records.length) {
                this.data = data.records[0];
              }
            },
            () => {
              this.data = {};
            }
          );
        }
      }
    },
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          data: this.data,
          template: this.template
        })
      );
    }
  }
};
</script>

<style scoped>
.section {
  margin: 0 10px;
}
.float-cell {
  float: left;
  width: 50%;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  line-height: 24px;
}
.left {
  border: 1px solid #ccc;
  float: left;
  width: 40%;
  text-align: right;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
.right {
  border: 1px solid #ccc;
  float: left;
  width: 60%;
  text-align: left;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 3px;
}
</style>
