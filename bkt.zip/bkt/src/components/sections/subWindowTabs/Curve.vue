<template>
  <div class="wrap"> 
    <div class="curve-name">
      <label><strong>{{$t_("curve_name")}}</strong>:</label>
      <label v-if="this.popout||!needCurveSelector">{{curveName}}</label>
      <select class="curve-select" v-model="curveName" v-else>
        <option v-for="(item,index) in curveOptions" :key="index" :value="item">{{item}}</option>
      </select>
    </div>
    <div ref="curve" class="curve-panel"></div>
  </div>
</template>
<script>
import echarts from "echarts/dist/echarts.common.min.js";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import {
  clone,
  convertStandardTermToDate,
  convertStandardTermToDays
} from "@/utils";
import {
  DATA_KEYS,
  POPOUT_TAB_DATA,
  DATA_TYPES,
  CURVE_OPTION_PATTERN,
  CURVE_YAXIS_DATA_PATTERN,
  RESPONSE_CODE
} from "@/consts";

export default {
  name: "Curve",
  props: {
    popout: Boolean
  },
  data() {
    return {
      curveApp: null,
      curveName: "",
      curveOptions: [],
      curveData: {}
    };
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      marketDate: "getMarketDate"
    }),
    needCurveSelector() {
      return this.entry.type !== DATA_KEYS.CURVE;
    }
  },
  watch: {
    curveName(name) {
      if (!this.popout) {
        if (name) {
          this.paintCurve(this.curveData[name]);
        } else {
          this.reset();
        }
      }
    },
    entry() {
      this.curveData = {};
    }
  },
  mounted() {
    if (this.popout) {
      this.curveApp = echarts.init(this.$refs.curve);
      let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
      this.curveName = tabData.curveData.id;
      this.paintCurve(tabData.curveData);
    }
  },
  methods: {
    load() {
      if (this.entry.type === DATA_KEYS.CURVE) {
        this.$set(
          this.curveData,
          this.entry.id,
          this.parseToCurveData(this.entry)
        );
        this.curveName = this.entry.id;
      } else {
        this.curveName = "";
        this.requestCurveData();
      }
    },
    requestCurveData() {
      if (this.entry.references && this.entry.references.length) {
        let defaultCondition = {
            searchType: "ID",
            searchValues: this.entry.references
          },
          requestParameters = productApiHelper.getRequestData(
            defaultCondition,
            null,
            null,
            null,
            null,
            DATA_TYPES.MARKETDATA,
            1
          );
        this.$api
          .request(endpoints.getProductData, requestParameters)
          .then(({ code, data }) => {
            if (code === RESPONSE_CODE.INFO) {
              this.curveOptions = data.records.map(record => record.id);
              data.records.forEach(curveEntry => {
                this.$set(
                  this.curveData,
                  curveEntry.id,
                  this.parseToCurveData(curveEntry)
                );
              });
              this.curveName = this.curveOptions[0];
            } else {
              this.curveOptions = [];
            }
          });
      }
    },
    parseToCurveData(curveEntry) {
      let terms = [],
        termValues = [];
      if (
        curveEntry.attributes[DATA_KEYS.CURVE_VALUE] &&
        curveEntry.attributes[DATA_KEYS.CURVE_VALUE].value
      ) {
        terms = (
          curveEntry.attributes[DATA_KEYS.CURVE_VALUE].value[
            DATA_KEYS.DIMENSIONS
          ][0].dimension || []
        ).map(item => item);
        termValues =
          curveEntry.attributes[DATA_KEYS.CURVE_VALUE].value[
            DATA_KEYS.SURFACE_VALUE_1D
          ] || [];
        if (terms.length) {
          let map = {};
          terms.forEach((term, index) => {
            map[term] = termValues[index];
          });
          terms.sort((a, b) => {
            return convertStandardTermToDays(a) - convertStandardTermToDays(b);
          });
          termValues = terms.map(term => map[term]);
        }
      }
      return {
        id: curveEntry.id,
        terms,
        termValues
      };
    },
    paintCurve(curveData) {
      this.reset();
      this.curveApp = echarts.init(this.$refs.curve);
      var curveAppOption = clone(CURVE_OPTION_PATTERN);
      curveAppOption.xAxis.data = curveData.terms;
      var yAxisData = clone(CURVE_YAXIS_DATA_PATTERN);
      if (curveData.terms.length === 1) {
        yAxisData.symbolSize = 5;
        yAxisData.symbol = "circle";
      }
      yAxisData.name = curveData.id;
      yAxisData.data = curveData.termValues;
      curveAppOption.series = [];
      curveAppOption.series.push(yAxisData);
      curveAppOption.tooltip.formatter = params => {
        return "Date: {0}<br/>Term: {1}<br/>Value: {2}".format(
          convertStandardTermToDate(params[0].name, this.marketDate),
          params[0].name,
          params[0].value
        );
      };
      this.curveApp.setOption(curveAppOption);
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          curveData
        })
      );
    },
    reset() {
      if (this.curveApp) {
        this.curveApp.dispose();
        this.curveApp = null;
      }
    },
    resize() {
      this.paintCurve(this.curveData[this.curveName]);
    },
    persistData() {}
  }
};
</script>

<style scoped>
.wrap {
  height: 100%;
}
.curve-name {
  width: 100%;
  height: 30px;
  line-height: 30px;
}
.curve-name label {
  margin-left: 40px;
}
.curve-select {
  width: 240px;
  overflow: hidden;
}
.curve-panel {
  width: 100%;
  height: calc(100% - 30px);
  height: -ms-calc(100% - 30px);
  height: -moz-calc(100% - 30px);
  height: -webkit-calc(100% - 30px);
}
</style>
