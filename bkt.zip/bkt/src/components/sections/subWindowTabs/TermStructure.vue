<template>
  <div class="term-structure-tab">
    <div class="grid-area">
      <grid
        :columns="gridColumns"
        :data="gridData"
        @sort="sort"
        ref="grid"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Grid from "@/components/common/Grid";
import { DATA_KEYS, POPOUT_TAB_DATA } from "@/consts";
import {
  clone,
  convertStandardTermToDate,
  convertStandardTermToDays
} from "@/utils";

export default {
  name: "TermStructure",
  components: {
    Grid
  },
  props: {
    popout: Boolean
  },
  computed: {
    ...mapGetters({
      entry: "getSelectedEntry",
      marketDate: "getMarketDate"
    }),
    gridColumns() {
      let columns = [
        {
          attributeName: "date",
          displayName: "date"
        },
        {
          attributeName: "standardTerm",
          displayName: "standard term"
        },
        {
          attributeName: "termValue",
          displayName: "term value"
        }
      ];
      if (
        this.entry.curveType &&
        this.entry.curveType == "FX_IMPLIED_VOL_CURVE"
      ) {
        columns.unshift({ displayName: "term", attributeName: "term" });
      }
      return columns;
    },
    gridData() {
      if (this.popout) {
        let tabData = JSON.parse(localStorage.getItem(POPOUT_TAB_DATA));
        return tabData.gridData;
      }
      let termData = [],
        terms = [],
        termValues = [],
        standardTerms = [],
        termMap = {};
      if (
        this.entry.attributes &&
        this.entry.attributes[DATA_KEYS.CURVE_VALUE]
      ) {
        standardTerms = clone(
          this.entry.attributes[DATA_KEYS.CURVE_VALUE].value[
            DATA_KEYS.DIMENSIONS
          ][0].dimension
        );
        termValues = this.entry.attributes[DATA_KEYS.CURVE_VALUE].value[
          DATA_KEYS.SURFACE_VALUE_1D
        ];
        if (standardTerms.length) {
          standardTerms.forEach((standardTerm, index) => {
            termMap[standardTerm] = {
              standardTerm: { value: standardTerm },
              term: {
                value: convertStandardTermToDays(standardTerm, this.marketDate)
              },
              date: {
                value: convertStandardTermToDate(standardTerm, this.marketDate)
              },
              termValue: { value: termValues[index] }
            };
          });
          standardTerms.sort((a, b) => {
            return (
              convertStandardTermToDays(a, this.marketDate) -
              convertStandardTermToDays(b, this.marketDate)
            );
          });
          standardTerms.forEach(item => {
            termData.push({ attributes: termMap[item] });
          });
        }
      }
      return termData;
    }
  },
  methods: {
    load() {
      this.resize();
    },
    reset() {},
    resize() {
      this.$refs.grid.resize();
    },
    resize() {
      this.$refs.grid.resize();
    },
    sort({ sortBy, searchBy }) {
      this.gridData.sort((a, b) => {
        return !sortBy._order
          ? b.attributes.term.value - a.attributes.term.value
          : a.attributes.term.value - b.attributes.term.value;
      });
    },
    persistData() {
      localStorage.setItem(
        POPOUT_TAB_DATA,
        JSON.stringify({
          gridData: this.gridData
        })
      );
    }
  }
};
</script>

<style scoped>
.term-structure-tab {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.grid-area {
  width: 100%;
  height: 100%;
}
</style>
