<template>
  <div class="host" ref="host">
    <div :class="['container',{'container-above':above,'container-below':!above}]">
      <div class="panel-host">
        <transition name="slide-fade">
          <div v-show="visible">
            <div class="panel" :style="{width:panelWidth+'px',height:panelHeight+'px'}"
              @mouseover="clearFadeOutTimer" @mouseout="registerFadeOutTimer">
              <div class="log-arrow-up" @click="scroll(false)" v-show="logOverflow">
                <i class="iconfont icon-aro-up"></i>
              </div>
              <div class="log-arrow-down" @click="scroll(true)" v-show="logOverflow">
                <i class="iconfont icon-aro-down"></i>
              </div>
              <div class="log-body" ref="body">
                <div class="log-row clearfix" v-for="(log,index) in logs" :key="index"  :title="log.msg">
                  <div class="log-level btn-info" v-if="log.type===RESPONSE_CODE.INFO">
                    <i class="iconfont icon-log-info"></i>
                  </div>
                  <div class="log-level btn-warning" v-else-if="log.type===RESPONSE_CODE.WARNING">
                    <i class="iconfont icon-log-warning"></i>
                  </div>
                  <div class="log-level btn-error" v-else-if="log.type===RESPONSE_CODE.ERROR">
                    <i class="iconfont icon-log-error"></i>
                  </div>
                  <span>{{log.msg}}</span>
                </div>
              </div>
            </div>
            <div class="panel-tail"></div>
          </div>
        </transition>
      </div>
      <div class="logger-btn" @click="showPanel(!visible)">
        <i class="iconfont icon-information"></i>
      </div>
    </div>
  </div>
</template>

<script>
import { RESPONSE_CODE } from "@/consts";
const MAX_ROW_COUNT = 5;

export default {
  name: "EditorLogger",
  props: {
    logs: {
      type: Array,
      required: true
    },
    above: Boolean
  },
  data() {
    return {
      visible: false,
      panelWidth: 0,
      panelHeight: 0,
      fadeTimer: null
    };
  },
  computed: {
    RESPONSE_CODE() {
      return RESPONSE_CODE;
    },
    logOverflow() {
      return this.logs.length > MAX_ROW_COUNT;
    }
  },
  watch: {
    logs() {
      this.showPanel(this.logs.length > 0);
      if (this.logs.length) {
        this.registerFadeOutTimer();
      }
    }
  },
  methods: {
    showPanel(visible) {
      this.visible = visible && this.logs.length;
      if (this.visible) {
        this.panelWidth = this.$refs.host.clientWidth - 100;
        this.panelHeight = Math.min(this.logs.length, MAX_ROW_COUNT) * 30;
      }
    },
    registerFadeOutTimer() {
      if (!this.logs.some(log => log.type !== RESPONSE_CODE.INFO)) {
        this.fadeTimer = setTimeout(() => {
          this.fadeTimer = null;
          this.visible = false;
        }, 3000);
      }
    },
    clearFadeOutTimer() {
      if (this.fadeTimer) {
        clearTimeout(this.fadeTimer);
      }
    },
    scroll(down) {
      if (down) {
        this.$refs.body.scrollTop += 10;
      } else {
        this.$refs.body.scrollTop = Math.max(0, this.$refs.body.scrollTop - 10);
      }
    }
  }
};
</script>

<style scoped>
.host {
  height: 0;
  position: relative;
}
.container {
  position: absolute;
  right: 0;
  height: 30px;
  width: 30px;
  z-index: 1;
}
.container-below {
  top: 0;
}
.container-above {
  bottom: 0;
}
.logger-btn {
  text-align: center;
  line-height: 30px;
  cursor: pointer;
}
.logger-btn:hover {
  color: #c39f5a;
}
.panel-host {
  position: relative;
}
.panel {
  position: absolute;
  top: 0;
  right: 25px;
  line-height: 30px;
  background-color: rgb(170, 170, 170);
  height: 30px;
  border-radius: 4px;
  overflow: hidden;
}
.panel-tail {
  position: absolute;
  top: 10px;
  right: 15px;
  border: 5px solid transparent;
  border-left: 5px solid rgb(170, 170, 170);
}
.log-body {
  height: 100%;
  overflow: hidden;
}
.log-arrow-up,
.log-arrow-down {
  position: absolute;
  right: 10px;
  border-radius: 50%;
  height: 16px;
  width: 16px;
  line-height: 16px;
  cursor: pointer;
  text-align: center;
  background-color: rgb(80, 80, 80);
  color: #fff;
}
.log-arrow-up:hover,
.log-arrow-down:hover {
  background-color: #fff;
  color: #000;
}
.log-arrow-up {
  top: 5px;
}
.log-arrow-down {
  bottom: 5px;
}
.log-row {
  margin-left: 5px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
.log-level {
  float: left;
  height: 30px;
  width: 20px;
  line-height: 30px;
}
.btn-error {
  color: red;
}
.btn-warning {
  color: yellow;
}
.btn-info {
  color: #000;
}
.slide-fade-enter-active {
  transition: all 1s ease;
}
.slide-fade-leave-active {
  transition: all 1s ease;
}
.slide-fade-enter,
.slide-fade-leave-to {
  transform: translateX(30px);
  opacity: 0;
}
</style>