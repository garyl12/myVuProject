<template>
  <div style="height:100%">
    <div class="top-row">
      <page-header :in-popout="true"></page-header>
    </div>
    <div class="bottom-row">
      <div class="content-wrap">
        <basic-info v-if="tabType===TAB_TYPES.BASIC_INFO" :popout="true" />
        <cashflow v-else-if="tabType===TAB_TYPES.CASHFLOW" :popout="true" />
        <curve v-else-if="tabType===TAB_TYPES.CURVE" :popout="true" />
        <counterparty v-else-if="tabType===TAB_TYPES.COUNTERPARTY" :popout="true" />
        <issue-records v-else-if="tabType===TAB_TYPES.ISSUE_RECORD" :popout="true" />
        <portfolio-chart v-else-if="tabType===TAB_TYPES.PORTFOLIO_CHART" :popout="true" />
        <rating v-else-if="tabType===TAB_TYPES.RATING" :popout="true" />
        <term-structure v-else-if="tabType===TAB_TYPES.TERM_STRUCTURE" :popout="true" />
        <underlying v-else-if="tabType===TAB_TYPES.UNDERLYING" :popout="true" />
        <valuation v-else-if="tabType===TAB_TYPES.VALUATION" :popout="true" />
        <log v-else-if="tabType===TAB_TYPES.LOG" />
      </div>
    </div>
  </div>
</template>
<script>
import PageHeader from "@/components/pages/layouts/PageHeader";
import BasicInfo from "@/components/sections/subWindowTabs/BasicInfo";
import Cashflow from "@/components/sections/subWindowTabs/Cashflow";
import Counterparty from "@/components/sections/subWindowTabs/Counterparty";
import Curve from "@/components/sections/subWindowTabs/Curve";
import IssueRecords from "@/components/sections/subWindowTabs/IssueRecords";
import Rating from "@/components/sections/subWindowTabs/Rating";
import Underlying from "@/components/sections/subWindowTabs/Underlying";
import TermStructure from "@/components/sections/subWindowTabs/TermStructure";
import PortfolioChart from "@/components/sections/subWindowTabs/PortfolioChart";
import Valuation from "@/components/sections/subWindowTabs/Valuation";
import Log from "@/components/sections/subWindowTabs/Log";
import { POPOUT_TAB_TYPE, TAB_TYPES } from "@/consts";

export default {
  name: "Popout",
  components: {
    PageHeader,
    BasicInfo,
    Cashflow,
    Curve,
    IssueRecords,
    Valuation,
    Rating,
    TermStructure,
    Counterparty,
    Underlying,
    Log
  },
  data() {
    return {
      tabType: null,
      TAB_TYPES
    };
  },
  mounted() {
    // load data from localStorage
    this.tabType = localStorage.getItem(POPOUT_TAB_TYPE);
  }
};
</script>
<style>
html {
  font-size: 14px;
}

.top-row {
  height: 40px;
  width: 100%;
}

.bottom-row {
  height: calc(100% - 40px);
  height: -ms-calc(100% - 40px);
  height: -moz-calc(100% - 40px);
  height: -webkit-calc(100% - 40px);
  width: 100%;
  background-color: #fff;
  color: #000;
  overflow: auto;
}
.content-wrap {
  width: 80%;
  margin: 0 auto;
  height: 100%;
}
</style>
