<template>
  <div class="home">
    <page-header />
    <div class="page">
      <div class="left clearfix">
        <left-nav @toggle="resizeMainBody"></left-nav>
      </div>
      <div class="right">
        <top-nav></top-nav>
        <main-body ref='mainBody'></main-body>
      </div>
    </div>
  </div>
</template>
<script>
import PageHeader from "@/components/pages/layouts/PageHeader";
import LeftNav from "@/components/pages/layouts/LeftNav";
import TopNav from "@/components/pages/layouts/TopNav";
import MainBody from "@/components/pages/layouts/MainBody";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import interceptor from "@/utils/interceptor";
import { convertListToMap, merge } from "@/utils";

const findName = (attributeList, tName, gName, aName) => {
  if (attributeList[tName]) return tName;
  if (attributeList[gName]) return gName;
  if (attributeList[aName]) return aName;
  return null;
};

export default {
  name: "Home",
  components: {
    PageHeader,
    LeftNav,
    TopNav,
    MainBody
  },
  created() {
    interceptor.logger.log = messages => {
      this.$store.commit("pushLog", messages || []);
    };
    // fetch views
    this.$api.request(endpoints.getViews).then(({ data }) => {
      this.$store.commit(
        "setViews",
        convertListToMap(data, "viewsName", "groups")
      );
    });

    //
    let getAttributes = this.$api.request(endpoints.getAttributes),
      getTemplates = this.$api.request(endpoints.getTemplates);
    Promise.all([getAttributes, getTemplates]).then(
      ([attributesResp, templateResp]) => {
        let attributes = convertListToMap(attributesResp.data, "attributeName"),
          templates = templateResp.data;
        templates.forEach(template => {
          let templateName = template.name;
          template.measures.forEach(measure => {
            let name = findName(
              attributes,
              templateName + "." + measure.name,
              measure.name
            );
            if (name) {
              let attribute = attributes[name];
              attribute.attributeName = measure.name;
              merge(measure, attribute);
            }
            if (measure.subMeasures.length) {
              measure.subMeasures.forEach(subMeasure => {
                let subName = findName(
                  attributes,
                  templateName + "." + measure.name + "." + subMeasure.name,
                  measure.name + "." + subMeasure.name,
                  subMeasure.name
                );
                if (subName) {
                  let subAttribute = attributes[subName];
                  subAttribute.attributeName = subMeasure.name;
                  merge(subMeasure, subAttribute);
                }
              });
            }
          });
        });
        this.$store.commit("setAttributes", attributes);
        this.$store.commit("setTemplates", convertListToMap(templates, "id"));
      }
    );
    this.$api
      .request(endpoints.getRegistryData, this.requestMarketDateParam)
      .then(({ data }) => {
        this.$store.commit("setMarketDate", data);
      });

    this.$api.request(endpoints.getDicts).then(({ data }) => {
      this.$store.commit("setDicts", convertListToMap(data, "label"));
    });
  },
  methods: {
    resizeMainBody() {
      this.$refs.mainBody.resize();
    }
  }
};
</script>
<style scoped>
.home {
  height: 100%;
  width: 100%;
}
.page {
  height: 100%;
}

.left {
  float: left;
  height: 100%;
}

.right {
  height: 100%;
  overflow: hidden;
}
</style>
