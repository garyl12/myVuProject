<template>
  <div class="main-body">
    <div class="view">
      <router-view ref="view"></router-view>
    </div>
    <div :style="loggerStyle">
      <logger @toggle="resizeView"/>
    </div>
  </div>
</template>
<script>
import Logger from "@/components/sections/Logger";

export default {
  name: "MainBody",
  components: {
    Logger
  },
  data() {
    return {
      richLogger: false
    };
  },
  computed: {
    loggerStyle() {
      let style = {};
      if (this.richLogger) {
        style = {
          position: "absolute",
          left: 0,
          bottom: 0,
          width: "100%"
        };
      }
      return style;
    }
  },
  methods: {
    resizeView(visible) {
      this.richLogger = visible;
    },
    resize() {
      this.$nextTick(function() {
        if (this.$refs.view.resize) this.$refs.view.resize();
      });
    }
  }
};
</script>
<style scoped>
.main-body {
  height: calc(100% - 40px);
  height: -ms-calc(100% - 40px);
  height: -moz-calc(100% - 40px);
  height: -webkit-calc(100% - 40px);
  background-color: #f9f9fb;
  color: #000;
  position: relative;
}
.view {
  height: calc(100% - 20px);
  height: -ms-calc(100% - 20px);
  height: -moz-calc(100% - 20px);
  height: -webkit-calc(100% - 20px);
}
</style>
