<template>
  <div class="container">
    <div class="header">
      <div class="date" :title="date">
        <i class="iconfont icon-calendar font-18"></i>
        <span>{{ date }}</span>
        <div class="separator"></div>
      </div>
      <div class="user" :title="currentUser.name" @click.stop="userPanelVisible = !userPanelVisible">
        <i class="iconfont icon-user font-18"></i>
      </div>
      <div class="panel-host" v-show="userPanelVisible" onselectstart="return false;">
        <div class="user-panel">
          <div class="operation" @click="clickHelp">
            {{ $t_('help') }}
          </div>
          <div class="operation" @click="logoutVisible=true">
            {{ $t_('logout') }}
          </div>
        </div>
        <div class="tail"></div>
      </div>
    </div>
    <el-dialog v-if="!inPopout" :title="$t_('Login_LogoutPanelTitle')" class="tiny" :visible="logoutVisible"
      :show-close="false" :close-on-press-escape="false">
			<span>{{$t_("Login_LogoutMessage")}}</span>
			<span slot="footer">
			  <el-button type="primary" @click="logout">{{ $t_("confirm") }}</el-button>
			  <el-button @click="logoutVisible=false">{{ $t_("cancel") }}</el-button>
			</span>
		</el-dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { parseToDate } from "@/utils";

export default {
  name: "PageHeader",
  props: ["inPopout"],
  data() {
    return {
      userPanelVisible: false,
      logoutVisible: false
    };
  },
  computed: {
    ...mapGetters({
      currentUser: "getUser",
      marketDate: "getMarketDate"
    }),
    date() {
      let d = new Date(this.marketDate);
      let year = d.getFullYear();
      let month = d.getMonth() + 1;
      let day = d.getDate();
      return [
        year,
        (month > 9 ? "" : "0") + month,
        (day > 9 ? "" : "0") + day
      ].join("/");
    }
  },
  mounted() {
    document.addEventListener("click", () => {
      this.userPanelVisible = false;
    });
  },
  methods: {
    clickHelp() {
      this.$router.push("/system/help");
      this.userPanelVisible = false;
    },
    logout() {
      let clearAll = () => {
        this.$store.commit("clearLogs");
        this.$store.commit("clearFrameCache");
        this.$router.push("/login");
      };
      this.$api.request(endpoints.logout).then(clearAll, clearAll);
    }
  }
};
</script>
<style scoped>
.container {
  height: 0;
  position: relative;
}
.header {
  position: absolute;
  background-color: #313949;
  top: 0;
  right: 0;
  width: 160px;
}
.date,
.user {
  position: relative;
  float: left;
  line-height: 40px;
  height: 40px;
  text-align: center;
  font-size: 14px;
}
.date {
  width: 110px;
}
.separator {
  position: absolute;
  top: 12px;
  right: -1px;
  height: 18px;
  width: 2px;
  background-color: #fff;
}
.user {
  text-align: center;
  width: 40px;
  cursor: pointer;
}
.user:hover {
  color: #c39f5a;
}
.panel-host {
  position: relative;
}
.user-panel {
  position: absolute;
  z-index: 1;
  top: 36px;
  right: 10px;
  width: 100px;
  height: 48px;
  background-color: #4e586f;
  box-shadow: 0 1px 3px 1px #777;
  border-radius: 2px;
  text-align: center;
}
.tail {
  position: absolute;
  top: 24px;
  right: 24px;
  border: 6px solid transparent;
  border-bottom: 6px solid #4e586f;
}
.operation {
  height: 24px;
  line-height: 24px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  cursor: pointer;
}
.operation:hover {
  background-color: #6c7790;
}
</style>
