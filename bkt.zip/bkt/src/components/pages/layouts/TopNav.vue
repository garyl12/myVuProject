<template>
	<div class="top-nav">
		<ul class="top-nav-box clearfix">
			<li class="top-nav-item" v-for="(item,index) in topNavShowList" :key="index">
				<div class="close-icon" @click="closeTab(item,index)">
					<i class="iconfont icon-close1"></i>
				</div>
				<div :class="['tab-title',{'active':item.id===currentNav.id}]" @click="routerTo(item)" :title="$t_(item.name)">{{$t_(item.name)}} </div>
			</li>
			<li v-show="exceedList.length" @mouseenter="isExceedShow = true" @mouseleave="isExceedShow = false" class="dropdown-icon">
				<span>
					<i class="iconfont icon-ellipsis"></i>
				</span>
			</li>
		</ul>
		<div class="exceed-tab-box" v-show="isExceedShow" @mouseenter="isExceedShow = true" @mouseleave="isExceedShow = false">
			<ul>
				<li class="" v-for="(item,index) in exceedList" @click="jumpTo(item, topNavShowList.length + index)" :key="index" :title="$t_(item.name)">
					{{$t_(item.name)}}
				</li>
			</ul>
		</div>
	</div>
</template>
<script>
import { mapGetters } from "vuex";

export default {
  name: "TopNav",
  data() {
    return {
      isExceedShow: false
    };
  },
  computed: {
    topNavShowList: function() {
      return this.visitedNavs.slice(0, 8);
    },
    exceedList: function() {
      return this.visitedNavs.slice(8);
    },
    ...mapGetters({
      allNavs: "getAllNavs",
      currentNav: "getCurrentNav",
      visitedNavs: "getVisitedNavs"
    })
  },
  watch: {
    $route() {
      this.restoreNav();
    }
  },
  mounted() {
    this.restoreNav();
  },
  methods: {
    restoreNav() {
      // when user is changing URL directly and navigating page,
      // code should detect it and assign navigation properly
      if (this.currentNav.href === this.$route.path) return;
      for (var i = 0; i < this.allNavs.length; i++) {
        if (this.$route.path === this.allNavs[i].href) {
          this.$store.commit("pushVisitedNavs", this.allNavs[i]);
          break;
        }
      }
      if (this.$route.meta.notInMenu) {
        this.$store.commit("pushVisitedNavs", {
          id: this.$route.params.id,
          name: this.$route.query.name,
          href: this.$route.path,
          query: this.$route.query
        });
      }
    },
    jumpTo(item, index) {
      this.isExceedShow = false;
      this.$router.push({ path: item.href, query: item.query });
      this.$store.commit("topNavAtIndex", index);
    },
    routerTo(item) {
      this.$router.push({ path: item.href, query: item.query });
      this.$store.commit("setCurrentNav", item);
    },
    closeTab(item, index) {
      this.$store.commit("clearFrameCache", item.href);
      this.$store.commit("removeNavAtIndex", index);
      this.$router.push({
        path: this.currentNav.href,
        query: this.currentNav.query
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.top-nav {
  height: 40px;
  background-color: #313949;
  position: relative;
  margin-right: 160px;
  ul.top-nav-box {
    width: 100%;
    li {
      float: left;
      width: 12%;
      margin-top: 10px;
      border-top-left-radius: 2px;
      border-top-right-radius: 2px;
      height: 30px;
      position: relative;
      .tab-title {
        height: 30px;
        line-height: 30px;
        padding: 0 24px 0 10px;
        margin-right: 2px;
        cursor: pointer;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        background-color: #575e6b;
        border-top-left-radius: 2px;
        border-top-right-radius: 2px;
      }
      .close-icon {
        position: absolute;
        top: 0;
        right: 4px;
        cursor: pointer;
        height: 30px;
        line-height: 30px;
        color: #ccc;
        .iconfont:hover {
          color: #333;
        }
      }
      .active {
        background-color: #f9f9fb;
        color: #000;
      }
    }
    li.dropdown-icon {
      float: right;
      width: 4%;
      background: transparent;
      text-align: center;
      height: 28px;
      span {
        display: inline-block;
        font-size: 23px;
        color: #cccccc;
      }
    }
  }
  div.exceed-tab-box {
    position: absolute;
    right: 0;
    top: 30px;
    z-index: 1;
    ul {
      border-radius: 4px;
      padding: 4px 0;
      overflow-y: auto;
      background-color: #383f52;
      box-shadow: 0 1px 3px 1px #777;
      max-height: 600px;
      color: #fff;
      li {
        height: 30px;
        line-height: 30px;
        padding: 0 15px;
        white-space: nowrap;
        cursor: pointer;
      }
      li:hover {
        background-color: #6c7790;
        color: #333;
      }
    }
  }
}
</style>