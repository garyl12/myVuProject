<template>
	<div :class="['left-nav', {'left-nav-fold': !isExpanded}]">
    <div class="logo">
      <img src="../../../static/img/logo.png" height="100%" v-show="isExpanded">
			<div class="menu-switcher" @click="toggleMenu">
				<i :class="['iconfont icon-menu', {'transform': !isExpanded}]"></i>
			</div>
    </div>
		<div :class="['icon-column', 'clearfix', {'icon-column-mini': hasMenuSelected}]">
			<div :class="['menu',{'active': index === currentIndex}]" v-for="(item,index) in menus" :key="index" @click="showMenu(item, index)" :title="$t_(item.name)">
				<i :class="['iconfont', 'menu-icon-big', item.icon]"></i>
				<div class="menu-name" v-show="!hasMenuSelected">{{$t_(item.name)}}</div>
			</div>
      <div style="border-top:1px solid #313949;height:0px;"></div>
		</div>
		<div class="menu-column" v-show="hasMenuSelected">
			<div class="menu-title">
        <span>{{$t_(currentMainMenu.name)}}</span>
        <i class="iconfont icon-menuback" @click="resetMenu" :title="$t_('back')"></i>
      </div>
      <div class="menu-content">
        <div v-for="(item, index) in currentMainMenu.childs" :key="index">
          <div :class="['menu-item-lvl1','menu-item-name', {'active-nav': item.id === currentNav.id}]" @click="navigate(item)" :title="$t_(item.name)">
            <span @click.stop="toggleNav(item)" class="menu-icon">
              <i v-show="item.childs&&!expandingMapping[item.id]" class="iconfont menu-icon-add"></i>
              <i v-show="item.childs&&expandingMapping[item.id]" class="iconfont menu-icon-minus"></i>
            </span>
            <span>{{$t_(item.name)}}</span>
          </div>
          <div v-if="item.childs" v-show="expandingMapping[item.id]">
             <div v-for="(innerItem, index) in item.childs" :key="index">
              <div :class="['menu-item-lvl2','menu-item-name', {'active-nav': innerItem.id === currentNav.id}]" @click="navigate(innerItem)" :title="$t_(innerItem.name)">
                <span @click.stop="toggleNav(innerItem)" class="menu-icon">
                  <i v-show="innerItem.childs&&!expandingMapping[innerItem.id]" class="iconfont menu-icon-add"></i>
                  <i v-show="innerItem.childs&&expandingMapping[innerItem.id]" class="iconfont menu-icon-minus"></i>
                </span>
                <span>{{$t_(innerItem.name)}}</span>
              </div>
              <div v-if="innerItem.childs" v-show="expandingMapping[innerItem.id]">
                <div v-for="(deepItem, innerIndex) in innerItem.childs" :key="innerIndex" @click="navigate(deepItem)"
                  :class="['menu-item-lvl3','menu-item-name',{'active-nav': deepItem.id === currentNav.id}]" :title="$t_(deepItem.name)">
                  <span>{{$t_(deepItem.name)}}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
		</div>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { convertListToMap, merge } from "@/utils";

export default {
  name: "LeftNav",
  computed: {
    ...mapGetters({
      currentNav: "getCurrentNav",
      currentUser: "getUser",
      mapping: "getMapping"
    })
  },
  watch: {
    currentNav() {
      let navPath = [],
        parentNav = this.currentNav.parentId;
      while (parentNav) {
        navPath.push(parentNav);
        if (this.mapping[parentNav].toUpperCase() === "ROOT") {
          for (let i = 0; i < this.menus.length; i++) {
            if (this.menus[i].id === parentNav) {
              this.currentMainMenu = this.menus[i];
              this.hasMenuSelected = true;
              this.currentIndex = i;
              break;
            }
          }
          break;
        }
        parentNav = this.mapping[parentNav];
      }
      for (let i = navPath.length - 1; i >= 0; i--) {
        let menusEachLevel = this.currentMainMenu.childs;
        for (let j = 0; j < menusEachLevel.length; j++) {
          if (menusEachLevel[j].id === navPath[i]) {
            this.expandingMapping[menusEachLevel[j].id] = true;
            menusEachLevel = menusEachLevel[j].childs;
            break;
          }
        }
      }
    }
  },
  data() {
    return {
      isExpanded: true,
      showSystemMenu: true,
      hasMenuSelected: false,
      currentMainMenu: {
        name: "",
        childs: []
      },
      expandingMapping: {},
      currentIndex: -1,
      menus: []
    };
  },
  methods: {
    toggleMenu() {
      this.isExpanded = !this.isExpanded;
      this.$emit("toggle");
    },
    showMenu(menu, index) {
      this.currentMainMenu = menu;
      this.hasMenuSelected = true;
      this.currentIndex = index;
      this.isExpanded = true;
      this.$emit("toggle");
    },
    toggleNav(item) {
      if (typeof this.expandingMapping[item.id] === "undefined") {
        this.$set(this.expandingMapping, item.id, true);
        return;
      }
      this.expandingMapping[item.id] = !this.expandingMapping[item.id];
    },
    resetMenu() {
      this.currentMainMenu = {
        name: "",
        childs: []
      };
      this.hasMenuSelected = false;
    },
    navigate(navigator) {
      if (navigator.href) {
        this.$store.commit("pushVisitedNavs", navigator);
        this.$router.push(navigator.href);
      }
    },
    processMenu(
      menus,
      mapping,
      menuArr,
      dataFilterArr = [],
      templateFilterArr = []
    ) {
      for (var i = 0; i < menus.length; i++) {
        mapping[menus[i].id] = menus[i].parentId;
        menuArr.push(menus[i]);
        if (menus[i].childs) {
          let tempDataFilterArr = [],
            tempTemplateFilterArr = [];
          this.processMenu(
            menus[i].childs,
            mapping,
            menuArr,
            tempDataFilterArr,
            tempTemplateFilterArr
          );
          menus[i].dataFilter = tempDataFilterArr.deduplicate().join(";");
          menus[i].templateFilter = tempTemplateFilterArr
            .deduplicate()
            .join(";");
        }
        (menus[i].dataFilter || "").split(";").forEach(filter => {
          if (filter) {
            dataFilterArr.push(filter);
          }
        });
        (menus[i].templateFilter || "").split(";").forEach(filter => {
          if (filter) {
            templateFilterArr.push(filter);
          }
        });
      }
    },
    setCurrentNav(path, menus) {
      // set current navigator after refreshing page

      menus.forEach(menu => {
        if (path === menu.href) {
          this.$store.commit("pushVisitedNavs", menu);
        }
      });
    },
  },
  mounted() {
    this.$api
      .request(endpoints.getMenu, {
        userId: this.currentUser.id,
        systemId: "MAS"
      })
      .then(({ data }) => {
        this.menus = data;
        var mapping = {};
        var menuArr = [];
        this.processMenu(data, mapping, menuArr);
        this.$store.commit("setMapping", mapping);
        this.$store.commit("setAllNavs", menuArr);
        this.setCurrentNav(this.$route.path, menuArr);
      });
  }
};
</script>

<style scoped>
.left-nav {
  width: 260px;
  height: 100%;
}
.logo {
  height: 40px;
}
.left-nav-fold {
  width: 40px;
  overflow: hidden;
}
.icon-column {
  float: left;
  height: calc(100% - 40px);
  height: -ms-calc(100% - 40px);
  height: -moz-calc(100% - 40px);
  height: -webkit-calc(100% - 40px);
  width: 260px;
  background-color: #3c4559;
}
.icon-column-mini {
  width: 40px;
  text-align: center;
  overflow: hidden;
}
.menu-switcher {
  height: 40px;
  width: 40px;
  line-height: 40px;
  text-align: center;
  float: right;
}
.menu-switcher i {
  display: inline-block;
  font-size: 16px;
  cursor: pointer;
  width: 40px;
  color: #fff;
}
.transform {
  transform: rotateZ(180deg);
  -ms-transform: rotateZ(180deg);
  -moz-transform: rotateZ(180deg);
  -webkit-transform: rotateZ(180deg);
}
.menu {
  cursor: pointer;
  height: 40px;
  border-top: 1px solid #313949;
  border-bottom: 1px solid #485266;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.menu:hover {
  background-color: #6c7790;
}
.menu-name {
  overflow: hidden;
  white-space: nowrap;
}
.menu-icon-big {
  font-size: 16px;
  float: left;
  height: 40px;
  width: 40px;
  text-align: center;
  line-height: 40px;
  color: #fff;
}
.active {
  background-color: #4e586f;
}
.menu div {
  height: 40px;
  line-height: 40px;
  font-size: 14px;
}
.menu-column {
  height: calc(100% - 40px);
  height: -ms-calc(100% - 40px);
  height: -moz-calc(100% - 40px);
  height: -webkit-calc(100% - 40px);
  background-color: #4e586f;
  border-top: 1px solid #313949;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  overflow: auto;
}
.menu-title {
  height: 40px;
  line-height: 40px;
  padding-left: 10px;
  padding-right: 36px;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  position: relative;
}
.menu-title i {
  position: absolute;
  top: 0;
  right: 3px;
  height: 36px;
  line-height: 36px;
  width: 30px;
  text-align: center;
  font-size: 16px;
  color: #fff;
  cursor: pointer;
}
.menu-item-lvl1 {
  height: 30px;
  line-height: 30px;
  padding-left: 10px;
  cursor: pointer;
}
.menu-item-lvl2 {
  padding-left: 30px;
  cursor: pointer;
  height: 30px;
  line-height: 30px;
}
.menu-item-lvl3 {
  padding-left: 60px;
  cursor: pointer;
  height: 30px;
  line-height: 30px;
}
.menu-item-lvl1:hover,
.menu-item-lvl2:hover,
.menu-item-lvl3:hover {
  background-color: #6c7790;
}
.menu-item-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.active-nav {
  background-color: #6c7790;
}
.menu-icon {
  display: inline-block;
  width: 12px;
}
.menu-icon-add,
.menu-icon-minus {
  font-size: 12px;
}
.menu-icon-add::after {
  content: "\e602";
}
.menu-icon-add:hover::after {
  content: "\e618";
}
.menu-icon-minus::after {
  content: "\e730";
}
.menu-icon-minus:hover::after {
  content: "\e7d0";
}
</style>