<template>
	<div class="login-bg">
		<div class="top-logo">
			<img src="../../static/img/top-logo.png" alt="">
		</div>
		<div class="bot-logo">
			<img src="../../static/img/Bucketing.png" alt="">
			<img src="../../static/img/Bucketing-system.png" alt="" class="system-name">
		</div>
    <!-- TODO: remove before release -->
    <div class="server-ip-input">
      <input type="text" v-model="serverAddress" @blur="persistServerIP" placeholder="http://localhost:8080">
    </div>
		<div class="login-form">
			<div class="login-header">
				<div :class="['login-field', {active: usernameActive}]">
					<i class="iconfont icon-loginname"></i>
					<span></span>
					<input type="text" :placeholder="$t_('login_username_placeholder')" @focus="activateField(true)" @blur="deactivateField(true)" v-model="username" />
				</div>
				<div class="password" :class="['login-field', {active: passwordActive}]">
					<i class="iconfont icon-password"></i>
					<span></span>
					<input type="password" :placeholder="$t_('login_password_placeholder')" @focus="activateField(false)" @blur="deactivateField(false)" v-model="password" @keydown.enter="login" />
				</div>
				<div class="login-opt clearfix">
					<div class="language">
						<input type="radio" name="language" id="chn" v-model="isChn" :value="true" />
						<label for='chn'>{{$t_("login_language_chn")}}</label>
						<input type="radio" name="language" id="eng" v-model="isChn" :value="false" />
						<label for='eng'>{{$t_("login_language_eng")}}</label>
					</div>
					<div class="remember">
						<input type="checkbox" id="remember-login" v-model="needRememberLogin" :value="true" />
						<label for="remember-login">{{$t_("login_remember_username")}}</label>
					</div>
				</div>
			</div>
			<div class="login-footer">
				<div class="login-btn" @click="login">{{$t_("login_login")}}</div>
			</div>
		</div>
    <alert :config="loginAlert" />
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { LOCALE, Languages } from "@/consts";
import Alert from "@/components/common/Alert";

export default {
  name: "Login",
  components: { Alert },
  data() {
    return {
      username: "",
      usernameActive: false,
      password: "",
      passwordActive: false,
      isChn: true,
      needRememberLogin: true,
      loginAlert: {
        visible: false,
        title: "warning",
        message: "",
        buttons: [
          {
            title: "ok",
            callback: () => {
              this.loginAlert.visible = false;
            }
          }
        ]
      },
      serverAddress: ""
    };
  },
  watch: {
    isChn(val) {
      this.$i18n.locale = val ? Languages.zhCN : Languages.enUS;
      localStorage.setItem(LOCALE, this.$i18n.locale);
    }
  },
  mounted() {
    this.isChn =
      (localStorage.getItem(LOCALE) || Languages.zhCN) === Languages.zhCN;
    let userName = localStorage.getItem("userName");
    let password = localStorage.getItem("password");
    this.username = userName;
    this.password = password;
    if (this.$api.authenticated()) {
      this.$router.push("/system/help");
    }
    this.serverAddress = localStorage.getItem("baseUrl") || "";
    this.$store.commit("clearLogs");
    this.$store.commit("clearFrameCache");
  },
  methods: {
    persistServerIP() {
      localStorage.setItem("baseUrl", this.serverAddress);
    },
    login() {
      if (!this.username) {
        this.loginAlert.visible = true;
        this.loginAlert.message = "login_missing_username";
        return;
      }
      if (!this.password) {
        this.loginAlert.visible = true;
        this.loginAlert.message = "login_missing_password";
        return;
      }
      this.$api
        .request(endpoints.login, {
          userNo: this.username,
          password: this.password,
          LOCAL_LOCALE_KEY: this.isChn ? "zh" : "en"
        })
        .then(({ data, messages }) => {
          if (data) {
            if (this.needRememberLogin) {
              localStorage.setItem("userName", this.username);
              localStorage.setItem("password", this.password);
            } else {
              localStorage.removeItem("userName");
            }
            this.$store.commit("setUser", data);
            if (this.$router.currentRoute.query.redirect) {
              //redirect to previous page
              this.$router.push(this.$router.currentRoute.query.redirect);
            } else {
              this.$router.push("/system/help");
            }
          } else if (messages.length) {
            this.loginAlert.message = messages[0].msg;
            this.loginAlert.visible = true;
          }
        });
    },
    activateField(flag) {
      if (flag) {
        this.usernameActive = true;
      } else {
        this.passwordActive = true;
      }
    },
    deactivateField(flag) {
      if (flag) {
        this.usernameActive = false;
      } else {
        this.passwordActive = false;
      }
    }
  }
};
</script>

<style scoped>
.login-bg {
  background: url(../../static/img/body-bg.png) no-repeat;
  background-size: 100% 100%;
  width: 100%;
  height: 100%;
  position: relative;
  background-color: #6fdcf9;
}
.server-ip-input {
  position: absolute;
  top: 0;
  right: 0;
  height: 30px;
}
.login-form {
  position: absolute;
  top: 19.37%;
  right: 13.16%;
  width: 420px;
  height: 490px;
  background: url(../../static/img/load-bg.png) no-repeat;
  background-size: 100% 100%;
}

.login-header {
  margin-top: 74px;
}

.login-field {
  margin: 0 auto;
  width: 374px;
  padding: 7px 0;
  line-height: 40px;
  background: url(../../static/img/input-bg.png);
  background-size: 100% 100%;
}
.login-field.password {
  margin-top: 20px;
}

.login-field i {
  float: left;
  line-height: 56px;
  font-size: 26px;
  color: #808080;
  margin: 0 22px;
}

.login-field span {
  height: 40px;
  border-left: 2px solid #808080;
  margin-right: 22px;
  padding: 8px 0;
}

.login-field input {
  border: 0;
  padding: 8px 0;
  color: #808080;
  height: 40px;
  width: 260px;
  background: transparent;
  font-size: 22px;
  outline: none;
}

.login-opt {
  margin: 0 auto;
  width: 350px;
  padding: 12px 12px;
}

.login-opt .remember {
  float: right;
}

.login-opt .language {
  float: left;
}

.login-footer {
  width: 374px;
  margin: 80px auto 0;
  cursor: pointer;
  text-align: center;
  background: url(../../static/img/login-In.png) no-repeat;
  background-size: 100% 100%;
}

.login-btn {
  height: 75px;
  font-size: 22px;
  color: #fff;
  line-height: 75px;
}

.active {
  color: #fff;
}

.active span {
  border-left-color: #fff;
}

.active i,
.active input {
  color: #fff;
}
.top-logo {
  position: absolute;
  left: 6.1%;
  top: 4.1%;
}
.bot-logo {
  position: absolute;
  bottom: 0;
  width: 680px;
  left: 6.1%;
  top: 69%;
}
.bot-logo .system-name {
  margin-top: 50px;
}
</style>