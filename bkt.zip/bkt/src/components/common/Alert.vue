<template>
  <el-dialog
    width="30%"
    class="dark"
    :title="$t_(config.title)"
    :visible="config.visible"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    :append-to-body="true"
    >
    <span>{{$t_(config.message)}}</span>
    <div v-if="!config.message&&config.logs">
      <div v-for="(log, index) in config.logs"
        :key="index" class="log">
        <div class="log-level info" v-if="log.type===LOG_LEVEL.INFO">
          <i class="iconfont icon-log-info"></i>
        </div>
        <div class="log-level warning" v-else-if="log.type===LOG_LEVEL.WARNING">
          <i class="iconfont icon-log-warning"></i>
        </div>
        <div class="log-level error" v-else-if="log.type===LOG_LEVEL.ERROR">
          <i class="iconfont icon-log-error"></i>
        </div>
        <span :title="log.msg || log ">{{ log.msg || log }}</span>
      </div>
    </div>
    <span slot="footer">
      <el-button
        v-for="(button,index) in config.buttons"
        :key="index"
        :title="$t_(button.title)"
        @click="handleClick(button)"
        >
        {{$t_(button.title)}}
      </el-button>
    </span>
  </el-dialog>
</template>

<script>
const LOG_LEVEL = {
  INFO: "info",
  WARNING: "warning",
  ERROR: "error",
  EXCEPTION: "exception"
};

export default {
  name: "Alert",
  props: {
    config: {
      required: true,
      type: Object
    }
  },
  computed: {
    LOG_LEVEL() {
      return LOG_LEVEL;
    }
  },
  methods: {
    handleClick: function(button) {
      if (button.callback) {
        button.callback();
      }
    }
  }
};
</script>

<style scoped>
.log {
  line-height: 24px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.log-level {
  float: left;
  width: 20px;
  height: 24px;
  text-align: center;
}
.log-level.error {
  color: red;
}
.log-level.warning {
  color: yellow;
}
.log-level.info {
  color: #fff;
}
</style>
