<template>
  <div
    :class="['icon-btn',{'icon-btn-active':active}]"
    @click="handleClick"
    :title="$t_(text)">
    <i :class="['iconfont','font-18',icon]"></i>
  </div>
</template>

<script>
export default {
  name: "IconButton",
  props: {
    icon: {
      type: String,
      required: true
    },
    text: {
      type: String,
      required: true
    },
    active: {
      type: Boolean,
      required: true
    },
    callback: {
      type: Function,
      required: true
    }
  },
  methods: {
    handleClick() {
      if (this.active) this.callback();
    }
  }
};
</script>

<style scoped>
.icon-btn {
  margin: 3px 0;
  float: left;
  width: 30px;
  height: 24px;
  line-height: 24px;
  cursor: not-allowed;
  color: grey;
  text-align: center;
}
.icon-btn-active {
  cursor: pointer;
  color: #fff;
}
.icon-btn-active:hover {
  color: #c39f5a;
}
</style>