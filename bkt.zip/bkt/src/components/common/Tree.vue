<template>
  <div onselectstart="return false"
    :class="[{'tree-root':!parent},{'clearfix':!parent},{'tree-sub':parent}]"
    >
    <div
      v-for="(item,index) in data"
      :key="index"
      class="tree-group"
      >
      <div>
        <i class="iconfont icon-tree-expand btn" @click="expand(item)" v-show="!plain&&!item._expanded"></i>
        <i class="iconfont icon-skewTriangle btn" @click="fold(item)" v-show="!plain&&item._expanded&&item[childAttribute]&&item[childAttribute].length"></i>
        <i class="iconfont icon-dot" v-show="plain||item._expanded&&(!item[childAttribute]||!item[childAttribute].length)"></i>
        <checkbox
          v-if="allowMulti"
          :indeterminate="item._indeterminate"
          :checked="item._checked"
          v-model="item._checked"
          @click="checkItem(item)"
          />
        <span
          :title="getLabel(item)"
          :class="['tree-label',{'selected':item._selected}]"
          @click="bubbleClick(item)"
          >{{getLabel(item)}}</span>
      </div>
      <div
        v-show="item._expanded">
        <tree
          v-if="item[childAttribute]"
          :data="item[childAttribute]"
          :parent="item"
          :child-attribute="childAttribute"
          :label-template="labelTemplate"
          :allow-multi="allowMulti"
          @load-children="bubbleLoad"
          @click="bubbleClick"
          @check="bubbleCheck"
          />
      </div>
    </div>
    <div class="no-data" v-show="!parent&&!data.length">{{$t_('no_data')}}</div>
  </div>
</template>

<script>
import Checkbox from "./Checkbox";

export default {
  name: "Tree",
  components: { Checkbox },
  props: {
    data: {
      required: true,
      type: Array
    },
    parent: Object,
    childAttribute: {
      required: true,
      type: String
    },
    labelTemplate: {
      required: true,
      type: String
    },
    allowMulti: Boolean,
    plain: [Boolean, String]
  },
  data() {
    return {
      selectedItem: null
    };
  },
  computed: {
    levelStatus() {
      // allChecked: true, allUnchecked: false, emit: check
      // allChecked: false, allUnchecked: true, emit: uncheck
      // allChecked: false, allUnchecked: false, won't emit
      // allChecked: true, allUnchecked: true, won't happen
      let allChecked = true,
        allUnchecked = true,
        hasIndeterminate = false;
      this.data.forEach(child => {
        allChecked &= child._checked;
        allUnchecked &= !child._checked;
        hasIndeterminate |= child._indeterminate;
      });
      return {
        allChecked,
        allUnchecked,
        hasIndeterminate
      };
    }
  },
  mounted() {
    if (this.parent && this.parent._checked) {
      this.data.forEach(item => {
        this.$set(item, "_checked", true);
      });
    }
  },
  methods: {
    getLabel(item) {
      return this.labelTemplate.replace(/\${\w+}/g, function(match) {
        let key = match.replace("${", "").replace("}", "");
        return item[key];
      });
    },
    expand(item) {
      if (this.plain) return;
      this.$set(item, "_expanded", true);
      if (!item[this.childAttribute]) {
        this.$emit("load-children", item);
      }
    },
    fold(item) {
      if (this.plain) return;
      item._expanded = false;
    },
    selectItem(item) {
      if (this.selectedItem) {
        this.selectedItem._selected = false;
      }
      this.$set(item, "_selected", true);
      this.selectedItem = item;
    },
    checkItem(item) {
      if (!this.allowMulti) return;
      this.$set(item, "_indeterminate", false);
      this.$nextTick(function() {
        this.processChildren(item, item._checked);
        this.bubbleCheck(item);
      });
    },
    bubbleCheck(payload) {
      if (this.parent) {
        if (this.levelStatus.allChecked) {
          this.$set(this.parent, "_checked", true);
          if (this.levelStatus.hasIndeterminate) {
            this.$set(this.parent, "_indeterminate", true);
          } else {
            this.$set(this.parent, "_indeterminate", false);
          }
        } else if (this.levelStatus.allUnchecked) {
          this.$set(this.parent, "_checked", false);
          if (this.levelStatus.hasIndeterminate) {
            this.$set(this.parent, "_indeterminate", true);
          } else {
            this.$set(this.parent, "_indeterminate", false);
          }
        } else {
          this.$set(this.parent, "_indeterminate", true);
        }
        this.$emit("check", payload);
      }
    },
    processChildren(item, checked) {
      let children = item[this.childAttribute];
      if (children && children.length) {
        // check / uncheck every child
        children.forEach(child => {
          if (checked) {
            this.$set(child, "_checked", true);
          } else {
            child._checked = false;
          }
          // process its own children
          this.processChildren(child, checked);
        });
      }
    },
    bubbleLoad(payload) {
      this.$emit("load-children", payload);
    },
    bubbleClick(payload) {
      this.$emit("click", payload);
      if (!this.parent) {
        this.selectItem(payload);
      }
    },
    collectScope() {
      if (!this.allowMulti) return;
      let checkedItems = [];
      this.collectInner(this.data, this.childAttribute, checkedItems);
      return checkedItems;
    },
    collectInner(items, childAttribute, checkedItems) {
      items.forEach(item => {
        if (item._checked) checkedItems.push(item);
        let children = item[childAttribute];
        if (children && children.length) {
          this.collectInner(children, childAttribute, checkedItems);
        }
      });
    }
  }
};
</script>

<style scoped>
.tree-root {
  float: left;
}
.tree-sub {
  margin-left: 18px;
}
.tree-group {
  white-space: nowrap;
  line-height: 20px;
}
.btn {
  cursor: pointer;
}
.btn:hover {
  color: #409eff;
}
.tree-label {
  cursor: pointer;
}
.tree-label.selected {
  background-color: #ccc;
}
.tree-label:hover {
  background-color: #ccc;
}
.no-data {
  padding-left: 5px;
  color: #6f7180;
  cursor: default;
}
</style>