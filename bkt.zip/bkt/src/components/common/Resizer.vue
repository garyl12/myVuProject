<template>
  <div class="h-drag" onselectstart="return false;" @mousedown.stop="bindDragX($event)"  v-if="axis==='x'||axis==='X'">
    <div class="mid" onselectstart="return false;"></div>
    <div class="h-drag-shadow" onselectstart="return false;" ref="xShadow">
      <div onselectstart="return false;">
      </div>
    </div>
  </div>
  <div class="v-drag" onselectstart="return false;" @mousedown.stop="bindDragY($event)" v-else>
    <div class="mid" onselectstart="return false;"></div>
    <div class="v-drag-shadow" onselectstart="return false;" ref="yShadow">
      <div onselectstart="return false;">
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Resizer",
  props: {
    axis: {
      required: true,
      type: String,
      validator: function(value) {
        return value.toLowerCase() === "x" || value.toLowerCase() === "y";
      }
    }
  },
  methods: {
    bindDragX(e) {
      let originalX = e.clientX,
        currentX = e.clientX,
        offsetX = 0,
        xShadow = this.$refs.xShadow,
        mouseMoveHandler = event => {
          offsetX = event.clientX - originalX;
          xShadow.style.right = -offsetX + "px";
          xShadow.style.display = "";
        },
        mouseUpHandler = () => {
          document.removeEventListener("mousemove", mouseMoveHandler, false);
          document.removeEventListener("mouseup", mouseUpHandler, false);
          xShadow.style.display = "none";
          this.$emit("resize", offsetX);
        };
      document.addEventListener("mousemove", mouseMoveHandler, false);
      document.addEventListener("mouseup", mouseUpHandler, false);
    },
    bindDragY(e) {
      let originalY = e.clientY,
        currentY = e.clientY,
        offsetY = 0,
        yShadow = this.$refs.yShadow,
        mouseMoveHandler = event => {
          offsetY = event.clientY - originalY;
          yShadow.style.top = offsetY + "px";
          yShadow.style.display = "";
        },
        mouseUpHandler = () => {
          document.removeEventListener("mousemove", mouseMoveHandler, false);
          document.removeEventListener("mouseup", mouseUpHandler, false);
          yShadow.style.display = "none";
          this.$emit("resize", offsetY);
        };
      document.addEventListener("mousemove", mouseMoveHandler, false);
      document.addEventListener("mouseup", mouseUpHandler, false);
    }
  }
};
</script>
