<template>
  <div class="wrapper clearfix">
    <div class="container" ref="container" v-show="data.length"
      onselectstart="return false">
      <div class="first-row clearfix" v-if="keyRow">
        <div class="first-row-content" :style="{ width: width + 'px' }" ref="firstRow" >
          <div class="key-cell">{{ $t_(keyRow) }}</div>
          <div v-for="(d, index) in data" :key="index" class="cell" :style="{ width: columnWidth + 'px' }"
            :title="(isDataBean ? d[keyRow] : (d.attributes[keyRow] || { value: '--' }).value ) | formatDisplay(keyRowFormat)">
            <span>{{ (isDataBean ? d[keyRow] : (d.attributes[keyRow] || { value: '--' }).value ) | formatDisplay(keyRowFormat) }}</span>
          </div>
        </div>
      </div>
      <div class="body" :style="{ height: this.bodyHeight + 'px'}" @scroll="scrollX" ref="body">
        <div v-for="(row, rowIndex) in rows" :key="rowIndex" v-if="!keyRow || keyRow !== row"
          :class="['row', 'clearfix', {'first-row': !keyRow && !rowIndex}]" :style="{ width: width + 'px' }">
            <div class="key-cell" :title="$t_(row.displayName || row.attributeName) | decorateFieldName(row.displayFormat)">
              {{ $t_(row.displayName || row.attributeName) | decorateFieldName(row.displayFormat) }}
            </div>
            <div v-for="(d, dIndex) in data" :key="dIndex" class="cell" :style="{ width: columnWidth + 'px' }"
              :title="(isDataBean ? d[row.attributeName] : (d.attributes[row.attributeName] || { value: '--' }).value ) | formatDisplay(row.displayFormat)">
              <span>{{ (isDataBean ? d[row.attributeName] : (d.attributes[row.attributeName] || { value: '--' }).value ) | formatDisplay(row.displayFormat) }}</span>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
const KEY_COLUMN_WIDTH = 100;
const COLUMN_MAIN_WIDTH = 100;
const ROW_HEIGHT = 20;
const MARGIN = 10;
import { clone } from "@/utils";
import { SIZE } from "@/consts";

export default {
  name: "VerticalGrid",
  props: {
    data: {
      type: Array,
      required: true
    },
    rows: {
      type: Array,
      required: true
    },
    keyRow: String,
    isDataBean: Boolean
  },
  data() {
    return {
      columnWidth: 0,
      isOverflowY: false,
      bodyHeight: 0,
      resizeHandler: () => {
        this.resize();
      }
    };
  },
  computed: {
    width() {
      let width = 0;
      width += KEY_COLUMN_WIDTH;
      width += this.columnWidth * this.data.length;
      return width;
    },
    keyRowFormat() {
      let format = null;
      if (this.keyRow) {
        this.rows.forEach(row => {
          if (row.attributeName === this.keyRow) {
            format = row.format;
          }
        });
      }
      return format;
    }
  },
  watch: {
    data() {
      this.resize();
    },
    rows() {
      this.resize();
    }
  },
  mounted() {
    this.checkOverflowY();
    this.calculateWidth();
    this.bindWindowResize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    bindWindowResize() {
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.resizeHandler);
    },
    scrollX() {
      if (this.keyRow) {
        this.$refs.firstRow.style.left = -this.$refs.body.scrollLeft + "px";
      }
    },
    calculateWidth() {
      let containerWidth = this.$refs.container.clientWidth;
      let columnWidth =
        (containerWidth -
          KEY_COLUMN_WIDTH -
          (this.isOverflowY ? SIZE.SCROLL_BAR_WIDTH : 0)) /
        this.data.length;
      this.columnWidth = Math.max(columnWidth, COLUMN_MAIN_WIDTH);
    },
    checkOverflowY() {
      this.isOverflowY =
        this.$refs.container.clientHeight - MARGIN * 2 <
        this.rows.length * ROW_HEIGHT;
      this.bodyHeight =
        this.$refs.container.clientHeight - (this.keyRow ? ROW_HEIGHT : 0);
    },
    resize() {
      this.$nextTick(function() {
        this.checkOverflowY();
        this.calculateWidth();
      });
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.wrapper {
  padding: 10px;
  height: 100%;
  overflow: hidden;
}
.container {
  height: 100%;
  box-shadow: 0 1px 3px 1px #777;
}
.body {
  overflow: auto;
}
.key-cell,
.cell {
  float: left;
  text-align: center;
  min-width: 100px;
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  height: 20px;
  line-height: 18px;
  position: relative;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.key-cell {
  background-color: #565c6b;
  color: #fff;
}
.first-row {
  position: relative;
  height: 20px;
  overflow: hidden;
}
.first-row-content {
  position: absolute;
}
.first-row .cell {
  border-top: 1px solid #ccc;
}
.row:nth-child(odd) {
  background-color: #e9e7e7;
  color: #000;
}
.row:hover {
  background-color: lightblue;
}
.key-cell {
  width: 100px;
}
</style>