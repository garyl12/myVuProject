<template>
  <div class="container" :style="{'padding-right':paddingRight+'px'}">
    <div
      class="bar"
      ref="bar"
      @mouseover="isMouseOver=true"
      @mouseout="isMouseOver=false"
      >
      <div
        v-show="leftArrowVisible"
        class="left-arrow"
        @click="slideButtons(false)"
        ><i class="iconfont icon-aro-left"></i></div>
      <div
        class="panel"
        ref="panel"
        :style="{left:panelOffset+'px',width:panelWidth+'px'}"
        >
        <icon-button
          v-for="(btn,index) in buttons" 
          :key="index"
          :icon="btn.icon"
          :active="btn.active"
          :text="btn.text"
          :callback="btn.callback" />
      </div>
      <div
        v-show="rightArrowVisible"
        class="right-arrow"
        @click="slideButtons(true)"
        ><i class="iconfont icon-aro-right"></i></div>
    </div>
  </div>
</template>

<script>
import IconButton from "@/components/common/IconButton";

const BUTTON_BAR_CONSTS = {
  BUTTON_WIDTH: 30,
  PADDING: 5
};

export default {
  name: "ButtonBar",
  components: { IconButton },
  props: {
    buttons: {
      type: Array,
      required: true
    },
    paddingRight: Number
  },
  computed: {
    panelWidth() {
      return this.buttons.length * BUTTON_BAR_CONSTS.BUTTON_WIDTH;
    },
    leftArrowVisible() {
      return this.isOverflow && this.isMouseOver && this.panelOffset < 0;
    },
    rightArrowVisible() {
      return (
        this.isOverflow &&
        this.isMouseOver &&
        this.barWidth - this.panelOffset < this.panelWidth
      );
    }
  },
  data() {
    return {
      isOverflow: false,
      isMouseOver: false,
      barWidth: 0,
      panelOffset: 0,
      windowResizeHandler: () => {
        this.$nextTick(function() {
          this.calculateBarWidth();
        });
      }
    };
  },
  watch: {
    paddingRight() {
      this.$nextTick(function() {
        this.calculateBarWidth();
      });
    }
  },
  mounted() {
    this.calculateBarWidth();
    window.addEventListener("resize", this.windowResizeHandler);
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.windowResizeHandler);
  },
  methods: {
    calculateBarWidth() {
      this.barWidth = this.$refs.bar.clientWidth;
      this.isOverflow = this.barWidth < this.panelWidth;
      this.panelOffset = 0;
    },
    slideButtons(flag) {
      if (!this.isOverflow) return;
      if (flag) {
        // move right
        if (this.panelWidth > this.barWidth - this.panelOffset) {
          this.panelOffset = Math.max(
            this.panelOffset - BUTTON_BAR_CONSTS.BUTTON_WIDTH,
            this.barWidth - this.panelWidth - BUTTON_BAR_CONSTS.PADDING * 2
          );
        }
      } else {
        // move left
        if (this.panelOffset < 0) {
          this.panelOffset = Math.min(
            this.panelOffset + BUTTON_BAR_CONSTS.BUTTON_WIDTH,
            0
          );
        }
      }
      console.log(this.panelOffset);
    }
  }
};
</script>

<style scoped>
.container {
  margin: 3px 0;
  background-color: #4e586f;
}
.bar {
  position: relative;
  height: 30px;
  overflow: hidden;
}
.panel {
  position: relative;
  top: 0;
  height: 30px;
  margin: 0 5px;
}
.left-arrow,
.right-arrow {
  position: absolute;
  top: 0;
  width: 20px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  cursor: pointer;
  background-color: #575e6b;
  z-index: 1;
}
.left-arrow:hover,
.right-arrow:hover {
  color: #c39f5a;
}
.left-arrow {
  left: 0;
}
.right-arrow {
  right: 0;
}
</style>