<template>
  <el-dialog :title="$t_('upload')" :visible="visible" top="60px" width='600px'
   :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="panel">
      <div class="upload" @click="activate">
        <span>{{$t_('upload')}}</span>
        <form enctype="multipart/form-data" method="post" ref="form">
          <input type="file" v-show="false" name="files" :multiple="allowMulti" ref="uploader" @change="load" />
        </form>
      </div>
      <div class="bar"></div>
      <div v-for="(file,index) in files" :key="index">
        <div class="file">
          <span :title="file">{{file}}</span>
          <i class="delete iconfont icon-close"></i>
        </div>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="upload">{{$t_("upload")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
		</div>
  </el-dialog>
</template>

<script>
export default {
  name: "FileUploader",
  props: {
    allowMulti: Boolean,
    visible: {
      type: Boolean,
      required: true
    }
  },
  watch: {
    visible() {
      if (this.visible) {
        this.files = [];
      }
    }
  },
  data() {
    return {
      files: []
    };
  },
  methods: {
    activate() {
      this.$refs.uploader.click();
    },
    load() {
      this.files = this.$refs.uploader.value
        .split(";")
        .map(file => file.substr(file.lastIndexOf("\\") + 1));
    },
    upload() {
      if (this.files.length) {
        let formData = new FormData(this.$refs.form);
        this.$emit("upload", formData);
      }
    },
    close() {
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.panel {
  height: 200px;
}
.upload {
  display: inline-block;
  width: 80px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  cursor: pointer;
  border-radius: 4px;
  background-color: #383f52;
  color: white;
}
.file {
  height: 24px;
  line-height: 24px;
  position: relative;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bar {
  margin-top: 10px;
  height: 1px;
  background-color: #383f52;
}
.delete {
  position: absolute;
  top: 4px;
  right: 0;
  width: 16px;
  height: 16px;
  line-height: 16px;
  border-radius: 50%;
  cursor: pointer;
}
.delete:hover {
  background-color: #bf0535;
  color: #fff;
}
</style>