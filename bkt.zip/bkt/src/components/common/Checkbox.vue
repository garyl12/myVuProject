<template>
  <span class="box" @click="toggle" onselectstart="return false;">
    <i class="iconfont box-icon icon-minus font-12" v-show="m_Indeterminate"></i>
    <i class="iconfont box-icon icon-check font-12" v-show="m_Checked&&!m_Indeterminate"></i>
    <i class="font-12" v-show="!m_Checked&&!m_Indeterminate">&nbsp;</i>
  </span>
</template>

<script>
export default {
  name: "Checkbox",
  props: {
    indeterminate: Boolean,
    checked: Boolean
  },
  data() {
    return {
      m_Checked: false,
      m_Indeterminate: false
    };
  },
  beforeMount() {
    this.$data.m_Checked = this.$options.propsData.checked;
    this.$data.m_Indeterminate = this.$options.propsData.indeterminate;
  },
  watch: {
    indeterminate(val) {
      this.m_Indeterminate = val;
    },
    checked(val) {
      this.m_Checked = val;
    }
  },
  methods: {
    toggle() {
      this.m_Indeterminate = false;
      this.m_Checked = !this.m_Checked;
      this.$emit("input", this.m_Checked);
      this.$emit("click");
    }
  }
};
</script>

<style scoped>
.box {
  border: 1px solid #ccc;
  border-radius: 2px;
  display: inline-block;
  width: 14px;
  height: 14px;
  line-height: 12px;
  background-color: #fff;
  cursor: pointer;
  text-align: center;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.box:hover {
  border-color: #409eff;
}
</style>