<template>
  <div class="row-group">
    <div v-for="(item,index) in data" :key="index">
      <div class="tree-grid-row clearfix">
        <div :class="['data-cells','clearfix',{'data-cells-selected':item._selected}]" @click="selectRow(item,index)">
          <div v-for="(col,columnIndex) in columns" :class="['tree-grid-cell', {'main-col':columnIndex===0}]" 
            :style="{width:col._columnWidth+'px'}" :key="columnIndex">
            <div class="tree-cell" v-if="columnIndex===0">
              <div v-for="d in depth" :key="d" class="pad"></div>
                <div class="toggle-button" v-show="plain"><i class="iconfont icon-dot icon-12"/></div>
                <div class="toggle-button" v-show="!plain&&item._expanded" @click.stop="fold(item)"><i class="iconfont icon-minus1 icon-12"/></div>
                <div class="toggle-button" v-show="!plain&&!item._expanded" @click.stop="expand(item)"><i class="iconfont icon-plus1 icon-12"/></div>
            </div>
            <span :title="(item.attributes[col.attributeName]||{value:''}).value|formatDisplay(col.displayFormat)">{{(item.attributes[col.attributeName]||{value:""}).value|formatDisplay(col.displayFormat)}}</span>
          </div>
        </div>
      </div>
      <tree-grid-row
        :columns="columns"
        :data="item.children"
        :repeat-select="repeatSelect"
        :parent="item"
        :depth="depth+1"
        :root="false"
        :child-attribute="childAttribute"
        :data-loader="dataLoader"
        :plain="plain"
        @select="broadcastSelect"
        v-show="item._expanded"
        v-if="item[childAttribute]"/>
    </div>
  </div>
</template>
<script>
export default {
  name: "TreeGridRow",
  props: {
    childAttribute: {
      type: String,
      required: true
    },
    columns: {
      type: Array,
      required: true
    },
    data: {
      type: Array,
      required: true
    },
    parent: {
      type: Object
    },
    depth: {
      type: Number,
      default: 0
    },
    root: {
      type: Boolean,
      default: true
    },
    dataLoader: {
      type: Function,
      required: true
    },
    repeatSelect: {
      type: Boolean,
      default: false
    },
    plain: Boolean
  },
  methods: {
    expand(item) {
      if (!item[this.childAttribute] || !item[this.childAttribute].length) {
        this.dataLoader(item).then(children => {
          if (children) {
            this.$set(item, "_expanded", true);
          }
        });
      } else {
        this.$set(item, "_expanded", true);
      }
    },
    fold(item) {
      item._expanded = false;
    },
    selectRow(item, index) {
      if (item._selected && !this.repeatSelect) return;
      this.$set(item, "_selected", true);
      this.$emit("select", { currentItem: item, parent: this.parent, index });
    },
    selectDefault() {
      this.$nextTick(function() {
        if (!this.data.length) return;
        this.selectRow(this.data[0], 0);
      });
    },
    broadcastSelect(payload) {
      this.$emit("select", payload);
    }
  }
};
</script>
<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.row-group {
  color: #000;
}
.pad {
  float: left;
  width: 12px;
  height: 24px;
}
.tree-branch-root {
  position: relative;
  float: left;
  width: 0;
  height: 24px;
}
.tree-branch-root div {
  position: absolute;
  top: 0;
  right: 0;
  height: 11px;
  width: 0;
  border-left: 1px dotted #808080;
  background-color: #fff;
}
.tree-branch {
  float: left;
  width: 16px;
}
.tree-branch div {
  height: 11px;
  border-bottom: 1px dotted #808080;
}
.tree-path {
  position: relative;
  height: 24px;
  line-height: 24px;
}
.toggle-button {
  float: left;
  cursor: pointer;
  width: 24px;
  height: 22px;
  line-height: 22px;
}
.tree-cell {
  float: left;
  height: 24px;
  line-height: 24px;
  text-align: center;
}
.tree-grid-cell {
  float: left;
  min-width: 100px;
  height: 24px;
  line-height: 24px;
  text-align: center;
  border-right: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.tree-grid-row {
  height: 24px;
}
.data-cells {
  float: left;
  height: 24px;
  cursor: pointer;
}
.data-cells:hover {
  background-color: #e9e7e7;
}
.data-cells-selected {
  background-color: #e9e7e7;
}
.main-col {
  padding-left: 5px;
  text-align: left;
}
.icon-12 {
  font-size: 12px;
}
</style>
