<template>
  <div class="editable-grid" :style="{width:gridWidth+'px'}" ref="grid">
    <div class="editable-grid-header-row clearfix">
      <div v-if="needIndex" class="editable-grid-header-cell" style="width:50px" onselectstart="return false">{{$t_("index")}}</div>
      <div :class="['editable-grid-header-cell',{'sortable':col.sortable}]" :style="{'width':col._columnWidth+'px'}" v-for="(col,index) in columns" :key="index" @click.stop="sort(col)" onselectstart="return false">
        <span>{{$t_(col.displayName)|decorateFieldName(col.displayFormat)}}</span>
        <div class="editable-grid-col-sort" v-if="col.sortable" v-show="col._sorted">
          <div class="iconfont icon-triangleU font-10" v-show="col._sorted&&col._order"></div>
          <div class="iconfont icon-triangleD font-10" v-show="col._sorted&&!col._order"></div>
        </div>
      </div>
      <div class="editable-grid-header-cell" style="width:100px" onselectstart="return false">{{$t_("operation")}}</div>
    </div>
    <div class="editable-grid-row clearfix" v-for="(row,rowIndex) in data" :key="rowIndex">
      <div v-if="needIndex" class="editable-grid-cell" style="width:50px">{{rowIndex+1}}</div>
      <div :class="['editable-grid-cell',{'editing-cell':col.editable},{'active-cell':activityMap[rowIndex+'-'+colIndex]}]" :style="{'width':col._columnWidth+'px'}" v-for="(col,colIndex) in columns" :key="colIndex" @click.stop="activateCell(rowIndex,colIndex,col)">
        <span v-show="!activityMap[rowIndex+'-'+colIndex]">{{row[col.attributeName]}}</span>
        <input v-show="activityMap[rowIndex+'-'+colIndex]" v-model="editingAttr" @blur="deactivateCell(rowIndex,colIndex,col)" :ref="rowIndex+'-'+colIndex" />
      </div>
      <div class="editable-grid-cell" style="width:100px">
        <input type="button" class="operator" @click.stop="remove(rowIndex)" value='-'>
      </div>
    </div>
    <div class="editable-empty-row clearfix">
      <div v-if="needIndex" class="editable-grid-cell" style="width:50px"></div>
      <div :class="['editable-grid-cell','editing-cell',{'active-cell':activityMap['x-'+colIndex]}]" :style="{'width':(col._columnWidth||100)+'px'}" v-for="(col,colIndex) in columns" :key="colIndex" @click.stop="activateCell('x',colIndex,col)">
        <input v-model="addingEntry[col.attributeName]" @blur="deactivateCell('x',colIndex,col)" :ref="'x-'+colIndex" v-if="col.editable" />
        <span v-else>{{addingEntry[col.attributeName]||'--'}}</span>
      </div>
      <div class="editable-grid-cell" style="width:100px">
        <input type="button" class="operator" @click.stop="add" value='+'>
      </div>
    </div>
    <alert :config="validationAlert" />
    <alert :config="removeConfirmation" />
  </div>
</template>

<script>
import { clone, isNumber } from "@/utils";
import Alert from "@/components/common/Alert";

export default {
  name: "EditableGrid",
  components: {
    Alert
  },
  props: {
    columns: {
      required: true,
      type: Array
    },
    data: {
      type: Array
    },
    needIndex: {
      type: Boolean
    }
  },
  watch: {
    columns() {
      this.resetGridWidth();
    }
  },
  data() {
    return {
      validationAlert: {
        visible: false,
        title: "warning",
        message: "field_invalid",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              let cellId = "";
              for (let attr in this.activityMap) {
                if (this.activityMap[attr]) {
                  cellId = attr;
                  break;
                }
              }
              this.validationAlert.message = "";
              this.validationAlert.visible = false;
              if (cellId) {
                this.$nextTick(function() {
                  this.$refs[cellId][0].focus();
                });
              }
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.editingAttr = "";
              for (let attr in this.activityMap) {
                this.activityMap[attr] = false;
              }
              this.validationAlert.message = "";
              this.validationAlert.visible = false;
            }
          }
        ]
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.doRemove();
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
      editingAttr: "",
      addingEntry: {},
      activityMap: {},
      removingIndex: -1,
      gridWidth: 0,
      resizeHandler: () => {
        this.resetGridWidth();
      }
    };
  },
  mounted() {
    this.resetGridWidth();
    this.bindWindowResize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    clearAddingEntry() {
      this.addingEntry = {};
    },
    activateCell(rowIndex, colIndex, column) {
      if (!column.editable) return;
      for (let index in this.activityMap) {
        if (this.activityMap[index]) return;
      }
      var cellId = rowIndex + "-" + colIndex;
      if (this.activityMap[cellId]) return;
      this.$set(this.activityMap, cellId, true);
      if (rowIndex !== "x") {
        this.editingAttr = this.data[rowIndex][column.attributeName];
      }
      this.$nextTick(() => {
        this.$refs[cellId][0].focus();
      });
    },
    deactivateCell(rowIndex, colIndex, column) {
      if (rowIndex === "x") {
        if (this.addingEntry[column.attributeName]) {
          if (
            column.validate &&
            column.validate(
              this.addingEntry[column.attributeName],
              rowIndex,
              this.addingEntry
            )
          ) {
            if (column.drive) {
              this.addingEntry = column.drive(this.addingEntry);
            }
          }
        }
        this.activityMap[rowIndex + "-" + colIndex] = false;
        return;
      }
      if (!this.editingAttr) {
        if (column.required) {
          this.validationAlert.visible = true;
          this.validationAlert.message = "field_required";
          return;
        }
      } else {
        if (column.validate) {
          if (
            !column.validate(this.editingAttr, rowIndex, this.data[rowIndex])
          ) {
            this.validationAlert.visible = true;
            this.validationAlert.message = "field_invalid_adding";
            return;
          }
        }
      }
      if (this.data[rowIndex][column.attributeName] != this.editingAttr) {
        this.$set(this.data[rowIndex], column.attributeName, this.editingAttr);
        this.editingAttr = "";
        if (column.drive) {
          this.data.splice(rowIndex, column.drive(this.data[rowIndex]));
        }
        this.$emit("change");
      }
      this.activityMap[rowIndex + "-" + colIndex] = false;
    },
    remove(rowIndex) {
      this.removingIndex = rowIndex;
      this.removeConfirmation.visible = true;
    },
    doRemove() {
      if (this.removingIndex > -1) {
        this.data.splice(this.removingIndex, 1);
        this.removingIndex = -1;
        this.$emit("change");
      }
    },
    add() {
      let valid = !this.columns.some((col, index) => {
        if (col.editable) {
          if (col.required) {
            if (!this.addingEntry[col.attributeName]) {
              this.validationAlert.message =
                this.$t_(col.displayName) +
                " " +
                this.$t_("field_required_adding");
              this.validationAlert.visible = true;
              return true;
            }
          }
          if (col.validate && this.addingEntry[col.attributeName]) {
            if (
              !col.validate(
                this.addingEntry[col.attributeName],
                index,
                this.addingEntry
              )
            ) {
              this.validationAlert.message =
                this.$t_(col.displayName) +
                " " +
                this.$t_("field_invalid_adding");
              this.validationAlert.visible = true;
              return true;
            }
          }
        }
        return false;
      });
      if (!valid) return;
      this.data.push(this.addingEntry);
      this.addingEntry = {};
      var sortingByColumn = this.columns.find(col => col._sorted);
      if (sortingByColumn) {
        this.sort(sortingByColumn);
      }
      this.$emit("change");
      this.$nextTick(() => {
        this.$refs["x-0"][0].focus();
      });
    },
    sort(column) {
      if (!column.sortable) return;
      this.columns.forEach(col => {
        col._sorted = false;
      });
      this.$set(column, "_sorted", true);
      this.$set(column, "_order", !column._order);
      let isNum = !this.data.some(item => {
        return !isNumber(item[column.attributeName]);
      });
      if (column.sortBy) {
        this.data.sort(column.sortBy);
      } else {
        this.data.sort((a, b) => {
          let result = 0;
          if (a[column.attributeName] !== b[column.attributeName]) {
            if (isNum) {
              result =
                Number(a[column.attributeName]) >
                Number(b[column.attributeName])
                  ? 1
                  : -1;
            } else {
              result =
                a[column.attributeName] > b[column.attributeName] ? 1 : -1;
            }
          }
          return column._order ? result : -result;
        });
      }
    },
    resetGridWidth() {
      this.gridWidth = this.$refs.grid.parentNode.clientWidth;
      let builtinWidth = 100;
      if (this.needIndex) {
        builtinWidth += 50;
      }
      let columnWidth = (this.gridWidth - builtinWidth) / this.columns.length;
      this.columns.forEach(col => this.$set(col, "_columnWidth", columnWidth));
    },
    bindWindowResize() {
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.resizeHandler);
    },
    resize() {
      this.$nextTick(function() {
        this.resetGridWidth();
      });
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
input {
  width: 100%;
  outline: none;
  border: 0;
  text-align: center;
}
.editable-grid {
  box-shadow: 0 1px 3px 1px #777;
}
.editable-grid-header-cell {
  height: 24px;
  line-height: 24px;
  float: left;
  text-align: center;
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  position: relative;
}
.editable-grid-header-cell.sortable {
  cursor: pointer;
}
.editable-grid-cell {
  height: 24px;
  line-height: 24px;
  float: left;
  text-align: center;
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.editing-cell {
  cursor: text;
}
.active-cell {
  border: 2px solid #217346;
  border-radius: 4px;
}
.operator {
  border-radius: 3px;
  border: 1px solid #ccc;
  background-color: #fff;
  cursor: pointer;
  height: 14px;
  line-height: 10px;
  margin: 5px 0;
  width: 50%;
}
.operator:hover {
  background-color: lightgrey;
}
.operator:focus {
  border: 1px solid #217346;
}
.editable-grid-col-sort {
  position: absolute;
  right: 0;
  top: 0;
  margin-right: 6px;
  text-align: center;
  cursor: pointer;
}
.editable-grid-col-sort:hover {
  color: #ccc;
}
.font-10 {
  font-size: 10px;
}
</style>
