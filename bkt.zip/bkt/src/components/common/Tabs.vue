<template>
  <div class="container clearfix" onselectstart="return false;" ref="container">
    <div class="slide-left" v-show="overflow" @click="slide(false)">
      <i class="iconfont icon-aro-l"></i>      
    </div>
    <div class="tabs" :style="{left:slideOffset+'px'}" ref="tabs">
      <div v-for="(tab,index) in tabs"
        :key="index"
        :class="['tab',{'selected':activeIndex===index}]"
        @click="selectTab(tab,index)"
        :ref="tab"
        :title="$t_(tab)"
        >{{$t_(tab)}}</div>
    </div>
    <div class="slide-right" v-show="overflow" @click="slide(true)">
      <i class="iconfont icon-aro-r"></i>
    </div>
  </div>
</template>

<script>
const SLIDE_BUTTON_WIDTH = 18;

export default {
  name: "Tabs",
  props: {
    tabs: {
      type: Array,
      required: true
    },
    activeIndex: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      overflow: false,
      slideOffset: 0,
      containerWidth: 0,
      tabsWidth: 0,
      edgeIndex: 0,
      windowResizeHandler: () => {
        this.checkOverflow();
      }
    };
  },
  watch: {
    tabs() {
      this.checkOverflow();
    }
  },
  mounted() {
    this.checkOverflow();
    this.bindWindowResize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    bindWindowResize() {
      window.addEventListener("resize", this.windowResizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.windowResizeHandler);
    },
    checkOverflow() {
      this.$nextTick(function() {
        let tabsWidth = 0;
        this.containerWidth = this.$refs.container.clientWidth;
        this.tabs.forEach(tab => {
          // in case the width has been rounded
          tabsWidth += this.$refs[tab][0].offsetWidth + 1;
        });
        this.tabsWidth = tabsWidth;
        this.$refs.tabs.style.width = tabsWidth + "px";
        if (this.containerWidth < this.tabsWidth) {
          this.overflow = true;
        } else {
          this.overflow = false;
        }
        // if window resize causes Tabs change from not-overflowed to overflowed
        // need to set slide offset, in case slide button will cover the first tab
        // if window resize causes Tabs change from overflowed to not-overflowed
        // need to set slide offset to 0, in case the first tab is not sticking to left edge
        if (this.overflow) {
          this.slideOffset = SLIDE_BUTTON_WIDTH;
        } else {
          this.slideOffset = 0;
        }
      });
    },
    selectTab(tab, index) {
      this.$emit("click", {
        tab,
        index
      });
    },
    slide(toRight) {
      if (!this.overflow) return;
      if (toRight) {
        // if slideOffset(less than SLIDE_BUTTON_WIDTH, probably negative) + tabsWidth is less than containerWidth
        // it means the last tab is visible, can't slide to right any more
        if (this.slideOffset + this.tabsWidth < this.containerWidth) return;

        this.slideOffset -=
          this.$refs[this.tabs[this.edgeIndex]][0].offsetWidth + 1;
        this.edgeIndex++;
      } else {
        // if slideOffset equals SLIDE_BUTTON_WIDTH, it means the first tab is visible, can't slide to left any more
        if (this.slideOffset === SLIDE_BUTTON_WIDTH) return;

        this.edgeIndex--;
        this.slideOffset +=
          this.$refs[this.tabs[this.edgeIndex]][0].offsetWidth + 1;
      }
    }
  }
};
</script>

<style scoped>
.container {
  overflow: hidden;
  position: relative;
  line-height: 28px;
  height: 30px;
}
.tabs {
  position: relative;
  top: 0;
  height: 30px;
}
.tab {
  float: left;
  padding: 0px 10px;
  border: 1px solid #ccc;
  cursor: pointer;
}
.selected {
  background-color: #4e586f;
  color: #fff;
}
.slide-left,
.slide-right {
  position: absolute;
  top: 0;
  height: 28px;
  border: 1px solid #ccc;
  width: 16px;
  cursor: pointer;
  text-align: center;
  background-color: #fff;
  z-index: 1;
}
.slide-left {
  left: 0;
}
.slide-right {
  right: 0;
}
.slide-left:hover,
.slide-right:hover {
  background-color: #383f52;
  color: #fff;
}
</style>