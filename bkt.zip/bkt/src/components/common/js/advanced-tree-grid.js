/*
==================== Sample ====================
<div id="grid"></div>

<script>
  let grid = new AdvancedTreeGrid({
    columns: [{
        valueAttr: "ID"
      },
      {
        valueAttr: "Name",
        columns: [{
            valueAttr: "First Name"
          },
          {
            valueAttr: "Last Name"
          }
        ]
      },
      {
        valueAttr: "Address",
        columns: [{
          valueAttr: "Home Address",
          columns: [{
              valueAttr: "Province"
            },
            {
              valueAttr: "City"
            }
          ]
        }, {
          valueAttr: "Work Address"
        }]
      }
    ],
    dataLoader: function () {
      return new Promise((resolve, reject) => {
        setTimeout(function () {
          resolve([{
            ID: 1,
            "First Name": "X",
            "Last Name": 'X',
            Province: "Henan",
            City: "Yuzhou",
            "Work Address": "Hangzhou",
            children: [{
              ID: 1,
              "First Name": "X",
              "Last Name": 'X',
              Province: "Henan",
              City: "Yuzhou",
              "Work Address": "Hangzhou",
            }]
          }, {
            ID: 2,
            "First Name": "Y",
            "Last Name": "Y",
            Province: "Henan",
            City: "Yuzhou",
            "Work Address": "Hangzhou"
          }]);
        }, 1000);
      })
    },
    selectRow: function (data) {
      console.log(data);
    },
    mountPoint: "#grid"
  });
</script>
==================== Sample ====================
*/



/*
 * API description
 * 
 * {
 *  mountPoint: string // required; specify a query selector to mount grid, id start with #, class start with .
 *  columns: Array // required; template below, sample above, support multi-level table header
 *  dataLoader: Function // required; a function returns a Promise
 *  data: Array // optional; if provided, dataLoader won't be triggered after grid being rendered
 *  selectRow: Function // optional; trigger after row being selected, payload is corresponding data of the row
 * }
 * 
 * 
 * 
 * 
 * const Column_Template = {
 *  valueAttr: "ID", //value of which attribute
 *  valueGetter: function(data){ return data.firstName + data.lastName }, //when it's not easy to get value from attribute, implement a value getter
 *  name: null,
 *  columns: [] // when this column has sub columns
 * }
 */
;
(function () {
  const processColumns = function (columns, parent, parentId = "col") {
    let depth = 1;
    let childCount = 0;
    columns.forEach((col, index) => {
      col._parent = parent;
      col._id = [parentId, index].join("-");
      if (col.columns) {
        let result = processColumns(col.columns, col, col._id);
        col._childCount = result.childCount;
        childCount += result.childCount;
        depth = result.depth + 1;
      } else {
        col._childCount = 1;
        childCount++;
      }
    });
    return {
      depth,
      childCount
    };
  };

  const getColumnTotalCount = function (columns) {
    let count = 0;
    columns.forEach(col => {
      if (col.columns) {
        if (col._folded) {
          if (col.keyColumns) {
            let keyColumns = [];
            for (let i = 0; i < col.columns.length; i++) {
              if (col.keyColumns.indexOf(col.columns[i].valueAttr) > -1) {
                keyColumns.push(col.columns[i]);
              }
            }
            count += getColumnTotalCount(keyColumns);
          } else {
            count += getColumnTotalCount([col.columns[0]]);
          }
        } else {
          count += getColumnTotalCount(col.columns);
        }
      } else {
        count++;
      }
    })
    return count;
  };

  // defining html fragment templates
  const ATG_TEMPLATE = {
    HEADER_HEIGHT: 30,
    CELL_MIN_WIDTH: 100,
    GRID: `<div class="atg-grid" style="width:{2}px">{0}{1}</div>`,
    HEADER: `<div class="atg-header" style="height:{1}px" onselectstart="return false;">{0}</div>`,
    HEADER_ROW: `<div class="atg-header-inner clearfix" style="width:{1}px">{0}</div>`,
    HEADER_CELL: `<div class="atg-header-cell" style="height:{2}px;line-height:{3}px;width:{4}px" id="{1}"><div class="atg-header-cell-border-t"></div><div class="atg-header-cell-dragger"></div>{6}<span>{0}</span>{5}</div>`,
    HEADER_BTN_FOLD: `<span class="atg-btn atg-header-btn fold"></span>`,
    BTN_FOLD: `<span class="atg-btn atg-row-btn fold"></span>`,
    BTN_EXPAND: `<span class="atg-btn atg-row-btn expand"></span>`,
    CLUSTER: `<div class="{1}">{0}</div>`,
    BODY: `<div class="atg-body" style="height:{1}px;">{0}</div>`,
    BODY_INNER_WRAPPER: `<div style="width:{1}px;" class="atg-body-inner">{0}</div>`,
    BODY_ROW: `<div class="atg-body-row clearfix" id="{1}">{0}</div><div class="atg-row-children">{2}</div>`,
    BODY_ROW_EMPTY: `<div class="atg-body-row"><div class="atg-body-row-empty">--</div></div>`,
    BODY_MAIN_CELL_PAD: `<div class="atg-pad"></div>`,
    BODY_ROW_CELL_MAIN: `<div class="atg-body-cell main {1}" style="width:{2}px">{3}{4}<span>{0}<span></div>`,
    BODY_ROW_CELL: `<div class="atg-body-cell {1}" style="width:{2}px;{3}"><span>{0}<span></div>`,
    DISPLAY_NONE: `display:none;`
  }

  const buildHtml = function (header, body, gridWidth) {
    return fill(ATG_TEMPLATE.GRID, header, body, gridWidth);
  };

  const buildHeader = function (columns, columnDepth, gridRealWidth) {
    return fill(
      ATG_TEMPLATE.HEADER,
      fill(
        ATG_TEMPLATE.HEADER_ROW,
        buildHeaderCells(columns, columnDepth),
        gridRealWidth
      ),
      columnDepth * ATG_TEMPLATE.HEADER_HEIGHT
    );
  }

  const buildBody = function (dataArray, columns, gridRealWidth, bodyHeight) {
    return fill(
      ATG_TEMPLATE.BODY,
      fill(
        ATG_TEMPLATE.BODY_INNER_WRAPPER,
        dataArray && dataArray.length ? buildRows(dataArray, columns) : ATG_TEMPLATE.BODY_ROW_EMPTY,
        gridRealWidth
      ),
      bodyHeight
    );
  };

  const buildHeaderCells = function (columns, columnDepth) {
    let segment = "";
    columns.forEach(col => {
      segment += fill(
        ATG_TEMPLATE.HEADER_CELL,
        col.name || col.valueAttr,
        col._id,
        ATG_TEMPLATE.HEADER_HEIGHT * columnDepth,
        col.columns ? ATG_TEMPLATE.HEADER_HEIGHT : ATG_TEMPLATE.HEADER_HEIGHT * columnDepth,
        col._width,
        col.columns ? fill(ATG_TEMPLATE.CLUSTER, buildHeaderCells(col.columns, columnDepth - 1)) : "",
        col.columns ? ATG_TEMPLATE.HEADER_BTN_FOLD : ""
      );
    })
    return segment;
  };

  const buildRows = function (dataArray, columns, parentId = "row", rowDepth = 0) {
    let segment = "";
    dataArray.forEach((data, index) => {
      let rowId = [parentId, index].join("-");
      if (data.children) {
        data._expanded = true;
      }
      segment += fill(
        ATG_TEMPLATE.BODY_ROW,
        buildCells(columns, data, rowDepth),
        rowId,
        data.children ? buildRows(data.children, columns, rowId, rowDepth + 1) : ""
      );
    });
    return segment;
  }

  const buildCells = function (columns, data, rowDepth, buildingSub) {
    let segment = "";
    let mainCellPad = "";
    for (let i = 0; i < rowDepth; i++) {
      mainCellPad += ATG_TEMPLATE.BODY_MAIN_CELL_PAD;
    }
    columns.forEach((col, index) => {
      if (col.columns) {
        segment += fill(ATG_TEMPLATE.CLUSTER, buildCells(col.columns, data, rowDepth, true), col._id);
      } else {
        let display = "";
        if (col._parent && col._parent._folded) {
          if (!(col._parent.keyColumns || [col._parent.columns[0]])
            .some(name => name === col.valueAttr || name === col)
          ) {
            display = ATG_TEMPLATE.DISPLAY_NONE;
          }
        }
        segment += buildingSub || index ? fill(
          ATG_TEMPLATE.BODY_ROW_CELL,
          col.valueGetter ? col.valueGetter(data) : data[col.valueAttr],
          col._id,
          col._width,
          display
        ) : fill(
          ATG_TEMPLATE.BODY_ROW_CELL_MAIN,
          col.valueGetter ? col.valueGetter(data) : data[col.valueAttr],
          col._id,
          col._width,
          mainCellPad,
          data._expanded ? ATG_TEMPLATE.BTN_FOLD : ATG_TEMPLATE.BTN_EXPAND
        );
      }
    })
    return segment;
  };

  const fill = function (template) {
    let fillings = Array.from(arguments).slice(1);
    return template.replace(/{\d+}/g, function (match) {
      let index = Number(match.replace("{", "").replace("}", ""));
      let replacement = fillings[index];
      if (typeof replacement === "undefined" || replacement === null) {
        replacement = "";
      }
      return replacement;
    });
  };

  const bubbleToFindEventHandler = function (event, eventHandler, mountPoint) {
    let el = event.srcElement || event.target;
    let targetFound = false;
    let handler = null;
    while (el !== mountPoint) {
      let classList = Array.from(el.classList);
      targetFound = classList.some(c => {
        handler = eventHandler[c];
        return c in eventHandler;
      });
      if (targetFound) {
        break;
      } else {
        el = el.parentNode;
      }
    }
    if (handler) {
      handler(el, event);
    }
  }

  const getRowData = function (rowId, dataArray) {
    let indexes = rowId.replace('row-', "").split('-');
    let rowData = null;
    for (let i = 0; i < indexes.length; i++) {
      rowData = dataArray[indexes[i]];
      dataArray = rowData.children;
    }
    return rowData;
  }

  const getRowDepth = function (rowId) {
    return rowId.replace('row-', "").split('-').length;
  }

  const getColumn = function (colId, columns) {
    let indexes = colId.replace('col-', "").split('-');
    let column = null;
    for (let i = 0; i < indexes.length; i++) {
      column = columns[indexes[i]];
      columns = column.columns;
    }
    return column;
  }

  const foldColumn = function (column, mountPoint) {
    // only fold its own children and leave key columns or the first column visible
    let baseWidth = column._width;
    let currentWidth = 0;
    column.columns.forEach(c => {
      if ((
          column.keyColumns || [column.columns[0]]
        ).some(name => {
          if (name === c.valueAttr || name === c) {
            return true;
          } else {
            // hide columns
            mountPoint.querySelector("#" + c._id).style.display = "none";
          }
        })) {
        currentWidth += c._width;
      } else {
        // hide corresponding columns in body
        Array.from(mountPoint.getElementsByClassName(c._id)).forEach(cell => {
          cell.style.display = "none";
        })
      }
    });

    let widthGrowth = currentWidth - baseWidth;
    // adjust column width
    while (column) {
      column._width += widthGrowth;
      mountPoint.querySelector("#" + column._id).style.width = column._width + 'px';
      column = column._parent;
    }
  }

  const expandColumn = function (column, mountPoint) {
    let baseWidth = column._width;
    let currentWidth = 0;
    column.columns.forEach(c => {
      // hide corresponding columns in body
      currentWidth += c._width;
      mountPoint.querySelector("#" + c._id).style.display = "";
      Array.from(mountPoint.getElementsByClassName(c._id)).forEach(cell => {
        cell.style.display = "";
      })
    });

    let widthGrowth = currentWidth - baseWidth;
    // adjust column width
    while (column) {
      column._width += widthGrowth;
      mountPoint.querySelector("#" + column._id).style.width = column._width + 'px';
      column = column._parent;
    }
  }

  const bubbleWidthGrowth = function (column, widthGrowth) {
    let parent = column._parent;
    while (parent) {
      parent._width += widthGrowth;
      parent = parent._parent;
    }
  };

  const propagateWidthGrowth = function (column, widthGrowth) {
    if (column.columns && column.columns.length) {
      if (column._folded) {
        // if current column is folded, only the first child column will spread
        if (column.keyColumns) {
          widthGrowth = widthGrowth / column.keyColumns.length;
          column.keyColumns.forEach(col => propagateWidthGrowth(col, widthGrowth));
        } else {
          column.columns[0]._width += widthGrowth;
          propagateWidthGrowth(column.columns[0], widthGrowth);
        }
      } else {
        widthGrowth = widthGrowth / column.columns.length;
        column.columns.forEach(col => {
          col._width += widthGrowth;
          propagateWidthGrowth(col, widthGrowth);
        });
      }
    }
  };

  // adjust grid header/body width
  const flowGrid = function (gridRealWidth, containerWidth, mountPoint) {
    mountPoint.querySelector(".atg-header-inner").style.width = gridRealWidth + 'px';
    mountPoint.querySelector(".atg-body-inner").style.width = gridRealWidth + 'px';
    if (gridRealWidth < containerWidth) {
      mountPoint.querySelector(".atg-grid").style.width = gridRealWidth + 'px';
    } else {
      mountPoint.querySelector(".atg-grid").style.width = "";
    }
  };

  const flowColumns = function (columns, mountPoint) {
    columns.forEach(col => {
      mountPoint.querySelector("#" + col._id).style.width = col._width + "px";
      if (col.columns) {
        flowColumns(col.columns, mountPoint);
      } else {
        Array.from(mountPoint.getElementsByClassName(col._id)).forEach(el => el.style.width = col._width + "px");
      }
    });
  };

  const setColumnWidth = function (columns, columnWidth) {
    columns.forEach(col => {
      if (col._folded) {
        col._width = col.keyColumns ? col.keyColumns.length * columnWidth : columnWidth
      } else {
        col._width = columnWidth * col._childCount;
      }
      if (col.columns) {
        setColumnWidth(col.columns, columnWidth);
      }
    })
  }

  const AdvancedTreeGrid = function (option) {
    let dataArray = [],
      columns = [],
      columnDepth, columnCount,
      dataLoader = function () {},
      autoLoad = false,
      mountPoint = null;

    // ======================== pre-check option ======================== //
    if (!option) {
      throw new Error("missing paramter 'option' when initializing an Advanced Tree Grid");
    }

    if (option.columns) {
      let {
        depth,
        childCount
      } = processColumns(option.columns);
      columns = option.columns;
      columnDepth = depth;
      columnCount = childCount;
    } else {
      throw new Error("missing columns in option");
    }

    if (option.dataLoader) {
      if (typeof option.dataLoader === "function") {
        dataLoader = option.dataLoader;
      } else {
        throw new Error("data loader should be a function");
      }
    } else {
      throw new Error("missing data loader in option");
    }

    if (option.mountPoint) {
      mountPoint = document.querySelector(option.mountPoint);
      if (!mountPoint) {
        throw new Error(`mount point ${option.mountPoint} is not existing in DOM tree`);
      }
    } else {
      throw new Error("missing mount point in option");
    }

    dataArray = option.data || dataArray;
    autoLoad = option.autoLoad;
    // ======================== end pre-check option ======================== //

    let gridWidth, gridHeight, columnWidth, gridBodyHeight, gridRealWidth;

    gridWidth = mountPoint.clientWidth;
    gridHeight = mountPoint.clientHeight;
    columnWidth = Math.max(gridWidth / columnCount, ATG_TEMPLATE.CELL_MIN_WIDTH);
    gridBodyHeight = gridHeight - columnDepth * ATG_TEMPLATE.HEADER_HEIGHT;
    gridRealWidth = columnWidth * columnCount;
    setColumnWidth(columns, columnWidth);

    mountPoint.innerHTML = buildHtml(
      buildHeader(columns, columnDepth, gridRealWidth),
      buildBody(dataArray, columns, gridRealWidth, gridBodyHeight),
      gridWidth
    );


    let clickHandler = {
      // select row
      'atg-body-row': function (el) {
        Array.from(mountPoint.getElementsByClassName("atg-body-row")).forEach(el => {
          el.classList.remove("selected");
        })
        el.classList.add("selected");
        if (option.selectRow) {
          option.selectRow(getRowData(el.id, dataArray));
        }
      },
      // expand/fold row
      'atg-row-btn': function (el) {
        let rowEl = el.parentNode.parentNode;
        let rowData = getRowData(rowEl.id, dataArray);
        if (rowData._expanded) {
          rowData._expanded = false;
          el.classList.add("expand");
          el.classList.remove("fold");
          rowEl.nextSibling.style.display = 'none';
        } else {
          rowData._expanded = true;
          el.classList.add("fold");
          el.classList.remove("expand");
          if (rowData.children) {
            rowEl.nextSibling.style.display = '';
          } else {
            // load data
            dataLoader(rowData).then(data => {
              rowData.children = data;
              rowEl.nextSibling.innerHTML = buildRows(data, columns, rowEl.id, getRowDepth(rowEl.id));
            });
          }
        }
      },
      // expand/fold column
      'atg-header-btn': function (el) {
        let column = getColumn(el.parentNode.id, columns);
        if (column._folded) {
          // to expand column
          column._folded = false;
          el.classList.add("fold");
          el.classList.remove("expand");
          expandColumn(column, mountPoint);
        } else {
          // to fold column
          column._folded = true;
          el.classList.add("expand");
          el.classList.remove("fold");
          foldColumn(column, mountPoint);
        }
        gridRealWidth = 0;
        columns.forEach(col => gridRealWidth += col._width);
        flowGrid(gridRealWidth, gridWidth, mountPoint);
      }
    };

    let mouseDownHandler = {
      "atg-header-cell-dragger": function (el, event) {
        let originalX = event.clientX,
          offsetX = 0;
        const mouseMoveHandler = function (event) {
          offsetX = event.clientX - originalX;
        };
        const mouseUpHandler = function () {
          window.removeEventListener("mousemove", mouseMoveHandler);
          window.removeEventListener("mouseup", mouseUpHandler);
          resizeColumn();
        };
        const resizeColumn = function () {
          let headerCellEl = el.parentNode;
          let column = getColumn(headerCellEl.id, columns);
          if (offsetX < 0) {
            let originalWidth = column.columns ? columnWidth * column._childCount : columnWidth;
            offsetX = originalWidth - column._width;
            column._width = originalWidth;
          } else {
            column._width += offsetX;
          }
          bubbleWidthGrowth(column, offsetX);
          propagateWidthGrowth(column, offsetX);
          flowColumns(columns, mountPoint);
          gridRealWidth = 0;
          columns.forEach(col => gridRealWidth += col._width);
          flowGrid(gridRealWidth, gridWidth, mountPoint);
        };
        window.addEventListener("mousemove", mouseMoveHandler);
        window.addEventListener("mouseup", mouseUpHandler);
      }
    };

    const resizeHandler = function () {
      setTimeout(
        _ => {
          gridWidth = mountPoint.clientWidth;
          gridHeight = mountPoint.clientHeight;
          let columnCount = getColumnTotalCount(columns);
          columnWidth = Math.max(gridWidth / columnCount, ATG_TEMPLATE.CELL_MIN_WIDTH);
          gridBodyHeight = gridHeight - columnDepth * ATG_TEMPLATE.HEADER_HEIGHT;
          gridRealWidth = columnWidth * columnCount;
          setColumnWidth(columns, columnWidth);
          flowColumns(columns, mountPoint);
          flowGrid(gridRealWidth, gridWidth, mountPoint);
          mountPoint.querySelector(".atg-body").style.height = gridBodyHeight + 'px';
        },
        10
      )
    };

    mountPoint.addEventListener("click", function (event) {
      bubbleToFindEventHandler(event, clickHandler, mountPoint);
    });
    mountPoint.addEventListener("mousedown", function (event) {
      bubbleToFindEventHandler(event, mouseDownHandler, mountPoint);
    });
    window.addEventListener("resize", resizeHandler);
    mountPoint.querySelector(".atg-body").addEventListener("scroll", function () {
      let el = event.srcElement || event.target;
      mountPoint.querySelector(".atg-header-inner").style.left = -el.scrollLeft + 'px';
    })

    if (autoLoad) {
      if (!dataArray || !dataArray.length) {
        dataLoader().then(data => {
          dataArray = data;
          mountPoint.querySelector(".atg-body-inner").innerHTML = buildRows(dataArray, columns);
        })
      }
    }

    this.setData = function (data) {
      dataArray = data;
      mountPoint.querySelector(".atg-body-inner").innerHTML = buildRows(dataArray, columns);
    }

    this.destroy = function () {
      window.removeEventListener("resize", resizeHandler);
      mountPoint = null;
    }
  }

  window.AdvancedTreeGrid = AdvancedTreeGrid;
})();
