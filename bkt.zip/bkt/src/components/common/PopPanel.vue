<template>
  <div class="panel-host" ref="host">
    <div class="panel" v-show="visible" @click.stop :style="style">
      <slot></slot>
    </div>
  </div>
</template>

<script>
const getScrollParent = function(el) {
  while (el.parentNode !== document.body) {
    let elParent = el.parentNode;
    let cssProperties = window.getComputedStyle(elParent, null);
    if (
      ["auto", "scroll"].indexOf(cssProperties["overflow"]) !== -1 ||
      ["auto", "scroll"].indexOf(cssProperties["overflow-x"]) !== -1 ||
      ["auto", "scroll"].indexOf(cssProperties["overflow-y"]) !== -1
    ) {
      return elParent;
    }
    el = elParent;
  }
  return document;
};
const getScrollOffset = function(el) {
  let offset = {
    x: el.scrollLeft,
    y: el.scrollTop
  };
  let html = document.body.parentNode;
  while (el.parentNode !== html) {
    let elParent = el.parentNode;
    let cssProperties = window.getComputedStyle(elParent, null);
    if (
      ["auto", "scroll"].indexOf(cssProperties["overflow"]) !== -1 ||
      ["auto", "scroll"].indexOf(cssProperties["overflow-x"]) !== -1 ||
      ["auto", "scroll"].indexOf(cssProperties["overflow-y"]) !== -1
    ) {
      if (elParent === document.body) {
        // only 1 between document.body.scrollTop and document.documentElement.scrollTop will take effect
        offset.x += elParent.scrollLeft + document.documentElement.scrollLeft;
        offset.y += elParent.scrollTop + document.documentElement.scrollTop;
      } else {
        offset.x += elParent.scrollLeft;
        offset.y += elParent.scrollTop;
      }
    }
    el = elParent;
  }
  return offset;
};
const getPositionOffset = function(el) {
  let offset = {
    x: el.offsetLeft,
    y: el.offsetTop
  };
  while (el.offsetParent) {
    let elParent = el.offsetParent;
    offset.x += elParent.offsetLeft;
    offset.y += elParent.offsetTop;
    el = elParent;
  }
  return offset;
};

export default {
  name: "PopPanel",
  props: {
    visible: false,
    width: {
      type: Number
    },
    height: {
      type: Number
    },
    hostHeight: {
      type: Number,
      default: 24
    }
  },
  data() {
    return {
      scrollParent: null,
      position: {
        onTop: true,
        onLeft: true,
        top: 25,
        bottom: 25,
        left: 0,
        right: 0
      },
      clickHandler: () => {
        this.$emit("close");
        this.unbindEventHandler();
      },
      scrollHandler: () => {
        this.calculatePosition();
      },
      resizeHandler: () => {
        this.calculatePosition();
      }
    };
  },
  computed: {
    style() {
      var styleObj = {
        width: this.width + "px",
        height: this.height + "px"
      };
      var pos = this.position;
      if (pos.onTop) {
        styleObj.top = pos.top + "px";
      } else {
        styleObj.bottom = pos.bottom + "px";
      }
      if (pos.onLeft) {
        styleObj.left = pos.left + "px";
      } else {
        styleObj.right = pos.right + "px";
      }
      return styleObj;
    }
  },
  watch: {
    visible(val) {
      if (val) {
        this.calculatePosition();
        setTimeout(() => {
          this.bindEventHandler();
        }, 300);
      } else {
        this.unbindEventHandler();
        this.$emit("close");
      }
    }
  },
  methods: {
    calculatePosition() {
      let positionOffset = getPositionOffset(this.$refs.host),
        scrollOffset = getScrollOffset(this.$refs.host),
        offsetX = positionOffset.x - scrollOffset.x,
        offsetY = positionOffset.y - scrollOffset.y,
        hostWidth = this.$refs.host.clientWidth,
        windowHeight = window.innerHeight,
        windowWidth = window.innerWidth,
        panelWidth = this.width,
        panelHeight = this.height,
        position = this.position;
      position.top = 0;
      position.bottom = 0;
      position.left = 0;
      position.right = 0;
      if (panelWidth > windowWidth) {
        position.onLeft = true;
        position.left = offsetX;
      } else {
        if (
          windowWidth - offsetX > panelWidth ||
          offsetX + hostWidth < panelWidth
        ) {
          position.onLeft = true;
          position.left = offsetX;
        } else {
          position.onLeft = false;
          position.right = windowWidth - offsetX - hostWidth;
        }
      }
      if (panelHeight > windowHeight) {
        position.onLeft = true;
        position.top = offsetY + 1;
      } else {
        if (windowHeight - offsetY > panelHeight || offsetY < panelHeight) {
          position.onTop = true;
          position.top = offsetY + 1;
        } else {
          position.onTop = false;
          position.bottom = windowHeight - offsetY + this.hostHeight + 1;
        }
      }
    },
    bindEventHandler() {
      this.scrollParent = getScrollParent(this.$refs.host);
      if (this.scrollParent) {
        this.scrollParent.addEventListener("scroll", this.scrollHandler);
      }
      document.addEventListener("click", this.clickHandler);
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindEventHandler() {
      if (this.scrollParent) {
        this.scrollParent.removeEventListener("scroll", this.scrollHandler);
      }
      document.removeEventListener("click", this.clickHandler);
      window.removeEventListener("resize", this.resizeHandler);
    }
  }
};
</script>

<style scoped>
.panel-host {
  height: 0;
}
.panel {
  position: fixed;
  z-index: 1;
  border: 1px solid red;
  border-radius: 4px;
  background-color: #fff;
}
</style>