<template>
  <div ref="gridWrapper">
    <div class="grid-pager-container clearfix"  v-show="needPager||needSearcher" ref="pager">
      <div class="grid-slot">
        <slot></slot>
      </div>
      <div class="grid-pager-wrapper">
        <div class="grid-pager" v-show="needPager&&data.length">
          <div class="pager-btn" @click="goPrevPage" :title="$t_('prev_page')"><i class="iconfont icon-aro-l"></i></div>
          <div class="pager">
            <input type="text" :title="$t_('input_page_no')" v-model="grid.targetPageIndex" @keydown.enter="jumpPage()" /><em>/</em><span>{{pageCount}}</span>
          </div>
          <div class="pager-btn" @click="goNextPage" :title="$t_('next_page')"><i class="iconfont icon-aro-r"></i></div>
        </div>
        <div class="grid-searcher"
          v-if="needSearcher">
          <div class="searcher-input">
            <input type="text" v-model="searcher.condition" :placeholder="searcherPlaceholder" @keydown.enter="search"/>
            <div class="btn-search">
              <i class="iconfont icon-search" @click="search"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div :class="['grid-container',{'default-margin':!(needPager||needSearcher)}]">
      <div class="grid">
        <div class="grid-header clearfix" ref="header" :style="{width:gridWidth+'px'}">
          <div class="grid-header-content"  ref="content" :style="{width:gridBodyWidth+'px'}">
            <div v-if="needColumnChecker" class="grid-header-cell grid-header-text grid-cell-builtin">
              <input type="checkbox" @click="checkAll" v-model="grid.allChecked"/>
              <div class="grid-dragger"></div>
            </div>
            <div v-if="needIndex" class="grid-header-cell grid-header-text grid-cell-builtin" :title="$t_('index')">
              <span>{{$t_('index')}}</span>
              <div class="grid-dragger"></div>
            </div>
            <div v-for="(col,index) in privateColumns" :key="index" :class="['grid-header-cell', {'grid-cell-sortable': col.isSortable}]" :style="{width: col._columnWidth+'px'}" onselectstart="return false;">
              <div @click="sort(col)" class="grid-header-text">
                <span :title="$t_(col.displayName)|decorateFieldName(col.displayFormat)" onselectstart="return false;">{{$t_(col.displayName)|decorateFieldName(col.displayFormat)}}</span>
                <div class="grid-col-sort" v-if="col.isSortable" v-show="col._sorted">
                  <div class="iconfont icon-triangleU font-12" v-show="col._sorted&&col._order"></div>
                  <div class="iconfont icon-triangleD font-12" v-show="col._sorted&&!col._order"></div>
                </div>
              </div>
              <div class="grid-dragger" @mousedown="startDragColumn(col, index, $event)" onselectstart="return false;"></div>
              <div class="grid-dragger-shadow"></div>
            </div>
          </div>
        </div> 
        <div class="grid-body" ref="body" :style="{width:gridWidth+'px'}" @scroll="scrollX">
          <div :class="['grid-row', 'clearfix', {'grid-row-even':rowIndex%2,'grid-row-selected': item._selected}]" v-for="(item,rowIndex) in data" :key="rowIndex" @click="selectRow(item, rowIndex)" :style="{width: gridBodyWidth+'px'}">
            <div v-if="needColumnChecker" class="grid-cell grid-cell-builtin">
              <input type="checkbox" @click.stop="checkRow(item, rowIndex)" v-model="item._checked" />
            </div>
            <div v-if="needIndex" class="grid-cell grid-cell-builtin">
              <span :title="rowIndex">{{rowIndex+1}}</span>
            </div>
            <div v-for="(col, colIndex) in privateColumns" :key="rowIndex+'_'+colIndex" class="grid-cell" :style="{width:col._columnWidth+'px'}">
              <span :title="(item.attributes[col.attributeName]||{value:''}).value|formatDisplay(col.displayFormat)">{{(item.attributes[col.attributeName]||{value:''}).value|formatDisplay(col.displayFormat)}}</span>
            </div>
          </div>
          <div v-show="!data.length" class="grid-row-noentry" :style="{width: gridBodyWidth+'px'}">
            <div :style="{width:gridWidth+'px'}" class="message" ref="noEntryMessage">{{$t_("No_Record")}}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { SIZE } from "@/consts";
import { clone } from "@/utils";
// default margin-top when pager is not necessary
// corresponding to CSS class: default-margin
const gridContainerMargin = 10;

export default {
  name: "Grid",
  props: {
    columns: {
      type: Array,
      required: true
    },
    data: {
      required: true,
      type: Array
    },
    needColumnChecker: Boolean,
    needPager: Boolean,
    pageCount: {
      type: Number,
      default: 1
    },
    pageIndex: {
      type: Number,
      default: 1
    },
    needSearcher: Boolean,
    searcherPlaceholder: String,
    condition: String,
    needIndex: Boolean,
    repeatSelect: Boolean
  },
  data() {
    return {
      searcher: {
        condition: ""
      },
      privateColumns: [],
      privateColumnWidth: 0,
      grid: {
        targetPageIndex: 1,
        allChecked: false
      },
      gridWidth: 0,
      gridBodyOverflowY: false,
      resizeHandler: () => {
        this.resize();
      }
    };
  },
  computed: {
    gridBodyWidth() {
      let width = 0;
      if (this.needColumnChecker) {
        width += SIZE.GRID.BUILTIN_COLUMN_WIDTH;
      }
      if (this.needIndex) {
        width += SIZE.GRID.BUILTIN_COLUMN_WIDTH;
      }
      this.privateColumns.forEach((col, index) => {
        width += col._columnWidth;
      });
      return width;
    }
  },
  watch: {
    columns() {
      this.privateColumns = clone(this.columns);
      this.calculateColumnWidth();
    },
    pageIndex(val) {
      this.grid.targetPageIndex = val;
    },
    data() {
      this.$nextTick(function() {
        this.calculateBodyOverflow();
        this.calculateColumnWidth();
      });
    },
    condition() {
      this.searcher.condition = this.condition;
    }
  },
  mounted() {
    this.privateColumns = clone(this.columns);
    this.bindWindowResize();
    this.resize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    bindWindowResize() {
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.resizeHandler);
    },
    scrollX() {
      this.$refs.content.style.left = -this.$refs.body.scrollLeft + "px";
      this.$refs.noEntryMessage.style.left = this.$refs.body.scrollLeft + "px";
    },
    resizeGridWidth() {
      this.gridWidth =
        this.$refs.gridWrapper.parentNode.clientWidth - SIZE.GRID.H_PADDING;
    },
    resizeGridHeight() {
      let entireGridHeight = this.$refs.gridWrapper.parentNode.clientHeight,
        pagerHeight =
          this.needPager || this.needSearcher
            ? this.$refs.pager.clientHeight
            : gridContainerMargin;
      let gridBodyHeight =
        entireGridHeight -
        pagerHeight -
        SIZE.GRID.HEADER_HEIGHT -
        SIZE.GRID.PADDING_BOTTOM;
      this.$refs.body.style.height = gridBodyHeight + "px";
      this.calculateBodyOverflow();
    },
    calculateBodyOverflow() {
      this.gridBodyOverflowY =
        this.$refs.body.offsetWidth !== this.$refs.body.clientWidth;
    },
    calculateColumnWidth() {
      if (this.privateColumns.length) {
        let columnsTotalWidth = this.gridWidth;
        if (this.needColumnChecker) {
          columnsTotalWidth -= SIZE.GRID.BUILTIN_COLUMN_WIDTH;
        }
        if (this.needIndex) {
          columnsTotalWidth -= SIZE.GRID.BUILTIN_COLUMN_WIDTH;
        }
        if (this.gridBodyOverflowY) {
          columnsTotalWidth -= SIZE.SCROLL_BAR_WIDTH;
        }
        let columnWidth = Math.floor(
          columnsTotalWidth / this.privateColumns.length
        );
        columnWidth = Math.max(columnWidth, SIZE.GRID.COLUMN_MIN_WIDTH);
        let firstColumnWidth =
          columnsTotalWidth - columnWidth * (this.privateColumns.length - 1);
        firstColumnWidth = Math.max(
          firstColumnWidth,
          SIZE.GRID.COLUMN_MIN_WIDTH
        );
        this.privateColumns.forEach((col, index) => {
          if (
            !col._columnWidth ||
            col._columnWidth === this.privateColumnWidth ||
            col._columnWidth < columnWidth
          ) {
            this.$set(
              col,
              "_columnWidth",
              index ? columnWidth : firstColumnWidth
            );
          }
        });
        this.privateColumnWidth = columnWidth;
      }
    },
    startDragColumn(col, colIndex, e) {
      let ele = e.srcElement || e.target,
        currentCell = ele.parentNode,
        draggerShadow = ele.nextElementSibling,
        originalX = e.clientX,
        offsetX = 0,
        maxOffsetX = -Math.max(
          0,
          this.gridBodyWidth -
            this.gridWidth +
            (this.gridBodyOverflowY ? SIZE.SCROLL_BAR_WIDTH : 0)
        ),
        mouseMoveHandler = function(event) {
          offsetX = event.clientX - originalX;
          draggerShadow.style.right = -offsetX + "px";
          draggerShadow.style.display = "";
        },
        gridResize = function() {
          draggerShadow.style.display = "none";
          if (offsetX < maxOffsetX) {
            offsetX = maxOffsetX;
          }
          let width = Math.ceil(currentCell.offsetWidth + offsetX);
          // column min width is 100px
          width = Math.max(width, SIZE.GRID.COLUMN_MIN_WIDTH);
          col._columnWidth = width;
        },
        mouseUpHandler = function(event) {
          document.removeEventListener("mousemove", mouseMoveHandler, false);
          gridResize();
          document.removeEventListener("mouseup", mouseUpHandler, false);
        };
      document.addEventListener("mouseup", mouseUpHandler, false);
      document.addEventListener("mousemove", mouseMoveHandler, false);
    },
    getSortbyColumn() {
      for (var i = 0; i < this.privateColumns.length; i++) {
        if (this.privateColumns[i]._sorted) {
          return this.privateColumns[i];
        }
      }
      return {};
    },
    uncheckCurrentPage() {
      this.grid.allChecked = false;
      for (var i = 0; i < this.data.length; i++) {
        this.data[i]._checked = false;
      }
    },
    goPrevPage() {
      this.uncheckCurrentPage();
      if (this.pageIndex === 1) {
        //this is the first page
        return;
      }
      console.log("emit prev page");
      this.$refs.body.scrollTop = 0;
      this.$emit("prev-page", {
        pageIndex: this.pageIndex - 1
      });
    },
    goNextPage() {
      this.uncheckCurrentPage();
      if (this.pageIndex === this.pageCount) {
        //this is the last page
        return;
      }
      console.log("emit next page");
      this.$refs.body.scrollTop = 0;
      this.$emit("next-page", {
        pageIndex: this.pageIndex + 1
      });
    },
    jumpPage() {
      this.uncheckCurrentPage();
      if (isNaN(Number(this.grid.targetPageIndex))) {
        this.grid.targetPageIndex = this.pageIndex;
      } else {
        this.grid.targetPageIndex = Math.floor(
          Number(this.grid.targetPageIndex)
        );
        if (
          this.grid.targetPageIndex < 1 ||
          this.grid.targetPageIndex > this.pageCount
        ) {
          this.grid.targetPageIndex = this.pageIndex;
        } else {
          console.log("emit jump page");
          this.$refs.body.scrollTop = 0;
          this.$emit("jump-page", {
            pageIndex: this.grid.targetPageIndex
          });
        }
      }
    },
    checkAll() {
      // v-model update after click event
      if (this.grid.allChecked) {
        //uncheck all
        for (var i = 0; i < this.data.length; i++) {
          this.data[i]._checked = false;
        }
      } else {
        //check all
        for (var i = 0; i < this.data.length; i++) {
          this.$set(this.data[i], "_checked", true);
        }
      }
      this.$emit("check-all", {
        data: this.data,
        allChecked: !this.grid.allChecked
      });
    },
    checkRow(item, index) {
      if (typeof item._checked === "undefined") {
        this.$set(item, "_checked", true);
      } else {
        item._checked = !item._checked;
      }
      var allChecked = true;
      for (var i = 0; i < this.data.length; i++) {
        allChecked = allChecked && this.data[i]._checked;
      }
      this.grid.allChecked = allChecked;
      console.log("emit on check row");
      this.$emit("check", {
        currentItem: item,
        index: index,
        _checked: item._checked
      });
    },
    selectRow(item, index) {
      if (item._selected && !this.repeatSelect) return;
      var prevItem = {};
      for (var i = 0; i < this.data.length; i++) {
        if (this.data[i]._selected) {
          prevItem = this.data[i];
          this.data[i]._selected = false;
          break;
        }
      }
      this.$set(item, "_selected", true);
      console.log("emit on select row");
      this.$emit("select", {
        currentItem: item,
        previousItem: prevItem,
        index,
        selected: item._selected
      });
    },
    sort(col) {
      if (!col.isSortable) return;
      for (var i = 0; i < this.privateColumns.length; i++) {
        this.$set(this.privateColumns[i], "_sorted", false);
      }
      col._sorted = true;
      //_order: true: ASC, false: DESC
      if (typeof col._order === "undefined") {
        this.$set(col, "_order", true);
      } else {
        col._order = !col._order;
      }
      console.log("emit on sort");
      this.$emit("sort", {
        sortBy: col
      });
    },
    search() {
      if (!this.needSearcher) return;
      console.log("emit search");
      this.$emit("search", {
        searchBy: this.searcher.condition
      });
    },
    resetSearchConditions() {
      this.searcher.condition = "";
    },
    resize() {
      this.$nextTick(function() {
        this.resizeGridWidth();
        this.resizeGridHeight();
        this.calculateColumnWidth();
      });
    },
    uncheckAll() {
      this.grid.allChecked = false;
      for (var i = 0; i < this.data.length; i++) {
        this.$set(this.data[i], "_checked", false);
      }
    },
    selectDefault(index = 0) {
      this.$nextTick(function() {
        if (!this.data.length) return;
        this.selectRow(this.data[index], index);
      });
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.grid-pager-container {
  margin: 0 10px;
  height: 36px;
  position: relative;
}
.grid-pager-wrapper {
  position: absolute;
  right: 0;
  top: 0;
}
.grid-pager {
  float: right;
  margin: 6px 3px;
}
.pager-btn {
  cursor: pointer;
  background-color: #fff;
  color: #383f52;
  line-height: 24px;
  width: 24px;
  text-align: center;
  border-radius: 2px;
}
.pager-btn:hover {
  color: #c39f5a;
}
.pager {
  background-color: #fff;
  overflow: hidden;
}
.pager input,
.pager span,
.pager em {
  display: inline-block;
  line-height: 24px;
  height: 24px;
  vertical-align: baseline;
  margin: 0;
  padding: 0;
  font-size: 14px;
  color: #808080;
  font-family: "microsoft yahei";
  font-weight: 500;
}
.pager input {
  border: 0;
  outline: none;
  width: 30px;
  text-align: right;
  padding-right: 5px;
  color: #333;
}
.pager span {
  padding: 0 8px 0 4px;
  min-width: 26px;
  text-align: left;
}
.grid-pager > div {
  vertical-align: top;
  display: inline-block;
  height: 24px;
}
.grid-slot {
  height: 30px;
  line-height: 30px;
  margin: 3px 0;
  background-color: #4e586f;
  color: #fff;
}
.grid-container {
  overflow: hidden;
  padding: 0 10px 10px 10px;
}
.default-margin {
  margin-top: 10px;
}
.grid {
  box-shadow: 0 1px 3px 1px #777;
}
.grid-header {
  background-color: #4e586f;
  color: #fff;
  overflow: hidden;
  height: 30px;
  font-weight: bold;
  line-height: 30px;
}
.grid-header-content {
  width: 200%;
  position: relative;
  left: 0;
  top: 0;
}
.grid-body {
  overflow: auto;
}
.grid-header-cell {
  float: left;
  position: relative;
  min-width: 100px;
}
.grid-header-text {
  text-align: center;
  color: #fff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-dragger {
  position: absolute;
  top: 0;
  right: 0;
  border-right: 1px solid #fff;
  cursor: col-resize;
  height: 36px;
  width: 4px;
}
.grid-dragger-shadow {
  position: absolute;
  z-index: 1;
  display: none;
  top: 0;
  right: 0;
  height: 36px;
  width: 1px;
  border-right: 1px solid #777;
}
.grid-cell {
  min-width: 100px;
  height: 22px;
  line-height: 22px;
  float: left;
  text-align: center;
  border-right: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-row {
  cursor: pointer;
  color: #000;
}
.grid-row-even {
  background-color: #e9e7e7;
}
.grid-row-noentry {
  position: relative;
  color: #777;
  text-align: center;
  height: 22px;
  line-height: 22px;
}
.grid-row-noentry .message {
  position: absolute;
  top: 0;
  left: 0;
}
.grid-row:hover {
  background-color: lightblue;
}
.grid-row-selected {
  background-color: lightblue;
}
.grid-col-sort {
  position: absolute;
  right: 0;
  top: 0;
  margin-right: 6px;
  text-align: center;
  cursor: pointer;
}
.grid-col-sort:hover {
  color: #ccc;
}
.grid-searcher {
  float: right;
  margin: 6px 3px 6px;
}
.grid-searcher input {
  outline: none;
  border: 0;
  width: 100px;
  height: 24px;
  padding-left: 5px;
  margin-bottom: 5px;
}
.btn-search {
  display: inline-block;
  cursor: pointer;
  background-color: #fff;
  color: #383f52;
  line-height: 24px;
  height: 24px;
  width: 24px;
  text-align: center;
}
.btn-search:hover {
  color: #c39f5a;
}
.searcher-input {
  display: inline-block;
  overflow: hidden;
  height: 24px;
  position: relative;
  background-color: #fff;
}
.grid-cell-sortable {
  cursor: pointer;
  padding: 0 18px;
}
.grid-cell-builtin {
  min-width: 50px;
}
</style>
