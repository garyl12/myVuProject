<template>
  <div ref="treeGridWrapper">
    <div class="searcher-container clearfix"  ref="searcher">
      <div class="grid-slot">
        <slot></slot>
      </div>
      <div class="searcher-wrapper">
        <div class="grid-searcher" v-if="needSearcher">
          <div class="search-input">
            <input type="text" v-model="searcher.condition" :placeholder="searcherPlaceholder" @keydown.enter="search"/>
          </div>
          <div class="btn-search">
            <i class="iconfont icon-search" @click="search"></i>
          </div>
        </div>

      </div>
    </div>
    <div class="grid-container" ref="container">
      <div class="grid">
        <div class="grid-header" ref="header" :style="{width:gridWidth+'px'}">
          <div class="grid-header-content clearfix" :style="{width: gridBodyWidth+'px'}" ref="content">
            <div v-for="(col,index) in privateColumns" :key="index" :class="['grid-header-cell', {'grid-cell-sortable': col.isSortable}]" :style="{width: col._columnWidth+'px'}" onselectstart="return false;">
              <div @click="sort(col)" class="grid-header-text">
                <span :title="$t_(col.displayName||col.attributeName)|decorateFieldName(col.displayFormat)" onselectstart="return false;">{{$t_(col.displayName||col.attributeName)|decorateFieldName(col.displayFormat)}}</span>
                <div class="grid-col-sort" v-if="col.isSortable" v-show="col._sorted">
                  <div class="iconfont icon-triangleU font-12" v-show="col._sorted&&col._order"></div>
                  <div class="iconfont icon-triangleD font-12" v-show="col._sorted&&!col._order"></div>
                </div>
              </div>
              <div class="grid-dragger" @mousedown="bindDrag(col, index, $event)" onselectstart="return false;"></div>
              <div class="grid-dragger-shadow"></div>
            </div>
          </div>
        </div>
        <div class="grid-body" ref="body" :style="{width:gridWidth+'px'}" @scroll="scrollX">
           <div :style="{width: gridBodyWidth+'px'}">
              <tree-grid-row 
                :repeat-select="repeatSelect"
                :columns="privateColumns"
                :data="data"
                :data-loader="dataLoader"
                :child-attribute="childAttribute"
                :plain="plain"
                @select="selectRow"
                ref="treeGridRow" />
            <div v-show="!data.length" class="grid-row grid-row-noentry">{{$t_("No_Record")}}</div>
           </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import NumberField from "@/components/fields/NumberUIField";
import DateField from "@/components/fields/DateUIField";
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import TreeGridRow from "@/components/common/TreeGridRow";
import { SIZE } from "@/consts";
import { clone, isNumber } from "@/utils";

export default {
  name: "TreeGrid",
  components: {
    TreeGridRow
  },
  props: {
    columns: {
      type: Array,
      required: true
    },
    data: {
      required: true,
      type: Array
    },
    needSearcher: Boolean,
    searcherPlaceholder: String,
    condition: String,
    dataLoader: {
      type: Function,
      required: true
    },
    childAttribute: {
      type: String,
      required: true
    },
    mainColumnWidth: {
      type: String,
      validator: function(value) {
        let regexp = /^[1-9]([0-9])?%$/;
        return regexp.test(value);
      }
    },
    repeatSelect: Boolean,
    plain: Boolean
  },
  data() {
    return {
      searcher: {
        condition: ""
      },
      grid: {
        mainColumnWidth: 0.3,
        currentSelectedItem: null
      },
      privateColumns: [],
      gridWidth: 0,
      gridBodyOverflowY: false,
      resizeHandler: () => {
        this.resize();
      }
    };
  },
  computed: {
    gridBodyWidth() {
      let width = 0;
      this.privateColumns.forEach((col, index) => {
        width += col._columnWidth;
      });
      return width;
    }
  },
  watch: {
    columns() {
      this.privateColumns = clone(this.columns);
      this.calculateColumnWidth();
    },
    condition() {
      this.searcher.condition = this.condition;
    }
  },
  beforeMount() {
    if (this.$options.propsData.mainColumnWidth) {
      let mainColumnWidth = this.$options.propsData.mainColumnWidth;
      this.$data.grid.mainColumnWidth =
        Number(mainColumnWidth.substr(0, mainColumnWidth.length - 1)) / 100;
    }
  },
  mounted() {
    this.privateColumns = clone(this.columns);
    this.bindWindowResize();
    this.resize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    bindWindowResize() {
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.resizeHandler);
    },
    resizeGridWidth() {
      console.log()
      this.gridWidth =
        this.$refs.treeGridWrapper.parentNode.clientWidth - SIZE.GRID.H_PADDING;
    },
    resizeGridHeight() {
      let searcherHeight = this.$refs.searcher.offsetHeight,
        entireGridHeight = this.$refs.treeGridWrapper.parentNode.clientHeight;
      let gridBodyHeight =
        entireGridHeight -
        searcherHeight -
        SIZE.GRID.HEADER_HEIGHT -
        SIZE.GRID.PADDING_BOTTOM;
      this.$refs.body.style.height = gridBodyHeight + "px";
      this.gridBodyOverflowY =
        this.$refs.body.offsetWidth !== this.$refs.body.clientWidth;
    },
    calculateColumnWidth() {
      if (this.privateColumns.length) {
        let mainColumnWidth = this.gridWidth * this.grid.mainColumnWidth;
        if (this.privateColumns.length === 1) {
          mainColumnWidth = this.gridWidth;
        }
        mainColumnWidth = Math.max(mainColumnWidth, SIZE.GRID.COLUMN_MIN_WIDTH);
        let otherColumnWidth = 0;
        if (this.privateColumns.length > 1) {
          otherColumnWidth =
            (this.gridWidth - mainColumnWidth) /
            (this.privateColumns.length - 1);
        }
        otherColumnWidth = Math.max(
          otherColumnWidth,
          SIZE.GRID.COLUMN_MIN_WIDTH
        );
        mainColumnWidth =
          this.gridWidth - otherColumnWidth * (this.privateColumns.length - 1);
        mainColumnWidth = Math.max(mainColumnWidth, SIZE.GRID.COLUMN_MIN_WIDTH);
        this.privateColumns.forEach((col, index) => {
          if (index) {
            this.$set(col, "_columnWidth", otherColumnWidth);
          } else {
            this.$set(col, "_columnWidth", mainColumnWidth);
          }
        });
      }
    },
    scrollX() {
      this.$refs.content.style.left = -this.$refs.body.scrollLeft + "px";
    },
    bindDrag(col, colIndex, e) {
      var ele = e.srcElement || e.target,
        currentCell = ele.parentNode,
        draggerShadow = ele.nextElementSibling,
        originalX = event.clientX,
        offsetX = 0,
        maxOffsetX = -Math.max(
          0,
          this.gridBodyWidth -
            this.gridWidth +
            (this.gridBodyOverflowY ? SIZE.SCROLL_BAR_WIDTH : 0)
        ),
        mouseMoveHandler = event => {
          offsetX = event.clientX - originalX;
          draggerShadow.style.right = -offsetX + "px";
          draggerShadow.style.display = "";
        },
        gridResize = () => {
          draggerShadow.style.display = "none";
          if (offsetX < maxOffsetX) {
            offsetX = maxOffsetX;
          }
          var width = Math.ceil(currentCell.offsetWidth + offsetX);
          // column min width is 100px
          width = Math.max(width, SIZE.GRID.COLUMN_MIN_WIDTH);
          col._columnWidth = width;
        },
        mouseUpHandler = event => {
          document.removeEventListener("mousemove", mouseMoveHandler, false);
          gridResize();
          document.removeEventListener("mouseup", mouseUpHandler, false);
        };
      document.addEventListener("mouseup", mouseUpHandler, false);
      document.addEventListener("mousemove", mouseMoveHandler, false);
    },
    selectRow({ currentItem, parent, index }) {
      if (this.grid.currentSelectedItem) {
        this.grid.currentSelectedItem._selected = false;
      }
      currentItem._selected = true;
      this.$emit("select", {
        previousItem: this.grid.currentSelectedItem,
        currentItem,
        parent,
        index
      });
      this.grid.currentSelectedItem = currentItem;
    },
    selectDefault() {
      this.$refs.treeGridRow.selectDefault();
    },
    sort(col) {
      if (!col.isSortable) return;
      for (var i = 0; i < this.privateColumns.length; i++) {
        this.$set(this.privateColumns[i], "_sorted", false);
      }
      col._sorted = true;
      //_order: true: ASC, false: DESC
      if (typeof col._order === "undefined") {
        this.$set(col, "_order", true);
      } else {
        col._order = !col._order;
      }
      console.log("sorting");
      this.recursiveSort(this.data, col.attributeName, col._order);
    },
    recursiveSort(data, attr, isAsc) {
      let isNum = !data.some(item => {
        // try to find string, ignore null or empty string
        return (
          item.attributes[attr] &&
          item.attributes[attr].value &&
          !isNumber(item.attributes[attr].value)
        );
      });
      data.sort((a, b) => {
        let result = 0;
        a = a.attributes;
        b = b.attributes;
        if (a[attr] && b[attr]) {
          if (a[attr].value !== b[attr].value) {
            if (isNum) {
              result = Number(a[attr].value) > Number(b[attr].value) ? 1 : -1;
            } else {
              result = a[attr].value > b[attr].value ? 1 : -1;
            }
          }
        } else if (a[attr]) {
          result = 1;
        } else if (b[attr]) {
          result = -1;
        }
        return isAsc ? result : -result;
      });
      data.forEach(item => {
        if (item.children && item.children.length) {
          this.recursiveSort(item.children, attr, isAsc);
        }
      });
    },
    search() {
      if (!this.needSearcher) return;
      console.log("emit on search");
      this.$emit("search", {
        searchBy: this.searcher.condition
      });
    },
    resize() {
      this.resizeGridWidth();
      this.resizeGridHeight();
      this.calculateColumnWidth();
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.searcher-container {
  margin: 0 10px;
  height: 36px;
  position: relative;
}
.grid-slot {
  height: 36px;
  line-height: 36px;
}
.grid-container {
  padding: 0 10px 10px 10px;
}
.grid {
  box-shadow: 0 1px 3px 1px #777;
}
.grid-header {
  background-color: #4e586f;
  color: #fff;
  height: 30px;
  font-weight: bold;
  line-height: 30px;
  overflow: hidden;
}
.grid-header-content {
  position: relative;
  left: 0;
  top: 0;
}
.grid-body {
  overflow: auto;
}
.tree-column {
  float: left;
  height: 30px;
  border-right: 1px solid #fff;
}
.grid-header-cell {
  float: left;
  position: relative;
  min-width: 100px;
}
.grid-header-text {
  text-align: center;
  color: #fff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-dragger {
  position: absolute;
  top: 0;
  right: 0;
  border-right: 1px solid #fff;
  cursor: col-resize;
  height: 36px;
  width: 4px;
}
.grid-dragger-shadow {
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  height: 36px;
  z-index: 1;
  width: 1px;
  border-right: 1px solid #777;
}
.grid-cell {
  min-width: 100px;
  height: 24px;
  line-height: 24px;
  float: left;
  text-align: center;
  border-right: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-row {
  cursor: pointer;
  background-color: #fff;
  color: #000;
}
.grid-row-noentry {
  color: #777;
  text-align: center;
  height: 36px;
  line-height: 36px;
}
.grid-row:hover {
  background-color: #e9e7e7;
}
.grid-row-selected {
  background-color: #e9e7e7;
}
.grid-col-sort {
  position: absolute;
  right: 0;
  top: 0;
  margin-right: 6px;
  text-align: center;
  cursor: pointer;
}
.grid-col-sort:hover {
  color: #ccc;
}
.searcher-wrapper {
  position: absolute;
  top: 0;
  right: 0;
}
.grid-searcher {
  float: right;
  margin: 6px 3px;
  background-color: #fff;
}
.grid-searcher input {
  outline: none;
  border: 0;
  width: 100px;
  padding-left: 5px;
  margin-top: 5px;
}
.btn-search {
  display: inline-block;
  cursor: pointer;
  background-color: #fff;
  color: #383f52;
  line-height: 24px;
  height: 24px;
  width: 24px;
  text-align: center;
  border-radius: 2px;
  vertical-align: top;
}
.btn-search:hover {
  color: #c39f5a;
}
.search-input {
  display: inline-block;
  height: 24px;
}
.grid-cell-sortable {
  cursor: pointer;
  padding: 0 18px;
}
.grid-cell-builtin {
  min-width: 50px;
}
</style>
