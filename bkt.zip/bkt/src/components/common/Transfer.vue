<template>
  <div class="container clearfix">
    <div class="options-area">
      <div class="title">{{ $t_(title) }}</div>
      <div class="options-container">
        <div v-for="(option, index) in leftOptions" 
          :key="index" :title="option" 
          @click="select(option, option.id, false)" 
          :class="['option', {'checked': (!current.fromRight && option.id === current.id),'option-even': index%2}]"
          >
         <span class="cell"> {{option.id}}</span> <span class="cell"> {{option.name}}</span>
        </div>
        <div v-show="!options.length" class="no-entry" >{{$t_("no_record")}}</div>
      </div>
    </div>
    <div class="buttons-area">
      <div class="title"></div>
      <div class="button" @click="add">
        <i class="iconfont icon-aro-r"></i>
      </div>
      <div class="button" @click="remove">
        <i class="iconfont icon-aro-l"></i>
      </div>
      <div class="button" @click="addAll">
        <i class="iconfont icon-dbAroRight"></i>
      </div>
      <div class="button" @click="removeAll">
        <i class="iconfont icon-dbAroLeft"></i>
      </div>
      <div class="button" @click="reset">
        <i class="iconfont icon-reset"></i>
      </div>
    </div>
    <div class="options-area">
      <div class="title">{{ $t_('selected') }}</div>
      <div class="options-container">
        <div 
          v-for="(option, index) in rightOptions" :key="index" :title="option" 
          :class="['option', {'checked': (current.fromRight && option.id === current.id),'option-even': index%2}]"
          @click="select(option, option.id, true)" 
          >
        <span class="cell"> {{option.id}}</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { clone } from "@/utils";

export default {
  name: "Transfer",
  props: {
    options: {
      type: Array,
      required: true
    },
    selectedOptions: {
      type: Array
    },
    title: {
      type: String,
      default: "Options"
    }
  },
  data() {
    return {
      current: {
        option: "",
        id: null,
        fromRight: false
      },
      selectedMap: {},
      selectItems: []
    };
  },
  computed: {
    leftOptions() {
      let options = [];
      this.options.forEach(opt => {
        if (!this.selectedMap[opt]) {
          options.push(opt);
        }
      });
      return options;
    },
    rightOptions() {
      let options = [];
      for (let opt in this.selectedMap) {
        if (this.selectedMap[opt]) {
          options.push(this.selectedMap[opt]);
        }
      }
      return options;
    }
  },
  mounted() {
    this.reset();
  },
  methods: {
    emitValue() {
      let list = this.rightOptions,
        ids = list.map(item => item.id);
      this.$emit("input", ids);
    },
    select(option, id, fromRight) {
      this.current = {
        option,
        id,
        fromRight
      };
    },
    add() {
      if (this.current.fromRight) return;
      this.current.fromRight = true;
      this.$set(this.selectedMap, this.current.id, this.current.option);
      this.selectItems.push(this.current.option);
      this.emitValue();
    },
    remove() {
      if (!this.current.fromRight) return;
      this.current.fromRight = false;
      this.$set(this.selectedMap, this.current.id, false);
      this.emitValue();
    },
    addAll() {
      this.options.forEach(opt => {
        this.$set(this.selectedMap, opt.id, opt);
      });
      this.current = {
        option: "",
        id: null,
        fromRight: false
      };
      this.emitValue();
    },
    removeAll() {
      this.selectedMap = {};
      this.current = {
        option: "",
        id: null,
        fromRight: false
      };
      this.emitValue();
    },
    reset() {
      this.selectedMap = {};
      if (this.selectedOptions) {
        // 还原传入数值
        this.selectedOptions.forEach(opt => {
          this.$set(this.selectedMap, opt, { id: opt });
        });
      }
      this.current = {
        option: "",
        id: null,
        fromRight: false
      };
      this.emitValue();
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.container {
  min-height: 260px;
  height: 100%;
}
.title {
  height: 30px;
  line-height: 30px;
  text-align: center;
  background-color: #bfcbd9;
  font-size: 1.2em;
}
.options-area {
  float: left;
  width: calc(50% - 25px);
  height: 100%;
  border-left: 1px solid #bfcbd9;
  border-right: 1px solid #bfcbd9;
}
.options-container {
  height: calc(100% - 30px);
  overflow-y: auto;
}
.option {
  height: 20px;
  line-height: 20px;
  padding: 0 10px;
  cursor: pointer;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.option .cell {
  display: inline-block;
  width: 50%;
  text-align: left;
}
.option-even {
  background-color: #e9e7e7;
}
.checked {
  background-color: #20a0ff;
}
.buttons-area {
  float: left;
  width: 50px;
  height: 100%;
}
.button {
  margin: 20px auto;
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  text-align: center;
  cursor: pointer;
  width: 24px;
  height: 24px;
  line-height: 24px;
}
.button:hover {
  background-color: #bfcbd9;
}
.no-entry {
  text-align: center;
  color: #777;
}
</style>
