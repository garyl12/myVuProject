<template>
  <div class="grid-tree-cell clearfix" :style="{width:column._columnWidth+'px'}">
    <div style="float:left">
      <div v-for="d in rowDepth" :key="d" class="pad"></div>
      <div class="button" v-show="data._expanded" @click.stop="fold(data)"><i class="iconfont icon-minus1 icon-12"/></div>
      <div class="button" v-show="!data._expanded" @click.stop="expand(data)"><i class="iconfont icon-plus1 icon-12"/></div>
    </div>
    <span class="tree-cell-text" :title="(data.attributes[column.attributeName] || { value: '' }).value | formatDisplay(column.displayFormat)"
      >{{(data.attributes[column.attributeName] || { value: "" }).value | formatDisplay(column.displayFormat)}}</span>
  </div>
</template>

<script>
export default {
  name: "GridTreeCell",
  props: {
    column: {
      type: Object,
      required: true
    },
    data: {
      type: Object,
      required: true
    },
    rowDepth: {
      type: Number,
      required: true
    },
    dataLoader: {
      type: Function,
      required: true
    },
    childAttribute: {
      type: String,
      required: true
    }
  },
  methods: {
    expand(data) {
      if (!data[this.childAttribute] || !data[this.childAttribute].length) {
        this.dataLoader(data).then(children => {
          if (children) {
            this.$set(data, "_expanded", true);
            this.$set(data, this.childAttribute, children);
          }
        });
      } else {
        this.$set(data, "_expanded", true);
      }
    },
    fold(data) {
      data._expanded = false;
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.pad {
  float: left;
  width: 12px;
  height: 24px;
}
.button {
  float: left;
  cursor: pointer;
  width: 24px;
  height: 22px;
  line-height: 22px;
}
.grid-tree-cell {
  padding-left: 5px;
  text-align: left;
  float: left;
  height: 24px;
  border-right: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  min-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.tree-cell-text {
  line-height: 22px;
}
</style>