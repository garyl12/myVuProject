<template>
  <div>
    <div :class="['grid-row',{'grid-row-selected':data._selected}]" @click="select">
      <grid-tree-cell
        v-if="columns.length"
        :data="data"
        :column="columns[0]"
        :data-loader="dataLoader"
        :row-depth="rowDepth"
        :child-attribute="childAttribute"
        />
      <grid-cell 
        v-for="(col,index) in columns"
        v-if="index"
        :key="index"
        :column="col"
        :data="data"
        />
    </div>
    <grid-tree-row
      v-if="data[childAttribute]"
      v-show="data._expanded"
      v-for="(row,index) in data[childAttribute]"
      :key="index"
      :row-index="rowIndex"
      :data="row"
      :columns="columns"
      :row-depth="rowDepth+1"
      :data-loader="dataLoader"
      :parent="data"
      :child-attribute="childAttribute"
      :repeat-select="repeatSelect"
      @select="broadcastSelect"
    />
  </div>
</template>

<script>
import GridTreeCell from "./AdvancedGridTreeCell";
import GridCell from "./AdvancedGridCell";

export default {
  name: "GridTreeRow",
  components: {
    GridTreeCell,
    GridCell
  },
  props: {
    columns: {
      type: Array,
      required: true
    },
    data: {
      type: Object,
      required: true
    },
    rowIndex: {
      type: Number,
      required: true
    },
    childAttribute: {
      type: String,
      required: true
    },
    parent: Object,
    rowDepth: {
      type: Number,
      required: true
    },
    dataLoader: {
      type: Function,
      required: true
    },
    repeatSelect: Boolean
  },
  methods: {
    select() {
      if (this.data._selected && !this.repeatSelect) return;
      this.$set(this.data, "_selected", true);
      this.$emit("select", {
        currentItem: this.data,
        parent: this.parent,
        index: this.rowIndex
      });
    },
    broadcastSelect(payload) {
      this.$emit("select", payload);
    }
  }
};
</script>

<style scoped>
.grid-row {
  height: 24px;
  cursor: pointer;
}
.grid-row:hover {
  background-color: #e9e7e7;
}
.grid-row-selected {
  background-color: #e9e7e7;
}
</style>