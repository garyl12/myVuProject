<template>
  <div v-if="column.columns&&column.columns.length" class="grid-cell-cluster" :style="{width:column._columnWidth+'px'}">
    <grid-cell
      v-for="(col,index) in column.columns"
      v-show="!column._folded||(column.keyColumns||[column.columns[0].attributeName]).some(c=>c===col.attributeName)"
      :key="index"
      :column="col"
      :data="data"
      />
  </div>
  <div v-else class="grid-cell" :style="{width:column._columnWidth+'px'}">
    <span :title="(this.data.attributes[column.attributeName] || { value: '' }).value | formatDisplay(column.displayFormat)"
      >{{(this.data.attributes[column.attributeName] || { value: "" }).value | formatDisplay(column.displayFormat)}}</span>
  </div>
</template>

<script>
export default {
  name: "GridCell",
  props: {
    column: {
      required: true,
      type: Object
    },
    data: {
      required: true,
      type: Object
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.grid-cell,
.grid-cell-cluster {
  float: left;
  height: 24px;
  line-height: 24px;
}
.grid-cell {
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border-right: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  min-width: 100px;
}
</style>
