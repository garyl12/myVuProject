<template>
  <div ref="treeGridWrapper" style="height:100%">
    <div class="grid-top clearfix" ref="top">
      <div class="grid-outside">
        <slot></slot>
      </div>
      <div :class="['grid-default-searcher',{'grid-default-searcher-margin':!data.length}]" v-if="needSearcher">
        <div class="default-search-input">
          <input type="text" v-model="searcher.defaultCondition" :placeholder="defaultSearcher.placeholder" @keydown.enter="defaultSearch"/>
        </div>
        <div class="btn-default-search">
          <i class="iconfont icon-search" v-show="!searcher.isSearching" @click="defaultSearch"></i>
          <i class="iconfont icon-close1" v-show="searcher.isSearching"  @click="clearDefaultSearch"></i>
        </div>
      </div>
    </div>
    <div class="grid-container" ref="container">
      <div class="grid" :style="{width:gridWidth+'px'}">
        <div class="grid-header clearfix" ref="header" :style="{width:gridWidth+'px',height: columnDepth*30+'px'}">
          <div class="grid-header-content" :style="{width:gridBodyWidth+'px',height: columnDepth*30+'px'}" ref="content">
            <grid-header
              :columns="privateColumns"
              :column-depth="columnDepth"
              @drag="startDragColumn"
              />
          </div>
        </div>
        <div class="grid-body" ref="body" :style="{width:gridWidth+'px'}" @scroll="scrollX">
           <div :style="{width: gridBodyWidth+'px'}">
              <grid-tree-row 
                v-for="(item,index) in data"
                :key="index"
                :row-index="index"
                :data="item"
                :columns="privateColumns"
                :data-loader="dataLoader"
                :row-depth="0"
                :parent="null"
                :child-attribute="childAttribute"
                :repeat-select="repeatSelect"
                @select="selectRow"
                />
            <div v-show="!data.length" class="grid-row grid-row-noentry" :style="{width: gridBodyWidth+'px'}">
              <div :style="{width:gridWidth+'px'}" class="message" ref="noEntryMessage">{{$t_("No_Record")}}</div>
            </div>
           </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import NumberField from "@/components/fields/NumberUIField";
import DateField from "@/components/fields/DateUIField";
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import GridHeader from "./AdvancedGridHeader";
import GridTreeRow from "./AdvancedGridTreeRow";
import { SIZE } from "@/consts";
import { clone } from "@/utils";

const processColumns = function(columns, parent = null) {
  let depth = 1;
  let childCount = 0;
  columns.forEach(col => {
    col._parent = parent;
    if (col.columns && col.columns.length) {
      let result = processColumns(col.columns, col);
      depth = Math.max(depth, result.depth + 1);
      col._childCount = result.childCount;
      childCount += result.childCount;
    } else {
      col._childCount = 0;
      childCount += 1;
    }
  });
  return {
    depth,
    childCount
  };
};

const bubbleWidthGrowth = function(column, widthGrowth) {
  let parent = column._parent;
  while (parent) {
    parent._columnWidth += widthGrowth;
    parent = parent._parent;
  }
};
const propagateWidthGrowth = function(column, widthGrowth) {
  if (column.columns && column.columns.length) {
    if (column._folded) {
      // if current column is folded, only the key columns and its sub columns will spread
      if (column.keyColumns) {
        column.keyColumns.forEach(col => {
          propagateWidthGrowth(col, widthGrowth);
        });
      } else {
        column.columns[0]._columnWidth += widthGrowth;
        propagateWidthGrowth(column.columns[0], widthGrowth);
      }
    } else {
      widthGrowth = widthGrowth / column.columns.length;
      column.columns.forEach(function(col) {
        col._columnWidth += widthGrowth;
        propagateWidthGrowth(col, widthGrowth);
      });
    }
  }
};

export default {
  name: "AdvancedTreeGrid",
  components: {
    NumberField,
    DateField,
    TextField,
    DropdownlistField,
    GridHeader,
    GridTreeRow
  },
  props: {
    columns: {
      type: Array,
      required: true
    },
    data: {
      required: true,
      type: Array
    },
    dataLoader: {
      type: Function,
      required: true
    },
    childAttribute: {
      type: String,
      required: true
    },
    needSearcher: Boolean,
    repeatSelect: Boolean
  },
  data() {
    return {
      searcher: {
        showAll: false,
        needSearch: false,
        searchConditions: [],
        defaultCondition: "",
        isSearching: false
      },
      currentSelectedItem: null,
      privateColumns: [],
      columnDepth: 1,
      columnCount: 0,
      gridContainerWidth: 0,
      gridBodyOverflowY: false,
      resizeHandler: () => {
        this.resize();
      }
    };
  },
  computed: {
    gridWidth() {
      return Math.min(this.gridContainerWidth, this.gridBodyWidth);
    },
    gridBodyWidth() {
      let width = 0;
      this.privateColumns.forEach((col, index) => {
        width += col._columnWidth;
      });
      return width;
    }
  },
  watch: {
    columns() {
      let columns = clone(this.columns);
      let result = processColumns(columns);
      this.privateColumns = columns;
      this.columnDepth = result.depth;
      this.columnCount = result.childCount;
      this.resizeGridHeight();
      this.calculateColumnWidth();
    }
  },
  mounted() {
    let columns = clone(this.columns);
    let result = processColumns(columns);
    this.columnDepth = result.depth;
    this.columnCount = result.childCount;
    this.privateColumns = columns;
    this.bindWindowResize();
    this.resize();
  },
  beforeDestroy() {
    this.unbindWindowResize();
  },
  methods: {
    bindWindowResize() {
      window.addEventListener("resize", this.resizeHandler);
    },
    unbindWindowResize() {
      window.removeEventListener("resize", this.resizeHandler);
    },
    resizeGridWidth() {
      this.gridContainerWidth =
        this.$refs.treeGridWrapper.parentNode.clientWidth - SIZE.GRID.H_PADDING;
    },
    resizeGridHeight() {
      let topHeight = this.$refs.top.offsetHeight,
        entireGridHeight = this.$refs.treeGridWrapper.clientHeight;
      let gridBodyHeight =
        entireGridHeight -
        topHeight -
        SIZE.GRID.HEADER_HEIGHT * this.columnDepth -
        SIZE.GRID.PADDING_BOTTOM;
      this.$refs.body.style.height = gridBodyHeight + "px";
      this.calculateBodyOverflow();
    },
    calculateBodyOverflow() {
      this.gridBodyOverflowY =
        this.$refs.body.offsetWidth !== this.$refs.body.clientWidth;
    },
    calculateColumnWidth() {
      if (this.privateColumns.length) {
        let columnWidth = this.gridContainerWidth / this.columnCount;
        columnWidth = Math.max(columnWidth, SIZE.GRID.COLUMN_MIN_WIDTH);
        this.updateColumnWidth(this.privateColumns, columnWidth);
      }
    },
    updateColumnWidth(columns, width) {
      columns.forEach(col => {
        let columnWidth = (col._childCount || 1) * width;
        this.$set(col, "_columnWidth", columnWidth);
        this.$set(col, "_baseWidth", columnWidth);
        if (col.columns) {
          this.updateColumnWidth(col.columns, width);
        }
      });
    },
    resetColumnWidth(columns) {
      columns.forEach(col => {
        col._columnWidth = col._baseWidth;
        if (col.columns) {
          this.resetColumnWidth(col.columns);
        }
      });
    },
    startDragColumn({ col, colIndex, e }) {
      let ele = e.srcElement || e.target,
        currentCell = ele.parentNode,
        draggerShadow = ele.nextElementSibling,
        originalX = event.clientX,
        offsetX = 0,
        mouseMoveHandler = event => {
          offsetX = event.clientX - originalX;
          draggerShadow.style.right = -offsetX + "px";
          draggerShadow.style.display = "";
        },
        resizeColumn = () => {
          draggerShadow.style.display = "none";
          // if drag to narrow column, reset column to base width
          if (offsetX < 0) {
            this.resetColumnWidth(this.privateColumns);
          } else {
            let width = currentCell.offsetWidth + offsetX;
            let widthGrowth = width - col._columnWidth;
            col._columnWidth = width;
            bubbleWidthGrowth(col, widthGrowth);
            propagateWidthGrowth(col, widthGrowth);
          }
        },
        mouseUpHandler = function(event) {
          document.removeEventListener("mousemove", mouseMoveHandler, false);
          resizeColumn();
          document.removeEventListener("mouseup", mouseUpHandler, false);
        };
      document.addEventListener("mouseup", mouseUpHandler, false);
      document.addEventListener("mousemove", mouseMoveHandler, false);
    },
    scrollX() {
      this.$refs.content.style.left = -this.$refs.body.scrollLeft + "px";
      this.$refs.noEntryMessage.style.left = this.$refs.body.scrollLeft + "px";
    },
    selectRow({ currentItem, parent, index }) {
      if (this.currentSelectedItem) {
        this.currentSelectedItem._selected = false;
      }
      currentItem._selected = true;
      this.$emit("select", {
        previousItem: this.currentSelectedItem,
        currentItem,
        parent,
        index
      });
      this.currentSelectedItem = currentItem;
    },
    selectDefault() {
      this.$refs.treeGridRow.selectDefault();
    },
    search() {
      if (!this.searcher.needSearch) return;
      console.log("emit on search");
      this.getSearchConditions();
      this.searcher.needSearch = false;
      this.$emit("search", {
        sortBy: this.getSortbyColumn(),
        searchBy: this.searcher.searchConditions
      });
    },
    defaultSearch() {
      if (this.searcher.defaultCondition || this.searcher.isSearching) {
        this.searcher.searchConditions = this.searcher.defaultCondition;
        this.searcher.isSearching = this.searcher.defaultCondition !== "";
        console.log("emit on search");
        this.$emit("search", {
          sortBy: this.getSortbyColumn(),
          searchBy: this.searcher.searchConditions
        });
      }
    },
    clearDefaultSearch() {
      this.searcher.isSearching = false;
      this.searcher.searchConditions = this.searcher.defaultCondition = "";
      console.log("emit on search");
      this.$emit("search", {
        sortBy: this.getSortbyColumn(),
        searchBy: this.searcher.searchConditions
      });
    },
    resize() {
      this.$nextTick(function() {
        this.resizeGridWidth();
        this.resizeGridHeight();
        this.calculateColumnWidth();
      });
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.grid-top {
  margin: 0 10px;
  height: 36px;
}
.grid-outside {
  height: 36px;
  line-height: 36px;
}
.grid-container {
  padding: 0 10px 10px 10px;
}
.grid {
  box-shadow: 0 1px 3px 1px #777;
}
.grid-header {
  background-color: #4e586f;
  color: #fff;
  font-weight: bold;
  overflow: hidden;
}
.grid-header-content {
  position: relative;
  left: 0;
  top: 0;
}
.grid-body {
  overflow: auto;
}
.grid-row {
  cursor: pointer;
  background-color: #fff;
  color: #000;
}
.grid-row-noentry {
  position: relative;
  color: #777;
  text-align: center;
  height: 36px;
  line-height: 36px;
}
.grid-row-noentry .message {
  position: absolute;
  top: 0;
  left: 0;
}
.grid-row:hover {
  background-color: #e9e7e7;
}
.searcher-top {
  margin: 0 10px;
  padding: 3px 0;
  height: 30px;
}
.btn-search {
  float: left;
  height: 24px;
  background-color: #383f52;
  color: #fff;
  border-radius: 4px;
  line-height: 24px;
  font-size: 12px;
  padding: 0 10px;
  cursor: pointer;
}
.btn-search-disable {
  background-color: #cccccc;
  cursor: not-allowed;
  border-radius: 0;
}
.btn-showall {
  cursor: pointer;
  float: right;
  height: 24px;
  line-height: 24px;
  font-size: 12px;
}
.searcher-wrapper {
  border-top: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  margin: 0 10px;
  padding: 10px 0;
}
.searcher-container-min {
  max-height: 60px;
  overflow: hidden;
}
.search-field {
  float: left;
  width: 16%;
  height: 24px;
  margin: 2px 0 0;
}
.grid-default-searcher {
  float: right;
  margin: 4px 10px 4px;
}
.grid-default-searcher input {
  outline: none;
  border: 0;
  width: 100px;
  padding-left: 5px;
  margin-top: 5px;
}
.grid-default-searcher-margin {
  margin-right: 0;
}
.btn-default-search {
  float: right;
  cursor: pointer;
  background-color: #383f52;
  color: #fff;
  line-height: 28px;
  height: 28px;
  width: 28px;
  text-align: center;
  border-radius: 2px;
}
.btn-default-search:hover {
  background-color: #bf0535;
}
.default-search-input {
  display: inline-block;
  height: 28px;
  border: 1px solid #cccccc;
}
</style>
