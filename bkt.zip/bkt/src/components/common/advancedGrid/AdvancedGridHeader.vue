<template>
  <div>
    <div 
      v-for="(col,index) in columns" 
      v-show="!col._parent||!col._parent._folded||(col._parent.keyColumns||[columns[0].attributeName]).some(c=>c===col.attributeName)"
      :key="index" :class="['grid-header-cell', {'grid-cell-sortable': col.isSortable}]"
      :style="{width: col._columnWidth+'px',height:columnDepth*30+'px'}"
      onselectstart="return false;">
      <div class="grid-header-cell-builtin" v-if="needChecker">
        <input type="checkbox" @click="checkAll" ref="checker">
        <div class="grid-dragger" />
      </div>
      <div class="grid-header-cell-builtin" v-if="needIndex" :title="$t_('index')">
        <span>{{$t_('index')}}</span>
        <div class="grid-dragger" />
      </div>
      <div v-if="col.columns&&col.columns.length" :style="{height:columnDepth*30+'px'}" class="grid-header-text">
        <i class="iconfont icon-plus font-12 col-btn" v-show="col._folded" @click="expandColumn(col)" />
        <i class="iconfont icon-minus font-12 col-btn" v-show="!col._folded" @click="foldColumn(col)" />
        <span
          :title="$t_(col.displayName)|decorateFieldName(col.displayFormat)"
          onselectstart="return false;">{{$t_(col.displayName)|decorateFieldName(col.displayFormat)}}</span>
        <grid-header
          :columns="col.columns"
          :column-depth="columnDepth-1"
          @drag="broadcastDrag"
          />
      </div>
      <div v-else @click="sort(col)" class="grid-header-text" :style="{'line-height':columnDepth*30+'px'}">
        <span
          :title="$t_(col.displayName)|decorateFieldName(col.displayFormat)"
          onselectstart="return false;">{{$t_(col.displayName)|decorateFieldName(col.displayFormat)}}</span>
        <div class="grid-col-sort" v-if="col.isSortable" v-show="col._sorted">
          <div class="iconfont icon-triangleU font-12" v-show="col._sorted&&col._order" />
          <div class="iconfont icon-triangleD font-12" v-show="col._sorted&&!col._order" />
        </div>
      </div>
      <div class="grid-cell-border-top" />
      <div class="grid-dragger" @mousedown.stop="startDragColumn(col, index, $event)" onselectstart="return false;" />
      <div class="grid-dragger-shadow" />
    </div>
  </div>
</template>

<script>
const bubbleWidthGrowth = function(column, widthGrowth) {
  let parent = column._parent;
  while (parent) {
    parent._columnWidth += widthGrowth;
    parent = parent._parent;
  }
};

export default {
  name: "GridHeader",
  props: {
    needChecker: Boolean,
    needIndex: Boolean,
    columns: {
      required: true,
      type: Array
    },
    columnDepth: {
      required: true,
      type: Number
    }
  },
  methods: {
    broadcastDrag({ col, colIndex, e }) {
      this.$emit("drag", {
        col,
        colIndex,
        e
      });
    },
    startDragColumn(col, colIndex, e) {
      this.$emit("drag", {
        col,
        colIndex,
        e
      });
    },  
    foldColumn(column) {
      this.$set(column, "_folded", true);
      let baseWidth = column._columnWidth;
      let currentWidth = 0;
      column.columns.forEach(c => {
        currentWidth += (
          column.keyColumns || [column.columns[0].attributeName]
        ).some(name => name === c.attributeName)
          ? c._columnWidth
          : 0;
      });
      column._columnWidth = currentWidth;
      let widthGrowth = column._columnWidth - baseWidth;
      bubbleWidthGrowth(column, widthGrowth);
    },
    expandColumn(column) {
      column._folded = false;
      let baseWidth = column._columnWidth;
      let totalWidth = 0;
      column.columns.forEach(col => {
        totalWidth += col._columnWidth;
      });
      column._columnWidth = totalWidth;
      let widthGrowth = column._columnWidth - baseWidth;
      bubbleWidthGrowth(column, widthGrowth);
    },
    sort(col) {
      this.$emit("sort");
    },
    checkAll() {
      this.$emit("check-all", this.$refs.checker.checked);
    }
  }
};
</script>

<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.grid-header-cell {
  position: relative;
  float: left;
  min-width: 100px;
}
.grid-header-cell-builtin {
  float: left;
  width: 50px;
  text-align: center;
}
.grid-cell-border-top {
  position: absolute;
  width: 100%;
  height: 0;
  border-top: 1px solid #fff;
  top: 0;
  left: 0;
}
.grid-header-text {
  line-height: 30px;
  text-align: center;
  color: #fff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-dragger {
  position: absolute;
  top: 0;
  right: 0;
  border-right: 1px solid #fff;
  cursor: col-resize;
  height: 100%;
  width: 4px;
}
.grid-dragger-shadow {
  position: absolute;
  display: none;
  top: 0;
  right: 0;
  height: 100%;
  z-index: 1;
  width: 1px;
  border-right: 1px solid #777;
}
.col-btn {
  cursor: pointer;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  border: 1px solid #383f52;
}
.col-btn:hover {
  border-color: #fff;
}
</style>
