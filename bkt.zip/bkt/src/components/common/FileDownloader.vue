<template>
    <el-dialog
      width="30%"
      :title="$t_('download_file')"
      :visible="visible"
      :close-on-click-modal="false"
      :show-close="false"
      >
      <div v-for="(type,index) in fileTypes" class="filetype" :key="index" @click="selectType(type)">
        <span>{{type}}</span>
      </div>
      <span slot="footer">
        <el-button @click="cancel()">{{$t_('cancel')}}</el-button>
      </span>
      <div>
        <iframe
          v-for="(url,index) in srcUrls"
          :key="index"
          :src="url"
          v-show="false"></iframe>
      </div>
    </el-dialog>
</template>

<script>
export default {
  name: "FileDownloader",
  props: {
    src: {
      type: String,
      required: true
    },
    visible: Boolean,
    fileTypes: {
      type: Array,
      require: true
    }
  },
  watch: {
    src() {
      if (this.src) {
        this.srcUrls.push(this.src);
      }
    },
    visible(val) {
      if (val) {
        this.typeSettled = false;
      }
    }
  },
  data() {
    return {
      srcUrls: [],
      typeSettled: true
    };
  },
  methods: {
    selectType(type) {
      if (this.typeSettled) return;
      this.$emit("select-type", type);
      this.typeSettled = true;
    },
    cancel() {
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.filetype {
  border: 1px solid #cccccc;
  width: 140px;
  height: 40px;
  line-height: 40px;
  margin: 10px auto;
  text-align: center;
  border-radius: 6px;
  cursor: pointer;
  background-color: #ffffff;
  color: #333;
}
.filetype:hover {
  background-color: goldenrod;
  color: #fff;
}
</style>