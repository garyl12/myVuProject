<template>
  <el-dialog  class="searcher" :title="$t_('search')" :visible="visible"
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false"> 
    <div class="container">
      <div v-for="(field,index) in fields" :key="index" class="search-field">
        <number-range-field
          v-if="field.dataType===FIELD_TYPES.DOUBLE||field.dataType===FIELD_TYPES.INTEGER"
          v-model="currentConditions[field.name]"
          :field-val="currentConditions[field.name]"
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :format="field.displayFormat"
          :min-placeholder="$t_('min_number')"
          :max-placeholder="$t_('max_number')"
          />
        <date-range-field
          v-else-if="field.dataType===FIELD_TYPES.DATE"
          v-model="currentConditions[field.name]"
          :field-val="currentConditions[field.name]"
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :min-date-placeholder="$t_('min_Date')"
          :max-date-placeholder="$t_('max_Date')"
          />
        <dropdownlist-field
          v-else-if="field.dataType===FIELD_TYPES.STRING&&field.enumRef||field.dataType===FIELD_TYPES.BOOLEAN"
          v-model="currentConditions[field.name]"
          :field-val="currentConditions[field.name]"
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :options="dictionary|lookup(field.enumRef)"
          :for-boolean="field.dataType===FIELD_TYPES.BOOLEAN"
          />
        <text-field
          v-else-if="field.dataType===FIELD_TYPES.STRING&&!field.enumRef"
          v-model="currentConditions[field.name]"
          :field-val="currentConditions[field.name]"
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :allow-multi="field.list"
          />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="search" :title="$t_('search')">{{$t_("search")}}</el-button>
      <el-button @click="currentConditions={}" :title="$t_('clear')">{{$t_("clear")}}</el-button>
      <el-button @click="close" :title="$t_('close')">{{$t_("close")}}</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { mapGetters } from "vuex";
import ReferenceSelectorField from "@/components/fields/ReferenceSelectorUIField";
import NumberRangeField from "@/components/fields/NumberRangeUIField";
import DateRangeField from "@/components/fields/DateRangeUIField";
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import { FIELD_TYPES } from "@/consts";
import { clone } from "@/utils";

export default {
  name: "Searcher",
  components: {
    NumberRangeField,
    DateRangeField,
    TextField,
    DropdownlistField
  },
  props: {
    visible: Boolean,
    fields: {
      type: Array,
      default() {
        return [];
      }
    },
    conditions: Array
  },
  data() {
    return {
      effectingConditions: {},
      currentConditions: {}
    };
  },
  computed: {
    ...mapGetters({
      dictionary: "getDicts"
    }),
    FIELD_TYPES() {
      return FIELD_TYPES;
    }
  },
  watch: {
    fields(fields) {
      this.currentConditions = {};
    },
    conditions() {
      this.currentConditions = this.effectingConditions = {};
      if (this.conditions) {
        this.conditions.forEach(condition => {
          this.$set(this.currentConditions, condition.key, condition.value);
          this.$set(this.effectingConditions, condition.key, condition.value);
        });
      }
    }
  },
  methods: {
    getSearchConditions() {
      let conditions = [];
      this.fields.forEach(field => {
        if (this.currentConditions[field.name]) {
          let searchItem = {
            key: field.name,
            value: this.currentConditions[field.name],
            valueType: field.dataType
          };
          conditions.push(searchItem);
        }
      });
      return conditions;
    },
    search() {
      this.effectingConditions = clone(this.currentConditions);
      this.$emit("search", {
        searchBy: this.getSearchConditions()
      });
    },
    close() {
      this.currentConditions = clone(this.effectingConditions);
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.container {
  padding: 5px 5px;
}
.search-field {
  float: left;
  width: 50%;
  height: 22px;
  margin: 2px 0 0;
}
</style>