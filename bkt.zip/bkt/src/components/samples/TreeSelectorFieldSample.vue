<template>
  <div class="sample">
    <tree-selector-field
      field-name="test"
      field-val="val"
      child-attribute="children"
      required="false"
      :tree-loader="treeLoader"
      :search-resolver="searchResolver"
      :value-resolver="valueResolver"
        />
  </div>
</template>

<script>
import TreeSelectorField from "./components/fields/TreeSelectorUIField";

export default {
  name: "TreeSelectorFieldSample",
  components: { TreeSelectorField },
  methods: {
    treeLoader(parent) {
      return new Promise((resolve, reject) => {
        if (parent) {
          if (parent.name == "z1_1") {
            return resolve([]);
          }
          return resolve([{ name: "z1_1", id: "0_1" }]);
        } else {
          return resolve([{ name: "z1", id: "0" }, { name: "z2", id: "2" }]);
        }
      });
    },
    searchResolver() {
      return new Promise((resolve, reject) => {
        return resolve([{ name: "z1", id: "0" }, { name: "z2", id: "2" }]);
      });
    },
    valueResolver(node) {
      return node.name;
    }
  }
};
</script>

<style scoped>
.sample {
  height: 300px;
  width: 200px;
  background-color: #fff;
  color: #000;
}
</style>
