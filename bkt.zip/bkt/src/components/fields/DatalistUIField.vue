<template>
    <div class="field-container clearfix">
        <div class="field-left-cell">
            <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
        </div>
        <div class="field-mid-cell">
            <div class="datalist-container">
                <input class="field-mid-cell-input" type="text" :placeholder="placeholder" v-model="input" @focus="filterOptions" @keyup="filterOptions" @blur="validate" :readonly="readonly">
                <div class="datalist-down-arrow-container" @click="showAllOptions">
                    <div class="datalist-down-arrow"></div>
                </div>
                <div class="datalist-options-container" v-show="showOptions">
                    <div class="datalist-option " v-for="(option, index) in currentOptions" :key="index" @click="selectOption(option)">
                        <span v-if="typeof option === 'string'">{{option}}</span>
                        <div v-else>
                            <div class="datalist-option-display">{{option.displayVal}}</div>
                            <div class="datalist-option-logic">{{option.logicVal}}</div>
                            <div style="clear:both"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="field-right-cell">
            <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
        </div>
    </div>
</template>
<script>
export default {
  name: "DatalistField",
  props: {
    placeholder: String,
    fieldName: {
      type: String,
      required: true
    },
    required: Boolean,
    readonly: Boolean,
    fieldVal: [String, Number],
    options: {
      type: Array,
      required: true
    },
    allowMulti: Boolean
  },
  data() {
    return {
      input: "",
      currentOptions: this.options,
      showOptions: false,
      isValid: true
    };
  },
  beforeMount() {
    var fieldVal = this.$options.propsData.fieldVal;
    if (fieldVal) {
      var options = this.$options.propsData.options;
      if (options.length) {
        if (typeof options[0] !== "string") {
          var self = this;
          options.some(function(item) {
            if (
              fieldVal.toLowerCase() === item.displayVal.toLowerCase() ||
              fieldVal.toLowerCase() === item.logicVal.toLowerCase()
            ) {
              self.$data.input = item.displayVal;
            }
          });
        } else {
          this.$data.input = fieldVal;
        }
      } else {
        throw new Error("Proptery 'options' is empty");
      }
    }
  },
  methods: {
    filterOptions() {
      if (this.readonly) return;
      this.currentOptions = [];
      if (this.input) {
        var self = this;
        self.options.forEach(function(item) {
          if (typeof item === "string") {
            if (item.toLowerCase().indexOf(self.input.toLowerCase()) !== -1) {
              self.currentOptions.push(item);
            }
          } else {
            if (
              item.displayVal
                .toLowerCase()
                .indexOf(self.input.toLowerCase()) !== -1 ||
              item.logicVal.toLowerCase().indexOf(self.input.toLowerCase()) !==
                -1
            ) {
              self.currentOptions.push(item);
            }
          }
        });
      } else {
        this.currentOptions = this.options;
      }
      this.showOptions = this.currentOptions.length > 0;
    },
    showAllOptions() {
      this.showOptions = !this.showOptions;
      this.currentOptions = this.options;
    },
    selectOption(option) {
      if (typeof option === "string") {
        this.input = option;
        this.$emit("input", option);
      } else {
        this.input = option.displayVal;
        this.$emit("input", option.logicVal);
      }
      this.showOptions = false;
      this.isValid = true;
    },
    validate() {
      if (this.readonly) return;
      var self = this;
      //当先在输入框中输入关键字，再点击选项完成输入的时候，会先调用validate方法，导致控件有多余的渲染动作
      //需要使点击响应事件先完成，再进行验证，因此延迟300ms
      setTimeout(function() {
        self.isValid = false;
        self.showOptions = false;
        if (self.input) {
          self.options.some(function(item) {
            if (typeof item === "string") {
              if (item.toLowerCase() === self.input.toLowerCase()) {
                self.isValid = true;
                self.$emit("input", item);
                return true;
              }
            } else {
              if (
                item.displayVal.toLowerCase() === self.input.toLowerCase() ||
                item.logicVal.toLowerCase() === self.input.toLowerCase()
              ) {
                self.isValid = true;
                self.$emit("input", item.logicVal);
                self.input = item.displayVal;
                return true;
              }
            }
          });
        } else {
          self.isValid = !self.required;
          self.$emit("input", null);
        }
      }, 300);
    }
  }
};
</script>
<style scoped>
.field-mid-cell-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 3px 10px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}

.field-mid-cell-input:hover {
  outline: 0;
  border-color: #8391a5;
}

.field-mid-cell-input:focus {
  outline: 0;
  border-color: #20a0ff;
}
.datalist-container {
  position: relative;
}

.datalist-down-arrow-container {
  width: 22px;
  height: 22px;
  position: absolute;
  top: 0;
  right: 0;
}

.datalist-down-arrow {
  margin: 8px;
  border-style: solid;
  border-top: 8px solid #bfcbd9;
  border-right: 4px solid transparent;
  border-bottom: 0px;
  border-left: 4px solid transparent;
}

.datalist-options-container {
  margin-top: 2px;
  border-radius: 4px;
  width: 100%;
  border: 1px solid #bfcbd9;
  position: absolute;
  z-index: 1;
  background-color: #fff;
}

.datalist-option {
  padding-left: 15px;
  height: 32px;
  line-height: 32px;
  font-size: 0.8em;
}

.datalist-option:hover {
  background-color: #e4e8f1;
  cursor: pointer;
}

.datalist-option-display {
  width: 70%;
  float: left;
}

.datalist-option-logic {
  width: 30%;
  float: left;
}
</style>
