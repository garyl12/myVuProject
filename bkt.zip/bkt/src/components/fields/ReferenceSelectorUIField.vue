<template>
  <div class="field-container clearfix">
    <div class="field-left-cell">
      <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell" ref='input'>
      <div class="container clearfix">
        <input class="field-mid-cell-input" v-model="input" :placeholder="placeholder" @change="autoResolve" :title="input" @blur="blur" />
        <i class="selector-switcher iconfont icon-search-accurate font-12" @click="showSelector" />
        <pop-panel
          :visible="panel.visible"
          :width="panelWidth"
          :height="panelHeight"
          @close="panel.visible=false"
          >
          <div class="panel-inner">
            <div style="border-bottom:1px solid #ccc">
              <div class="header-row clearfix">
                <div v-for="(col,index) in columns" :key="index" :class="['cell',{'main-col': col.attributeName===refAttribute}]" :style="{width: col.width+'px'}">
                  <span>{{$t_(col.displayName||col.attributeName)}}</span>
                </div>
              </div>
              <div class="header-row clearfix">
                <div v-for="(col,index) in columns" :key="index" class="cell" :style="{width: col.width+'px'}">
                  <input class="condition" @keyup.enter="search" v-model="panel.condition[col.attributeName]"/>
                </div>
                <div class="cell btn-cell" @click="search"><i class="iconfont icon-search"></i></div>
              </div>
            </div>
            <div class="references">
              <div :class="['row',{'selected-row':item._selected}]" v-for="(item,index) in panel.refs" :key="index" @click="toggleCheck(item)">
                <div :class="['cell',{'main-col':col.attributeName===refAttribute}]"
                  :style="{width: col.width+'px'}"
                  v-for="(col,index) in columns"
                  :key="index" :title="item[col.attributeName]">
                  <input type="checkbox" v-if="allowMulti&&!index" :checked="item._checked" />
                  {{item[col.attributeName]}}
                  </div>
              </div>
            </div>
            <div class="pager clearfix" v-show="panel.refs.length&&panel.pageCount>1">
              <div :class="['btn',{'disabled':panel.currentPage<2}]" @click="prevPage" onselectstart="return false">
                <i class="iconfont icon-aro-left"></i>
              </div>
              <div class="">{{panel.currentPage+" / "+panel.pageCount}}</div>
              <div :class="['btn',{'disabled':panel.currentPage===panel.pageCount}]" @click="nextPage" onselectstart="return false">
                <i class="iconfont icon-aro-right"></i>
              </div>
            </div>
            <div class="preview clearfix" v-if="allowMulti">
              <div class="v-button">
                <div @click="confirm">{{$t_('confirm')}}</div>
                <div @click="clear">{{$t_('clear')}}</div>
              </div>
              <div class="preview-panel">
                <div class="opt">
                  <div @click="moveUp"
                    :class="{disabled:!panel.checkedRefs.length||panel.previewingIndex<1}"
                    >
                    <i class="iconfont icon-aro-up"></i>
                  </div>
                  <div @click="moveDown"
                    :class="{disabled:!panel.checkedRefs.length||panel.previewingIndex===-1||panel.previewingIndex===panel.checkedRefs.length-1}"
                    >
                    <i class="iconfont icon-aro-down"></i>
                  </div>
                </div>
                <div class="list">
                  <div
                    :class="['item',{'selected-item':index===panel.previewingIndex}]"
                    v-for="(item,index) in panel.checkedRefs"
                    :key="index"
                    @click="panel.previewingIndex=index"
                    :title="item">{{item}}</div>
                </div>
              </div>
            </div>
          </div>
        </pop-panel>
      </div>
    </div>
    <div class="field-right-cell">
      <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]" />
    </div>
  </div>
</template>
<script>
import PopPanel from "@/components/common/PopPanel";
import mixin from "./mixin";

export default {
  name: "ReferenceSelectorField",
  mixins: [mixin],
  components: { PopPanel },
  props: {
    referencesResolver: {
      type: Function,
      required: true
    },
    columns: {
      type: Array,
      required: true
    },
    refAttribute: {
      type: String,
      required: true
    },
    fieldVal: [String, Array],
    allowMulti: Boolean
  },
  data() {
    return {
      isValid: true,
      input: "",
      panel: {
        condition: {}, //condition will be cleared once panel is hidden
        visible: false,
        currentPage: 1,
        refs: [],
        checkedRefs: [],
        pageCount: 0,
        previewingIndex: -1
      }
    };
  },
  computed: {
    panelWidth() {
      // margin: 2px
      let width = 4;
      // button: 30px;
      width += 30;
      this.columns.forEach(c => (width += c.width));
      return width;
    },
    panelHeight() {
      let searchFieldHeight = 50, // search field: 50px
        tableHeight = 200, // references table: 200px, 10 lines
        pagerHeight = 20, // table pager: 20px
        previewHeight = 60, // preview field: 60px;
        height = 4; // margin: 2px

      height += searchFieldHeight + tableHeight;
      if (this.panel.pageCount > 1) {
        height += pagerHeight;
      }
      if (this.allowMulti) {
        height += previewHeight;
      }
      return height;
    }
  },
  watch: {
    fieldVal(val) {
      // always consider fieldVal is valid
      if (val instanceof Array) {
        this.input = val.join(";");
      } else {
        this.input = val || "";
      }
      this.panel.checkedRefs = this.input ? this.input.split(/\s*;\s*/) : [];
      this.isValid = true;
    },
    "panel.visible": function(visible) {
      if (!visible) {
        this.panel.condition = {};
        this.panel.currentPage = 1;
      }
    }
  },
  mounted() {
    // always consider fieldVal is valid
    if (this.fieldVal instanceof Array) {
      this.input = this.fieldVal.join(";");
    } else {
      this.input = this.fieldVal || "";
    }
    this.panel.checkedRefs = this.input ? this.input.split(/\s*;\s*/) : [];
  },
  methods: {
    validate() {
      if (this.input) {
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    },
    showSelector() {
      if (this.panel.visible) return;
      this.panel.visible = true;
      this.loadReferences();
    },
    toggleCheck(item) {
      if (this.allowMulti) {
        if (item._checked) {
          item._checked = false;
          this.panel.checkedRefs.splice(
            this.panel.checkedRefs.indexOf(item[this.refAttribute]),
            1
          );
        } else {
          this.$set(item, "_checked", true);
          this.panel.checkedRefs.push(item[this.refAttribute]);
        }
      } else {
        this.panel.refs.forEach(ref => this.$set(ref, "_selected", false));
        this.$set(item, "_selected", true);
        this.panel.checkedRefs = [item[this.refAttribute]];
        this.emitValue();
        this.panel.visible = false;
      }
    },
    prevPage() {
      if (this.panel.currentPage === 1) return;
      this.panel.currentPage--;
      this.loadReferences();
    },
    nextPage() {
      if (this.panel.currentPage === this.panel.pageCount) return;
      this.panel.currentPage++;
      this.loadReferences();
    },
    loadReferences() {
      this.referencesResolver(
        this.panel.currentPage,
        this.panel.condition
      ).then(({ data, pageCount }) => {
        this.panel.pageCount = pageCount;
        this.panel.refs = data;
        this.processRefs();
      });
    },
    processRefs() {
      this.panel.refs.forEach(ref => {
        this.$set(
          ref,
          "_checked",
          this.panel.checkedRefs.indexOf(ref[this.refAttribute]) !== -1
        );
      });
    },
    search() {
      this.panel.currentPage = 1;
      this.loadReferences();
    },
    moveUp() {
      if (this.panel.previewingIndex < 1) return;
      var refs = this.panel.checkedRefs;
      var tempRef = refs[this.panel.previewingIndex - 1];
      refs[this.panel.previewingIndex - 1] = refs[this.panel.previewingIndex];
      refs[this.panel.previewingIndex] = tempRef;
      this.panel.previewingIndex--;
    },
    moveDown() {
      if (
        this.panel.previewingIndex === -1 ||
        this.panel.previewingIndex === this.panel.checkedRefs.length - 1
      )
        return;
      var refs = this.panel.checkedRefs;
      var tempRef = refs[this.panel.previewingIndex + 1];
      refs[this.panel.previewingIndex + 1] = refs[this.panel.previewingIndex];
      refs[this.panel.previewingIndex] = tempRef;
      this.panel.previewingIndex++;
    },
    clear() {
      this.panel.checkedRefs = [];
      this.panel.refs.forEach(ref => {
        ref._checked = false;
      });
    },
    confirm() {
      // confirm button will only be visible when it's in multiple mode
      this.emitValue();
      this.panel.visible = false;
    },
    emitValue() {
      this.isValid = true;
      this.input = this.panel.checkedRefs.join(";");
      this.$emit("input", this.allowMulti ? this.input.split(";") : this.input);
      this.triggerExt();
    },
    autoResolve() {
      this.panel.checkedRefs = [];
      this.panel.previewingIndex = -1;
      let resolvingPieces = this.input
        ? this.input.split(/\s*;\s*/).deduplicate([""])
        : [];
      this.input = "";
      if (resolvingPieces.length) {
        if (!this.allowMulti) {
          // in single mode, will only resolve the first piece
          resolvingPieces = [resolvingPieces[0]];
        }
        this.resolveOneByOne(resolvingPieces);
      } else {
        this.emitValue();
      }
    },
    resolveOneByOne(pieces) {
      let piece = pieces.shift();
      let condition = {};
      condition[this.refAttribute] = piece;
      this.referencesResolver(1, condition).then(data => {
        if (data.length === 1) {
          this.panel.checkedRefs.push(data[0][this.refAttribute]);
          if (pieces.length) {
            this.resolveOneByOne(pieces);
          } else {
            // when stop resolving, emit value
            this.emitValue();
          }
        } else {
          // if there's not only one result, should stop resolving
          this.$set(this.panel.condition, this.refAttribute, piece);
          this.panel.refs = data;
          this.processRefs();
          this.emitValue();
          this.panel.visible = true;
        }
      });
    },
    blur() {
      this.isValid = this.input || !this.required;
    }
  }
};
</script>
<style scoped>
div {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.disabled {
  background-color: grey !important;
  cursor: not-allowed !important;
}
.field-mid-cell-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0 22px 0 5px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}
.field-mid-cell-input:hover {
  outline: 0;
  border-color: #8391a5;
}
.container {
  position: relative;
}
.selector-switcher {
  cursor: pointer;
  height: 22px;
  width: 22px;
  text-align: center;
  line-height: 22px;
  position: absolute;
  color: #bfcbd9;
  top: 0;
  right: 0;
}
.selector-panel {
  position: fixed;
  z-index: 1;
  border: 1px solid red;
  border-radius: 4px;
  background-color: #fff;
}
.panel-inner {
  margin: 2px;
}
.row {
  height: 20px;
  border-bottom: 1px solid #ccc;
  cursor: pointer;
}
.row:hover {
  background-color: #e9e7e7;
}
.selected-row {
  background-color: #e9e7e7;
}
.header-row {
  height: 22px !important;
  background-color: #eee;
}
.cell {
  float: left;
  height: 20px;
  line-height: 20px;
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 0 5px;
}
.btn-cell {
  width: 30px;
  background-color: #3f8db1;
  color: #fff;
  text-align: center;
  border-radius: 4px;
  cursor: pointer;
}
.btn-cell:hover {
  background-color: #bf0535;
}
.condition {
  margin-bottom: 2px;
  border-radius: 4px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 18px;
  width: 100%;
  border: 1px solid #bfcbd9;
  outline: 0;
}
.references {
  height: 200px;
  overflow: hidden;
}
.preview {
  height: 60px;
}
.preview .v-button {
  float: right;
  width: 60px;
}
.v-button > div {
  padding: 0 5px;
  width: 60px;
  margin-top: 4px;
  height: 22px;
  line-height: 22px;
  text-align: center;
  cursor: pointer;
  background-color: #3f8db1;
  color: #fff;
  border-radius: 4px;
}
.v-button > div:hover {
  background-color: #bf0535;
}
.preview-panel {
  margin-right: 70px;
}
.preview-panel .opt {
  float: right;
  width: 20px;
  height: 60px;
  line-height: 20px;
}
.preview-panel .list {
  height: 60px;
  margin-right: 20px;
  border: 1px solid #ccc;
  overflow-y: scroll;
  overflow-x: hidden;
}
.opt > div {
  color: #fff;
  margin-top: 6px;
  height: 20px;
  text-align: center;
  cursor: pointer;
  border-radius: 4px;
  background-color: #3f8db1;
}
.opt > div:hover {
  background-color: #bf0535;
}
.preview-panel .item {
  height: 20px;
  line-height: 20px;
  color: #000;
  padding: 0 5px;
  cursor: pointer;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.preview-panel .item:hover {
  background-color: #59b3eb;
}
.preview-panel .selected-item {
  background-color: #59b3eb;
}
.pager {
  height: 20px;
}
.pager > div {
  float: left;
  line-height: 20px;
}
.pager .btn {
  height: 20px;
  color: #fff;
  background-color: #3f8db1;
  cursor: pointer;
  border-radius: 4px;
  margin: 0 5px;
  padding: 0 5px;
}
.pager .btn:hover {
  background-color: #bf0535;
}
.index-cell {
  width: 10px;
}
.main-col {
  font-weight: bold;
}
</style>
