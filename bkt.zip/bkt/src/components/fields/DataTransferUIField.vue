<template>
    <div class="field-container clearfix">
        <div class="field-left-cell">
            <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
        </div>
        <div class="field-mid-cell">
            <div class="dt-datafield" @click="showDataPicker()">
                <span class="data" v-for="(item, index) in selectedOptions" :key="index" :title="item">
                    {{item}}
                </span>
            </div>
            <transfer :options="options" :selectedOptions="selectedOptions" :title="fieldName" v-model="selectedOptions" ref="transfer">
            </transfer>
        </div>
        <div class="field-right-cell ">
            <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
        </div>
    </div>
</template>
<script>
import Transfer from "@/components/common/Transfer";

export default {
  name: "DataTransferField",
  components: {
    Transfer
  },
  props: {
    placeholder: String,
    fieldName: {
      type: String,
      required: true
    },
    required: Boolean,
    readonly: Boolean,
    fieldVal: String,
    options: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      selectedOptions: [],
      showTransfer: false,
      isValid: true
    };
  },
  watch: {
    selectedOptions(selectedOptions) {
      this.$emit("input", selectedOptions);
      this.isValid =
        !this.required || (this.required && selectedOptions.length);
    }
  },
  methods: {
    showDataPicker() {
      this.$refs.transfer.isVisible = true;
    }
  },
  beforeMount() {
    if (this.$options.propsData.fieldVal) {
      this.$data.selectedOptions = this.$options.propsData.fieldVal.split(";");
    }
  }
};
</script>
<style scoped>
.dt-datafield {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  height: 22px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  line-height: 22px;
  overflow: hidden;
}

.dt-datafield .data {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  float: left;
  max-width: 50px;
  min-width: 30px;
  text-align: center;
  height: 18px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 0.8em;
  margin: 1px;
  line-height: 18px;
}
</style>
