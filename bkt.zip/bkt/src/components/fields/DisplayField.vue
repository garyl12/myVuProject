<template>
  <div class="field-container clearfix">
    <div class="field-left-cell">
      <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell field-mid-cell-overflow field-font">
      <label :class="{'link': showAsLink}" @click="clickHandler" :title="fieldVal instanceof Array ? fieldVal.join(';') : fieldVal">
        {{fieldVal instanceof Array ? fieldVal.join(';') : fieldVal}}
      </label>
    </div>
    <div class="field-right-cell">
    </div>
  </div>  
</template>
<script>
export default {
  name: "DisplayField",
  props: {
    fieldName: {
      type: String,
      required: true
    },
    fieldVal: [String, Number, Object, Array],
    showAsLink: {
      type: Boolean
    }
  },
  methods: {
    clickHandler() {
      this.$emit("click");
    }
  }
};
</script>
<style scoped>
.field-font {
  font-size: 100%;
}
.field-mid-cell-overflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.field-mid-cell label {
  line-height: 22px;
  padding-left: 5px;
}
.link {
  text-decoration: underline;
  cursor: pointer;
  color: #abb6d5;
}
</style>
