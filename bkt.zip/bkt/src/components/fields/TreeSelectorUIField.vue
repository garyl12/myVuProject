<!--
  Sample: TreeSelectorFieldSample.vue
-->
<template>
  <div class="field-container clearfix">
    <div class="field-left-cell clearfix">
      <label :title="fieldName" class="field-name">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell relative">
      <input class="field-mid-cell-input" v-model="input" :placeholder="placeholder" @change="autoResolve" @blur="validate" ref="input" />
      <i class="selector-switcher iconfont icon-tree font-12" @click.stop="showSelector" />
      <pop-panel
        :visible="panel.visible"
        :width="panel.width"
        :height="panel.height"
        @close="panel.visible=false">
        <div style="height:100%">
          <div class="pop-top">
            <div class="search-field">
              <input type="text" v-model="tree.condition" @keydown.enter="search" class="field-mid-cell-input">
              <div class="erase-btn">
                <i class="iconfont icon-close font-12" v-show="tree.condition" @click="clearSearch"></i>
              </div>
            </div>
            <div class="search-btn">
              <i class="iconfont icon-search" @click="search"></i>
            </div>
          </div>
          <div class="pop-mid">
            <tree
              :data="tree.data"
              :childAttribute="childAttribute"
              :label-template="treeLabelTemplate"
              :plain="tree.plain"
              :allow-multi="allowMulti"
              @load-children="load"
              ref="tree"
              />
          </div>
          <div class="pop-footer">
            <span class="btn btn-dark" :title="$t_('confirm')" @click="confirm">{{$t_("confirm")}}</span>
            <span class="btn btn-dark" :title="$t_('cancel')" @click="panel.visible=false">{{$t_("cancel")}}</span>
          </div>
        </div>
      </pop-panel>
    </div>
    <div class="field-right-cell">
      <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
    </div>
  </div>
</template>

<script>
import PopPanel from "@/components/common/PopPanel";
import Tree from "../common/Tree";
import mixin from "./mixin";

export default {
  name: "TreeSelectorField",
  mixins: [mixin],
  components: { PopPanel, Tree },
  props: {
    fieldVal: [String, Array],
    childAttribute: {
      type: String,
      default: "children"
    },
    treeLabelTemplate: {
      type: String,
      default: "${name}(${id})"
    },
    treeLoader: {
      required: true,
      type: Function
    },
    searchResolver: {
      required: true,
      type: Function
    },
    valueResolver: {
      type: Function,
      required: true
    },
    allowMulti: Boolean
  },
  data() {
    return {
      input: "", //input, maybe invalid
      val: [], //accurate value, valid
      isValid: true,
      panel: {
        visible: false,
        width: 0,
        minWidth: 180,
        height: 250
      },
      tree: {
        condition: "",
        plain: false,
        data: []
      }
    };
  },
  watch: {
    fieldVal(val) {
      // always consider fieldVal is valid
      this.isValid = true;
      if (val instanceof Array) {
        this.input = val.join(";");
      } else {
        this.input = val || "";
      }
      this.values = this.input ? this.input.split(/\s*;\s*/) : [];
      if (!val) {
        // reset tree
        this.tree.condition = "";
        this.tree.plain = false;
        this.tree.data = [];
      }
    },
    "panel.visible": function(visible) {
      if (!visible) {
        // if current tree has condition, reset tree
        if (this.tree.condition) {
          this.tree.condition = "";
          this.tree.plain = false;
          this.tree.data = [];
        }
      } else {
        this.panel.width = Math.max(
          this.$refs.input.clientWidth,
          this.panel.minWidth
        );
      }
    }
  },
  mounted() {
    // consider fieldVal is always valid
    if (this.fieldVal instanceof Array) {
      this.input = this.fieldVal.join(";");
    } else {
      this.input = this.fieldVal || "";
    }
    this.values = this.input ? this.input.split(/\s*;\s*/) : [];
  },
  methods: {
    validate() {
      if (this.values.length) {
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    },
    clearSearch() {
      this.tree.condition = "";
      this.tree.plain = false;
      this.load(null);
    },
    showSelector() {
      if (this.panel.visible) return;
      this.panel.visible = true;
      // always load tree when showing panel by clicking tree icon
      if (!this.tree.data.length) {
        this.load(null);
      }
    },
    load(parent) {
      this.treeLoader(parent).then(data => {
        if (data.length) {
          this.setStatus(data);
          if (parent) {
            this.$set(parent, this.childAttribute, data);
          } else {
            this.tree.data = data;
          }
        }
      });
    },
    setStatus(data) {
      if (this.values.length) {
        if (this.allowMulti) {
          this.setCheckedRecursively(data);
        } else {
          this.setSelectedRecursively(data);
        }
      }
    },
    setSelectedRecursively(data) {
      return data.some(d => {
        if (this.values.indexOf(this.valueResolver(d)) !== -1) {
          this.$set(d, "_selected", true);
          this.$refs.tree.selectedItem = d;
          return true;
        } else if (d[this.childAttribute]) {
          return this.setSelectedRecursively(d[this.childAttribute]);
        } else {
          return false;
        }
      });
    },
    setCheckedRecursively(data) {
      let hasChecked = false;
      data.forEach(d => {
        let checked = this.values.indexOf(this.valueResolver(d)) !== -1;
        hasChecked = hasChecked || checked;
        this.$set(d, "_checked", checked);
        if (d[this.childAttribute]) {
          let hasChildrenChecked = this.setCheckedRecursively(
            d[this.childAttribute]
          );
          if (!checked && hasChildrenChecked) {
            this.$set(d, "_indeterminate", true);
          }
        }
      });
      return hasChecked;
    },
    search() {
      if (!this.tree.plain && !this.tree.condition) return;
      this.tree.plain = this.tree.condition;
      if (this.tree.condition) {
        this.searchResolver(this.tree.condition).then(data => {
          this.setStatus(data);
          this.tree.data = data;
        });
      } else {
        this.load(null);
      }
    },
    confirm() {
      this.values = [];
      if (this.allowMulti) {
        let checkedItems = this.$refs.tree.collectScope();
        checkedItems.forEach(node => {
          this.values.push(this.valueResolver(node));
        });
      } else {
        this.values.push(this.valueResolver(this.$refs.tree.selectedItem));
      }
      this.$emit("input", this.values.join(";"));
      this.isValid = true;
      this.triggerExt();
      this.panel.visible = false;
    },
    autoResolve() {
      let resolvingPieces = this.input
        ? this.input.split(/\s*;\s*/).deduplicate([""])
        : [];
      this.input = "";
      this.values = [];
      if (resolvingPieces.length) {
        if (!this.allowMulti) {
          // in single mode, will only resolve the first piece
          resolvingPieces = [resolvingPieces[0]];
        }
        this.resolveOneByOne(resolvingPieces);
      } else {
        this.isValid = !this.required;
        this.$emit("input", this.values.join(";"));
        this.triggerExt();
      }
    },
    resolveOneByOne(pieces) {
      let piece = pieces.shift();
      this.searchResolver(piece).then(data => {
        if (data.length === 1) {
          this.values.push(this.valueResolver(data[0]));
          if (pieces.length) {
            this.resolveOneByOne(pieces);
          } else {
            this.$emit("input", this.values.join(";"));
            this.isValid = true;
            this.triggerExt();
          }
        } else {
          // if there's more than one result, should stop resolving
          this.tree.condition = piece;
          this.tree.plain = true;
          this.panel.visible = true;
          this.setStatus(data);
          this.tree.data = data;
          this.isValid = true;
          this.$emit("input", this.values.join(";"));
          this.triggerExt();
        }
      });
    }
  }
};
</script>

<style scoped>
.field-mid-cell-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0 22px 0 5px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}
.field-mid-cell-input:hover {
  outline: 0;
  border-color: #8391a5;
}
.selector-switcher {
  cursor: pointer;
  height: 22px;
  width: 22px;
  text-align: center;
  line-height: 22px;
  position: absolute;
  color: #bfcbd9;
  top: 0;
  right: 0;
}
.selector-switcher:hover {
  color: #8391a5;
}

.relative {
  position: relative;
}
.search-field {
  position: relative;
  margin: 2px 22px 0 2px;
}
.search-btn {
  position: absolute;
  line-height: 28px;
  width: 22px;
  text-align: center;
  cursor: pointer;
  top: 0;
  right: 0;
}
.search-btn:hover {
  color: #8391a5;
}
.erase-btn {
  position: absolute;
  top: 0;
  right: 6px;
  line-height: 22px;
  cursor: pointer;
}
.erase-btn:hover {
  color: #8391a5;
}
.pop-top {
  height: 26px;
}
.pop-mid {
  height: 200px;
  overflow: auto;
}
.pop-footer {
  height: 22px;
  float: right;
}
</style>