<template>
    <div class="field-container clearfix">
        <div class="field-left-cell clearfix">
            <label :title="fieldName" class="field-name">{{fieldName}}</label><label class="colon">:</label>
        </div>
        <div class="field-mid-cell">
            <textarea v-if="fieldType==='textarea'" class="field-mid-cell-textarea" v-model="input" @change="processInput"></textarea>
            <input v-else class="field-mid-cell-input" v-model="input" :placeholder="placeholder" @change="processInput" />
        </div>
        <div class="field-right-cell">
            <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]" :title="validationMsg"></i>
        </div>
    </div>
</template>
<script>
import mixin from "./mixin";

export default {
  name: "TextField",
  mixins: [mixin],
  props: {
    fieldVal: [String, Number, Array],
    allowMulti: Boolean,
    fieldType: String
  },
  data() {
    return {
      input: "",
      isValid: true,
      validationMsg: ""
    };
  },
  watch: {
    fieldVal(newVal) {
      this.isValid = true;
      if (newVal && this.allowMulti && newVal instanceof Array) {
        this.input = newVal.join(";");
      } else {
        this.input = newVal;
      }
    }
  },
  mounted() {
    if (this.fieldVal && this.allowMulti && this.fieldVal instanceof Array) {
      this.input = this.fieldVal.join(";");
    } else {
      this.input = this.fieldVal;
    }
  },
  methods: {
    processInput() {
      if (this.allowMulti) {
        this.input = this.input
          .split(";")
          .filter(v => v)
          .join(";");
        this.isValid = !this.required || this.input;
        let tempVal = this.input.split(";");
        this.$emit("input", tempVal);
        this.triggerExt(tempVal);
      } else {
        this.isValid = !this.required || this.input;
        this.$emit("input", this.input);
        this.triggerExt(this.input);
      }
    },
    validate() {
      if (this.input) {
        // if input is not empty, the field has been validated, emit isValid
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        // if input is empty, the field may not be validated, emit !required
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    }
  }
};
</script>
<style scoped>
.field-mid-cell-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0px 5px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}

.field-mid-cell-textarea {
  overflow: auto;
  border-radius: 6px;
  height: 100px;
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  padding: 0 5px;
}

.field-mid-cell-input:hover {
  outline: 0;
  border-color: #8391a5;
}

.field-mid-cell-input:focus {
  outline: 0;
  border-color: #20a0ff;
}
</style>
