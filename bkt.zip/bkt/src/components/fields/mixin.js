export default {
  props: {
    placeholder: String,
    fieldName: {
      type: String,
      required: true
    },
    required: Boolean,
    driveExt: Function,
    validateExt: Function, //should return Promise, resolving true for valid, false for invalid.
  },
  methods: {
    triggerExt(val) {
      if (!this.isValid) return;
      this.triggerValidateExt(val).then(() => {
        this.triggerDriveExt(val);
      })
    },
    triggerDriveExt(val) {
      if (this.driveExt) {
        this.driveExt(val)
      }
    },
    triggerValidateExt(val) {
      if (this.validateExt) {
        return this.validateExt(val).then(isValid => {
          this.isValid = isValid;
          if (this.isValid) {
            // trigger post action (driveExt) if field is valid
            Promise.resolve();
          }
        }, _ => {
          this.isValid = false;
          this.$emit("validate", {
            fieldName: this.fieldName,
            isValid: this.isValid
          });
        });
      } else {
        return new Promise(resolve => {
          if (this.isValid) {
            // trigger post action (driveExt) if field is valid
            resolve();
          }
        });
      }
    }
  }
}
