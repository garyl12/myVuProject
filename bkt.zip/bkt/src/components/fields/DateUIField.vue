<template>
  <div class="field-container clearfix">
    <div class="field-left-cell">
      <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell">
      <el-date-picker 
        v-model="dateVal"
        align="left"
        type="date"
        :placeholder="placeholder"
        :picker-options="pickerOptions"
        @input="processInput"
        @blur="handleBlur" />
    </div>
    <div class="field-right-cell">
      <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
    </div>
  </div>
</template>

<script>
import mixin from "./mixin";

const parseToDate = function(input) {
  if (input) {
    let pieces = input.split("-");
    return new Date(
      Number(pieces[0]),
      Number(pieces[1]) - 1,
      Number(pieces[2])
    );
  }
  return null;
};

const parseFromDate = function(date) {
  let y = date.getFullYear();
  let m = date.getMonth() + 1;
  let d = date.getDate();
  return [y, (m > 9 ? "" : "0") + m, (d > 9 ? "" : "0") + d].join("-");
};

export default {
  name: "DateField",
  mixins: [mixin],
  props: {
    fieldVal: String,
    startFrom: String,
    endBy: String
  },
  data() {
    return {
      dateVal: "",
      isValid: true,
      minDate: null,
      maxDate: null,
      pickerOptions: {
        disabledDate: time => {
          return (
            (this.endByDate && time.getTime() > this.endByDate.getTime()) ||
            (this.startFromDate &&
              time.getTime() < this.startFromDate.getTime())
          );
        }
      }
    };
  },
  computed: {
    startFromDate() {
      return this.startFrom ? parseToDate(this.startFrom) : null;
    },
    endByDate() {
      return this.endBy ? parseToDate(this.endBy) : null;
    }
  },
  watch: {
    fieldVal(newVal) {
      if (newVal) {
        this.dateVal = parseToDate(newVal);
      } else {
        this.dateVal = null;
      }
    }
  },
  mounted() {
    if (this.fieldVal) {
      this.dateVal = parseToDate(this.fieldVal);
    } else {
      this.dateVal = null;
    }
  },
  methods: {
    validate() {
      if (this.dateVal) {
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    },
    processInput() {
      if (this.dateVal) {
        this.$emit("input", parseFromDate(this.dateVal));
        this.isValid = true;
      } else {
        this.$emit("input", null);
        this.isValid = !this.required;
      }
    },
    handleBlur() {
      //when input is invalid, el-data-picker won't emit 'input' event,
      //so hook blur event to revert invalid input
      if (
        this.$children[0].$children[0].currentValue !==
        this.$children[0].$children[0].value
      ) {
        this.$children[0].$children[0].setCurrentValue(
          this.$children[0].$children[0].value
        );
      }
    }
  }
};
</script>