<template>
  <div class="field-container clearfix">
    <div class="field-left-cell">
      <label :title="fieldName" class="field-name">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell">
      <div class="min">
        <input :class="['field-mid-input',{'input-invalid':!isMinValid}]" v-model="minInput" :placeholder="minPlaceholder" @blur="blur(false)" />
      </div>
      <div class="separator">-</div>
      <div class="max">
        <input :class="['field-mid-input',{'input-invalid':!isMaxValid}]" v-model="maxInput" :placeholder="maxPlaceholder" @blur="blur(true)" />
      </div>
    </div>
    <div class="field-right-cell">
    </div>
    </div>
</template>

<script>
import numberFormatter from "@/utils/numberFormatter";
import { merge } from "@/utils";

export default {
  name: "NumberRangeField",
  props: {
    maxPlaceholder: String,
    minPlaceholder: String,
    fieldName: {
      type: String,
      required: true
    },
    format: String,
    fieldVal: Object
  },
  beforeMount() {
    let format = this.$options.propsData.format;
    if (format) {
      let [decimalCount = -1, thousandSymbol, rate] = format.split(";");
      this.$data.decimalCount = Number(decimalCount);
      let [rateSymbol, rateFactor] = rate.split("/");
      if (rateSymbol) {
        this.$data.rateSymbol = rateSymbol;
      }
      if (rateFactor) {
        this.$data.rateFactor = Number(rateFactor);
      }
    }
    this.$data.regexp = numberFormatter.getNumberRegexp(
      this.$data.decimalCount
    );
  },
  watch: {
    fieldVal(val) {
      this.isMaxValid = true;
      this.isMinValid = true;
      let fieldVal = merge(val || {}, { max: null, min: null });
      if (fieldVal.max === null) {
        this.maxInput = "";
        this.maxValue = null;
      } else {
        this.maxValue = Number(fieldVal.max);
        this.maxInput = this.maxValue + "";
        if (this.format) {
          this.maxInput = formattedVal = numberFormatter.formatDisplay(
            fieldVal.max,
            this.format,
            false
          );
        }
      }
      if (fieldVal.min === null) {
        this.minInput = "";
        this.minValue = null;
      } else {
        this.minValue = Number(fieldVal.min);
        this.minInput = this.minValue + "";
        if (this.format) {
          this.minInput = numberFormatter.formatDisplay(
            fieldVal.min,
            this.format,
            false
          );
        }
      }
    },
    format(format) {
      this.decimalCount = -1;
      this.rateSymbol = "";
      this.rateFactor = 1;
      if (format) {
        let [decimalCount = -1, thousandSymbol, rate] = format.split(";");
        this.decimalCount = Number(decimalCount);
        let [rateSymbol, rateFactor] = rate.split("/");
        if (rateSymbol) {
          this.rateSymbol = rateSymbol;
        }
        if (rateFactor) {
          this.rateFactor = Number(rateFactor);
        }
      }
      this.regexp = numberFormatter.getNumberRegexp(this.$data.decimalCount);
    }
  },
  data() {
    return {
      decimalCount: -1,
      rateSymbol: "",
      rateFactor: 1,
      minInput: "",
      maxInput: "",
      minValue: null,
      maxValue: null,
      regexp: null,
      isMinValid: true,
      isMaxValid: true
    };
  },
  methods: {
    blur(isMax) {
      let input = isMax ? this.maxInput : this.minInput;
      // rateSymbol should not appear among the input
      // remove all comma(,)
      input = input.replace(/,/g, "");
      if (this.validate(input, isMax)) {
        this.processInput(input, isMax);
      } else {
        if (isMax) {
          this.maxValue = null;
        } else {
          this.minValue = null;
        }
      }
      this.$emit("input", {
        max: this.maxValue,
        min: this.minValue
      });
    },
    validate(input, isMax) {
      let isValid = true;
      if (input) {
        isValid = this.regexp.test(input);
      }
      if (isMax) {
        this.isMaxValid = isValid;
      } else {
        this.isMinValid = isValid;
      }
      return isValid;
    },
    processInput(input, isMax) {
      let val = null;
      if (input) {
        if (this.format) {
          if (this.rateFactor) {
            val = numberFormatter.transformDecimal(
              Number(input),
              1 / this.rateFactor
            );
            if (isMax) {
              this.maxValue = val;
            } else {
              this.minValue = val;
            }
          }
          let formattedVal = numberFormatter.formatDisplay(
            val,
            this.format,
            false
          );
          if (isMax) {
            this.maxInput = formattedVal;
          } else {
            this.minInput = formattedVal;
          }
        } else {
          if (isMax) {
            this.maxInput = input;
            this.maxValue = Number(input);
          } else {
            this.minInput = input;
            this.minValue = Number(input);
          }
        }
      }
    }
  }
};
</script>
<style scoped>
.field-mid-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0 5px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}
.field-mid-input:hover {
  outline: 0;
  border-color: #8391a5;
}
.field-mid-input:focus {
  outline: 0;
  border-color: #20a0ff;
}
.input-invalid {
  border-color: red;
}
.min {
  float: left;
  width: calc(50% - 5px);
  width: -ms-calc(50% - 5px);
  width: -moz-calc(50% - 5px);
  width: -webkit-calc(50% - 5px);
}
.max {
  float: right;
  width: calc(50% - 5px);
  width: -ms-calc(50% - 5px);
  width: -moz-calc(50% - 5px);
  width: -webkit-calc(50% - 5px);
}
.separator {
  margin-left: auto;
  margin-right: auto;
  width: 10px;
  height: 100%;
  text-align: center;
  display: inline-block;
  line-height: 22px;
}
</style>
