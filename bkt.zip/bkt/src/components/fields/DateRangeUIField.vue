<template>
  <div class="field-container clearfix">
        <div class="field-left-cell">
            <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
        </div>
        <div class="field-mid-cell clearfix">
          <div class="min-date">
            <el-date-picker
              v-model="minDate"
              align="left"
              type="date"
              :placeholder="minDatePlaceholder"
              :picker-options="startPickerOptions"
              @input="validate"
              @blur="handleBlur(false)" />
          </div>
          <div class="separator">-</div>
          <div class="max-date">
            <el-date-picker
              v-model="maxDate"
              align="left"
              type="date"
              :placeholder="maxDatePlaceholder"
              :picker-options="endPickerOptions"
              @input="validate"
              @blur="handleBlur(true)" />
          </div>
        </div>
        <div class="field-right-cell">
        </div>
    </div>
</template>

<script>
import { merge } from "@/utils";

const parseToDate = function(input) {
  if (input) {
    let pieces = input.split("-");
    return new Date(
      Number(pieces[0]),
      Number(pieces[1]) - 1,
      Number(pieces[2])
    );
  }
  return null;
};

const parseFromDate = function(date) {
  if (date) {
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    let d = date.getDate();
    return [y, (m > 9 ? "" : "0") + m, (d > 9 ? "" : "0") + d].join("-");
  } else {
    return null;
  }
};

const availableDateRang = {
  startFrom: null,
  endBy: null
};

export default {
  name: "DateRangeField",
  props: {
    minDatePlaceholder: String,
    maxDatePlaceholder: String,
    fieldName: {
      required: true,
      type: String
    },
    startFrom: String,
    endBy: String,
    fieldVal: [Object, String]
  },
  watch: {
    fieldVal(val) {
      let fieldVal = merge(val || {}, { max: null, min: null });
      this.maxDate = fieldVal.max ? parseToDate(fieldVal.max) : null;
      this.minDate = fieldVal.min ? parseToDate(fieldVal.min) : null;
    }
  },
  data() {
    return {
      minDate: null,
      maxDate: null,
      startPickerOptions: {
        disabledDate: time => {
          let currentTime = time.getTime();
          return (
            (this.maxDate && currentTime > this.maxDate.getTime()) ||
            (availableDateRang.endBy &&
              currentTime > availableDateRang.endBy.getTime()) ||
            (availableDateRang.startFrom &&
              currentTime < availableDateRang.startFrom.getTime())
          );
        }
      },
      endPickerOptions: {
        disabledDate: time => {
          let currentTime = time.getTime();
          return (
            (availableDateRang.endBy &&
              currentTime > availableDateRang.endBy.getTime()) ||
            (this.minDate && currentTime < this.minDate.getTime()) ||
            (availableDateRang.startFrom &&
              currentTime < availableDateRang.startFrom.getTime())
          );
        }
      }
    };
  },
  beforeMount() {
    let propsDate = this.$options.propsData;
    if (propsDate.startFrom) {
      availableDateRang.startFrom = parseToDate(propsDate.startFrom);
    }
    if (propsDate.endBy) {
      availableDateRang.endBy = parseToDate(propsDate.endBy);
    }
  },
  methods: {
    validate() {
      this.$emit("input", {
        min: parseFromDate(this.minDate),
        max: parseFromDate(this.maxDate)
      });
    },
    handleBlur(isMax) {
      //when input is invalid, el-data-picker won't emit 'input' event,
      //so hook blur event to revert invalid input
      let elDataPicker = null;
      if (isMax) {
        elDataPicker = this.$children[1];
      } else {
        elDataPicker = this.$children[0];
      }
      if (
        elDataPicker.$children[0].currentValue !==
        elDataPicker.$children[0].value
      ) {
        elDataPicker.$children[0].setCurrentValue(
          elDataPicker.$children[0].value
        );
      }
    }
  }
};
</script>

<style scoped>
.min-date {
  float: left;
  width: calc(50% - 5px);
  width: -ms-calc(50% - 5px);
  width: -moz-calc(50% - 5px);
  width: -webkit-calc(50% - 5px);
}
.max-date {
  float: left;
  width: calc(50% - 5px);
  width: -ms-calc(50% - 5px);
  width: -moz-calc(50% - 5px);
  width: -webkit-calc(50% - 5px);
}
.separator {
  float: left;
  margin: 0;
  width: 10px;
  height: 100%;
  text-align: center;
  display: inline-block;
  line-height: 22px;
}
</style>
