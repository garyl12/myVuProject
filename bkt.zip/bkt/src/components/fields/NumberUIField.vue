<template>
    <div class="field-container clearfix">
        <div class="field-left-cell">
            <label :title="fieldName" class="field-name">{{fieldName}}</label><label class="colon">:</label>
        </div>
        <div class="field-mid-cell">
            <input class="field-mid-cell-input" v-model="input" :placeholder="placeholder" @change="validateInner" />
        </div>
        <div class="field-right-cell">
            <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
        </div>
    </div>
</template>
<script>
import numberFormatter from "@/utils/numberFormatter";
import mixin from "./mixin";
const ERROR = "__error__";

export default {
  name: "NumberField",
  mixins: [mixin],
  props: {
    fieldVal: [Number, String, Array],
    format: String,
    allowMulti: Boolean
  },
  data() {
    return {
      decimalCount: -1,
      rateSymbol: "",
      rateFactor: 1,
      input: "",
      val: "",
      regexp: null,
      isValid: true
    };
  },
  mounted() {
    this.resetFormat();
    this.resetFieldVal();
  },
  watch: {
    format() {
      this.resetFormat();
    },
    fieldVal() {
      // always consider fieldVal is valid
      if (this.fieldVal !== ERROR) {
        this.isValid = true;
        this.resetFieldVal();
      }
    }
  },
  methods: {
    resetFormat() {
      if (this.format) {
        let [decimalCount = -1, thousandSymbol, rate = ""] = this.format.split(
          ";"
        );
        this.decimalCount = Number(decimalCount);
        let [rateSymbol = "", rateFactor = 1] = rate.split("/");
        this.rateSymbol = rateSymbol;
        this.rateFactor = Number(rateFactor);
      } else {
        this.decimalCount = -1;
        this.rateSymbol = "";
        this.rateFactor = 1;
      }
      this.regexp = numberFormatter.getNumberRegexp(this.decimalCount);
    },
    resetFieldVal() {
      // incase fieldVal is 0
      if (
        this.fieldVal === "" ||
        this.fieldVal === null ||
        typeof this.fieldVal === "undefined"
      ) {
        this.input = "";
      } else {
        if (this.format) {
          if (this.allowMulti) {
            this.input = (this.fieldVal instanceof Array
              ? this.fieldVal
              : this.fieldVal.split(";")
            )
              .map(v => numberFormatter.formatDisplay(v, this.format, false))
              .join(";");
          } else {
            this.input = numberFormatter.formatDisplay(
              this.fieldVal,
              this.format,
              false
            );
          }
        } else {
          if (this.allowMulti) {
            this.input =
              this.fieldVal instanceof Array
                ? this.fieldVal.join(";")
                : this.fieldVal;
          } else {
            this.input = this.fieldVal.toString();
          }
        }
      }
    },
    validate() {
      if (this.input) {
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    },
    validateInner() {
      let input = this.input;
      // rateSymbol should not appear among the input
      // remove all comma(,)
      input = input.replace(/,/g, "");
      this.isValid = true;
      if (input) {
        if (this.allowMulti) {
          this.isValid = !input.split(";").some(piece => {
            return piece ? !this.regexp.test(piece) : false;
          });
        } else {
          this.isValid = this.regexp.test(input);
        }
      } else {
        if (this.required) {
          this.isValid = false;
        }
      }
      if (this.isValid) {
        this.processInput(input);
        this.$emit("input", this.val);
        this.triggerExt();
      } else {
        this.$emit("input", ERROR);
      }
    },
    processInput(input) {
      if (input) {
        if (this.allowMulti) {
          let formattedValues = [],
            values = [],
            pieces = input.split(";");
          pieces.forEach(piece => {
            if (piece) {
              let val = numberFormatter.transformDecimal(
                Number(piece),
                1 / this.rateFactor
              );
              values.push(val);
              let formattedVal = this.format
                ? numberFormatter.formatDisplay(val, this.format, false)
                : val;
              formattedValues.push(formattedVal);
            }
          });
          this.input = formattedValues.join(";");
          this.val = values;
        } else {
          let val = numberFormatter.transformDecimal(
            Number(input),
            1 / this.rateFactor
          );
          this.val = val;
          let formattedVal = this.format
            ? numberFormatter.formatDisplay(val, this.format, false)
            : val.toString();
          this.input = formattedVal;
        }
      } else {
        this.val = null;
      }
    }
  }
};
</script>
<style scoped>
.field-mid-cell-input {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0 5px;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}

.field-mid-cell-input:hover {
  outline: 0;
  border-color: #8391a5;
}

.field-mid-cell-input:focus {
  outline: 0;
  border-color: #20a0ff;
}
</style>
