<template>
  <div class="field-container clearfix">
    <div class="field-left-cell">
      <label class="field-name" :title="fieldName">{{fieldName}}</label><label class="colon">:</label>
    </div>
    <div class="field-mid-cell">
      <select v-model="input" class="field-mid-cell-select" @change="validateInner" @blur="validate">
        <option value="" v-if="needEmptyOption"></option>
        <option v-if="forBoolean" value="true">{{$t_('yes')}}</option>
        <option v-if="forBoolean" value="false">{{$t_('no')}}</option>
        <option 
          v-if="!forBoolean"
          v-for="(option, index) in options"
          :key="index"
          :title="option.logicVal"
          :value="option.logicVal">
          {{option.displayVal}}
        </option>
      </select>
    </div>
    <div class="field-right-cell ">
      <label v-if="required">*</label><i :class="['iconfont','icon-warning','field-invalid-icon',{'field-valid':isValid}]"></i>
    </div>
  </div>
</template>
<script>
import mixin from "./mixin";

export default {
  name: "DropdownlistField",
  mixins: [mixin],
  props: {
    fieldVal: [String, Boolean],
    options: {
      type: Array,
      required: true
    },
    needEmptyOption: {
      type: Boolean,
      default: true
    },
    forBoolean: Boolean
  },
  data() {
    return {
      input: "",
      isValid: true
    };
  },
  watch: {
    fieldVal() {
      // always consider fieldVal is valid
      this.isValid = true;
      this.resetFieldVal();
    }
  },
  mounted() {
    this.resetFieldVal();
  },
  methods: {
    resetFieldVal() {
      let fieldVal = this.fieldVal;
      if (this.forBoolean && typeof fieldVal === "boolean") {
        this.input = fieldVal.toString();
      } else {
        if (fieldVal) {
          if (this.options.length) {
            if (
              !this.options.some(item => {
                if (
                  fieldVal.toLowerCase() === item.displayVal.toLowerCase() ||
                  fieldVal.toLowerCase() === item.logicVal.toLowerCase()
                ) {
                  this.input = item.logicVal;
                  return true;
                }
              })
            ) {
              this.input = "";
            }
          } else {
            console.warn("Property 'options' is empty");
          }
        } else {
          this.input = "";
        }
      }
    },
    validateInner() {
      this.isValid = true;
      if (this.input) {
        this.$emit(
          "input",
          this.forBoolean ? this.input === "true" : this.input
        );
        this.triggerExt();
      } else {
        this.isValid = !this.required;
        this.$emit("input", null);
        this.triggerExt();
      }
    },
    validate() {
      if (this.input) {
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: this.isValid
        });
      } else {
        if (this.required) this.isValid = false;
        this.$emit("validate", {
          fieldName: this.fieldName,
          isValid: !this.required
        });
      }
    }
  }
};
</script>
<style scoped>
.field-mid-cell-select {
  border-radius: 4px;
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  color: #1f2d3d;
  height: 22px;
  padding: 0;
  font-size: inherit;
  width: 100%;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  outline: 0;
}
.field-mid-cell-select option {
  font-size: 12px;
}
.field-mid-cell-select:hover {
  border-color: #8391a5;
}
.field-mid-cell-select:focus {
  border-color: #20a0ff;
}
</style>
