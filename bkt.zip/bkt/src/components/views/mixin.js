import {
  mapGetters
} from 'vuex'

export default {
  computed: {
    ...mapGetters({
      cache: "getFrameCache",
      visitedNavs: "getVisitedNavs"
    })
  },
  watch: {
    '$route.path': function (path, lastPath) {
      this.cacheFrame(lastPath);
    }
  },
  methods: {
    cacheFrame(path) {
      if (this.getCacheData) {
        if (this.visitedNavs.some(nav => nav.href === path)) {
          let data = this.getCacheData(path);
          console.log(`caching frame ${path}`)
          this.$store.commit("cacheFrame", {
            url: path,
            data: JSON.stringify(data)
          });
          console.log('done');
        }
      } else {
        console.error(`getCacheData is not implemented in frame ${path}`);
      }
    }
  },
  beforeRouteLeave(to, from, next) {
    this.cacheFrame(this.$route.path);
    next();
  }
}
