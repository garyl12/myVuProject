<template>
<div class="frame clearfix" ref="frame" style="heigth:100%">
    <div class="frame-left section portfolios" ref="left">
      <tree-grid
        :columns="portfolioColumns"
        :data="portfolios.data"
        :data-loader="dataLoader"
        :child-attribute="portfolios.childAttribute"
        :repeat-select="true"
        :need-searcher="true"
        :plain="portfolios.plain"
        :condition="portfolios.searchBy"
        @select="selectPortfolio"
        @search="searchPortfolio"
        ref="portfolioGrid"
        >
        <button-bar
          :padding-right="0"
          :buttons="portfolioButtons" />
      </tree-grid>
      <portfolio-editor 
        :visible="portfolioEditor.visible"
        :status="portfolioEditor.status"
        @add="postAddPortfolio"
        @edit="postEditPortfolio"
        @close="portfolioEditor.visible=false"
        />
    </div>
     <resizer axis="x" @resize="resizeX"/>
    <div class="frame-right" ref="right">
      <div class="portfolio-detail clearfix" style="overflow:auto" ref="rightTop">
        <basic-info ref="basicInfo" />
      </div>
      <resizer axis="y" @resize="resizeY"/>
      <div class="positions clearfix" ref="rightBottom">
        <grid
          :need-index="true"
          :need-pager="true"
          :need-searcher="true"
          :repeat-select="true"
          :columns="positionColumns"
          :data="positions.data"
          :condition="positions.searchBy"
          :page-count="positions.pageCount"
          :page-index="positions.pageIndex"
          :searcher-placeholder=positions.searcherPlaceholder
          @sort="loadPositionsPaginal"
          @search="loadPositionsPaginal"   
          @next-page="loadPositionsPaginal"
          @prev-page="loadPositionsPaginal"
          @jump-page="loadPositionsPaginal"
          ref="positionGrid"
          >
        </grid>
      </div>
    </div>
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
    <log-alert :logs="logAlert.logs" />
    <file-downloader
      :src=downloader.src
      :visible="downloader.visible"
      :file-types="fileTypes"
      @select-type="exportPortfolio"
      @close="downloader.visible=false"
      />
</div>

</template>

<script>
import endpoints from "@/api/endpoints";
import resizer from "@/components/common/Resizer";
import Grid from "@/components/common/Grid";
import TreeGrid from "@/components/common/TreeGrid";
import Resizer from "@/components/common/Resizer";
import FileDownloader from "@/components/common/FileDownloader";
import PortfolioEditor from "./PortfolioEditor";
import ButtonBar from "@/components/common/ButtonBar";
import Alert from "@/components/common/Alert";
import LogAlert from "@/components/sections/LogAlert";
import BasicInfo from "@/components/sections/subWindowTabs/BasicInfo";
import { mapGetters } from "vuex";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import {
  clone,
  autoCompleteFields,
  assembleDownloadUrl,
  getColumns
} from "@/utils";
import {
  PORTFOLIO_DATA_KEYS as KEYS,
  DATA_TYPES,
  PAGE_SIZE,
  EDITOR_STATUS,
  RESPONSE_CODE,
  FILE_TYPES,
  SIZE
} from "@/consts";
import mixin from "../mixin";

export default {
  name: "PortfolioFrame",
  components: {
    resizer,
    Grid,
    TreeGrid,
    FileDownloader,
    PortfolioEditor,
    ButtonBar,
    Alert,
    LogAlert,
    BasicInfo
  },
  mixins: [mixin],
  data() {
    return {
      portfolios: {
        rootIds: [],
        childAttribute: "children",
        data: [],
        selectedItem: null,
        selectedItemParent: null,
        selectedIndex: -1,
        plain: false,
        searchBy: ""
      },
      positions: {
        data: [],
        pageCount: 0,
        pageIndex: 0,
        selectedItem: null,
        selectedIndex: -1,
        searchableFields: [],
        searcherPlaceholder: "",
        searchBy: "",
        sortBy: null
      },
      portfolioEditor: {
        visible: false,
        status: EDITOR_STATUS.VIEWING
      },
      downloader: {
        src: "",
        visible: false
      },
      alert: {
        visible: false,
        title: "error",
        message: "",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      logAlert: {
        logs: []
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removePortfolio();
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      attributes: "getAttributes"
    }),
    portfolioColumns() {
      let columns = [];
      if (this.views[KEYS.PORTFOLIO_MANAGEMENT]) {
        columns = getColumns(
          this.views[KEYS.PORTFOLIO_MANAGEMENT],
          KEYS.PORTFOLIO_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    portfolioButtons() {
      return [
        {
          icon: "icon-tianjiagenjiedianicon",
          active: true,
          text: "add_root_portfolio",
          callback: () => {
            this.addRootPortfolio();
          }
        },
        {
          icon: "icon-tianjiazijiedianicon",
          active: this.portfolios.selectedIndex !== -1,
          text: "add_sub_portfolio",
          callback: () => {
            this.addSubPortfolio();
          }
        },
        {
          icon: "icon-bianji",
          active: this.portfolios.selectedIndex !== -1,
          text: "edit",
          callback: () => {
            this.editPortfolio();
          }
        },
        {
          icon: "icon-shanchu",
          active: this.portfolios.selectedIndex !== -1,
          text: "remove",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-daoru",
          active: true,
          text: "import",
          callback: () => {
            this.importPortfolio();
          }
        },
        {
          icon: "icon-daochu",
          active: this.portfolios.selectedIndex !== -1,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    },
    positionColumns() {
      let columns = [];
      if (this.views[KEYS.PORTFOLIO_MANAGEMENT]) {
        columns = getColumns(
          this.views[KEYS.PORTFOLIO_MANAGEMENT],
          KEYS.POSITION_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    positionSearchableFields() {
      let searchableFields = [];
      if (this.positionTemplate) {
        this.positionTemplate.measures.forEach(field => {
          if (field.searchAble) {
            searchableFields.push(field);
          }
        });
      }
      return searchableFields;
    },
    fileTypes() {
      return FILE_TYPES;
    },
    dataLoader() {
      return currentItem => {
        let baseCondition = {
            searchType: "CUSTOMIZED",
            attributeName: "Parent ID",
            valueType: "STRING",
            operator: "EQUAL",
            searchValues: [currentItem.id]
          },
          requestParameters = productApiHelper.getRequestData(
            null,
            [baseCondition],
            null,
            null,
            null,
            DATA_TYPES.PORTFOLIO,
            1
          );
        return this.requestPortfolios(requestParameters).then(
          ({ data }) => {
            this.$set(
              currentItem,
              this.portfolios.childAttribute,
              data.records
            );
            return Promise.resolve(data.records);
          },
          () => {
            return Promise.resolve(null);
          }
        );
      };
    },
    portfolioTemplate() {
      return this.templates[KEYS.TEMPLATES.PORTFOLIO];
    },
    positionTemplate() {
      return this.templates[KEYS.TEMPLATES.POSITION];
    }
  },
  watch: {
    "portfolios.selectedItem": function(entry) {
      this.$store.commit("setSelectedEntry", entry);
    }
  },
  mounted() {
    this.resetStore();
    this.loadFrameData();
  },
  methods: {
    loadFrameData() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.portfolios = cacheData.portfolios;
        this.positions = cacheData.positions;
      } else {
        let baseCondition = {
            searchType: "CUSTOMIZED",
            attributeName: "Parent ID",
            valueType: "STRING",
            operator: "EQUAL",
            searchValues: [KEYS.ROOT_PORTFOLIO_ID]
          },
          requestParameters = productApiHelper.getRequestData(
            null,
            [baseCondition],
            null,
            null,
            null,
            DATA_TYPES.PORTFOLIO,
            1
          );

        this.requestPortfolios(requestParameters).then(({ data }) => {
          this.portfolios.plain = false;
          this.portfolios.data = data.records;
          this.portfolios.rootIds = data.records.map(r => r.id);
          this.$refs.portfolioGrid.selectDefault();
        });
      }
    },
    resetStore() {
      this.$store.commit("setSelectedEntry", {});
      this.$store.commit("setEditingEntry", {});
      this.$store.commit("setEditingTemplate", {});
    },
    addRootPortfolio() {
      let entry = autoCompleteFields(
        { attributes: {} },
        this.portfolioTemplate,
        true
      );
      entry.attributes[KEYS.PARENT_ID].value = KEYS.ROOT_PORTFOLIO_ID;
      this.setEditorData(entry);
      this.portfolioEditor.visible = true;
      this.portfolioEditor.status = EDITOR_STATUS.ADDING;
    },
    addSubPortfolio() {
      let entry = autoCompleteFields(
        { attributes: {} },
        this.portfolioTemplate,
        true
      );
      entry.attributes[KEYS.PARENT_ID].value = this.portfolios.selectedItem.id;
      this.setEditorData(entry);
      this.portfolioEditor.status = EDITOR_STATUS.ADDING;
      this.portfolioEditor.visible = true;
    },
    searchPortfolio({ searchBy }) {
      this.portfolios.searchBy = searchBy;
      if (searchBy) {
        let defaultCondition = {
            searchType: "BRANCHES",
            searchValues: this.portfolios.rootIds
          },
          requestParameters = productApiHelper.getRequestData(
            defaultCondition,
            null,
            searchBy,
            null,
            this.portfolioColumns,
            DATA_TYPES.PORTFOLIO,
            1
          );
        this.requestPortfolios(requestParameters).then(({ data }) => {
          this.portfolios.data = data.records;
          this.$refs.portfolioGrid.selectDefault();
          this.portfolios.plain = true;
        });
      } else {
        this.loadFrameData();
      }
    },
    selectPortfolio({ currentItem, index, parent }) {
      if ((this.portfolios.selectedItem || {}).id !== currentItem.id) {
        this.$refs.positionGrid.resetSearchConditions();
        this.positions.pageIndex = 1;
        this.portfolios.selectedItem = currentItem;
        this.portfolios.selectedItemParent = parent;
        this.portfolios.selectedIndex = index;
        this.$store.commit("setSelectedEntry", currentItem);
        this.loadPositionsPaginal({});
      }
    },
    requestPortfolios(requestParams) {
      return this.$api.request(endpoints.getProductData, requestParams);
    },
    requestPositions(requestParams) {
      return this.$api.request(endpoints.getProductData, requestParams);
    },
    setEditorData(entry) {
      this.$store.commit("setEditingEntry", entry);
      this.$store.commit("setEditingTemplate", this.portfolioTemplate);
    },
    editPortfolio() {
      let entry = clone(this.portfolios.selectedItem);
      this.setEditorData(autoCompleteFields(entry, this.portfolioTemplate));
      this.portfolioEditor.status = EDITOR_STATUS.EDITING;
      this.portfolioEditor.visible = true;
    },
    loadPositionsPaginal({ searchBy, sortBy, pageIndex = 1 }) {
      this.positions.pageIndex = pageIndex;
      // searchBy can be empty when clearing search condition and requesting data
      if (typeof searchBy !== "undefined") {
        this.positions.searchBy = searchBy;
      }
      // sortBy is either undefined or a column
      if (sortBy) this.positions.sortBy = sortBy;
      let defaultCondition = {
          searchType: "LEAVES",
          searchValues: this.portfolios.selectedItem
            ? [this.portfolios.selectedItem.id]
            : ["0"]
        },
        requestParameters = productApiHelper.getRequestData(
          defaultCondition,
          null,
          this.positions.searchBy,
          sortBy,
          this.positionSearchableFields,
          DATA_TYPES.PORTFOLIO,
          pageIndex
        );
      this.requestPositions(requestParameters).then(
        ({ data }) => {
          this.positions.data = data.records;
          this.positions.pageCount = Math.ceil(data.recordCount / PAGE_SIZE);
        },
        () => {
          this.positions.data = [];
          this.positions.pageCount = 0;
        }
      );
    },
    removePortfolio() {
      if (!this.portfolios.selectedItem) return;
      let requestData = processApiHelper.getDeleteRequestData(
        this.portfolios.selectedItem,
        this.portfolioTemplate,
        DATA_TYPES.PORTFOLIO
      );
      this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            let index = this.portfolios.selectedIndex;
            if (this.portfolios.selectedItemParent) {
              this.portfolios.selectedItemParent[
                this.portfolios.childAttribute
              ].splice(index, 1);
            } else {
              this.portfolios.data.splice(index, 1);
            }
            this.portfolios.selectedIndex = -1;
            this.portfolios.selectedItem = null;
            this.positions.data = [];
            this.positions.pageCount = 0;
            this.positions.pageIndex = 0;
            this.resetStore();
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    postAddPortfolio(portfolio) {
      if (
        portfolio.attributes[KEYS.PARENT_ID].value === KEYS.ROOT_PORTFOLIO_ID
      ) {
        // added a root portfolio
        this.portfolios.data.unshift(portfolio);
        this.$refs.portfolioGrid.selectDefault();
      } else {
        // added a sub portfolio
        let attr = this.portfolios.childAttribute;
        this.portfolios.selectedItem[attr] =
          this.portfolios.selectedItem[attr] || [];
        this.portfolios.selectedItem[attr].unshift(portfolio);
      }
      this.portfolioEditor.visible = false;
    },
    postEditPortfolio(portfolio) {
      let attr = this.portfolios.childAttribute,
        index = this.portfolios.selectedIndex;
      this.$set(portfolio, "_selected", true);
      if (this.portfolios.selectedItem._expanded) {
        this.$set(portfolio, "_expanded", true);
        this.$set(
          portfolio,
          this.portfolios.childAttribute,
          this.portfolios.selectedItem[this.portfolios.childAttribute]
        );
      }
      if (this.portfolios.selectedItemParent) {
        this.portfolios.selectedItemParent[attr].splice(index, 1, portfolio);
      } else {
        // selected item is a root portfolio
        this.portfolios.data.splice(index, 1, portfolio);
      }
      this.portfolios.selectedItem = portfolio;
      this.portfolioEditor.visible = false;
    },
    exportPortfolio(type) {
      let parentId = this.portfolios.selectedItem.id,
        defaultCondition = {
          searchType: "BRANCHES",
          searchValues: [parentId]
        },
        exportParameters = productApiHelper.getRequestData(
          defaultCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.PORTFOLIO,
          -1
        );
      exportParameters.queryResultAction = "DOWNLOAD";
      exportParameters.outputFormat = type;
      this.$api.request(endpoints.getProductData, exportParameters).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    },
    resizeX(offset) {
      let leftWidth = this.$refs.left.clientWidth,
        rightWidth = this.$refs.right.clientWidth,
        distance = Math.min(
          Math.max(SIZE.PORTFOLIO_MIN_WIDTH - leftWidth, offset),
          rightWidth - SIZE.PORTFOLIO_DETAIL_MIN_WIDTH
        );

      this.$refs.left.style.width = leftWidth + distance + "px";
      this.$refs.right.style.width = rightWidth - distance + "px";

      this.$refs.portfolioGrid.resize();
      this.$refs.positionGrid.resize();
    },
    resizeY(offset) {
      let topHeight = this.$refs.rightTop.clientHeight,
        bottomHeight = this.$refs.rightBottom.clientHeight,
        bottomMinHeight = SIZE.GRID.PAGER_HEIGHT + SIZE.GRID.TABLE_MIN_HEIGHT,
        distance = Math.min(
          Math.max(SIZE.PORTFOLIO_DETAIL_MIN_HEIGHT - topHeight, offset),
          bottomHeight - bottomMinHeight
        );

      this.$refs.rightTop.style.height = topHeight + distance + "px";
      this.$refs.rightBottom.style.height = bottomHeight - distance + "px";

      this.$refs.positionGrid.resize();
    },
    getCacheData() {
      return {
        portfolios: this.portfolios,
        positions: this.positions
      };
    }
  }
};
</script>

<style scoped>
.frame {
  height: 100%;
}
.frame-left,
.frame-right {
  float: left;
  height: 100%;
  width: calc(50% - 4px);
  width: -ms-calc(50% - 4px);
  width: -moz-calc(50% - 4px);
  width: -webkit-calc(50% - 4px);
}
.section {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.portfolio-detail {
  height: 30%;
}
.positions {
  height: calc(70% - 8px);
  height: -ms-calc(70% - 8px);
  height: -moz-calc(70% - 8px);
  height: -webkit-calc(70% - 8px);
}
</style>