<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-inner">
      <editor-logger :logs="logs" />
      <div class="category-group" v-for="(category,index) in categoryGroups" :key ="index" v-show="category.fields.length">
        <div class="section">
          <span class="category-title">{{$t_(category.groupName||"")}}</span>
        </div>
        <fields-renderer
          :fields="category.fields"
          :entry="entry"
          :adding="isAdding"
          ref="fieldsRenderer"
          />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="calculate" v-show="calculable">{{$t_("calculate")}}</el-button>
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset()">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
	  </div>
    <alert :config="alert" />
  </el-dialog>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { getEditorTitle, clone, autoCompleteFields } from "@/utils";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import {
  PORTFOLIO_DATA_KEYS,
  EDITOR_STATUS,
  DATA_TYPES,
  RESPONSE_CODE
} from "@/consts";

export default {
  name: "PortfolioEditor",
  components: {
    FieldsRenderer,
    EditorLogger,
    Alert
  },
  props: {
    visible: {
      required: true,
      type: Boolean
    },
    status: {
      required: true,
      type: Number
    },
    calculable: Boolean
  },
  data() {
    return {
      logs: [],
      alert: {
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      template: "getEditingTemplate",
      selectedEntry: "getSelectedEntry",
      entry: "getEditingEntry"
    }),
    categoryGroups() {
      if (this.template.measures) {
        return assembleTemplateCategories(
          this.template,
          this.$api,
          field => field.name === PORTFOLIO_DATA_KEYS.PARENT_ID
        );
      }
      return [];
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    },
    defaultCondition() {
      let condition = {
        searchType: "ID",
        searchValues: []
      };
      if (this.entry.attributes) {
        condition.searchValues = [this.entry.attributes["ID"].value];
      }
      return condition;
    }
  },
  methods: {
    validate() {
      let invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    calculate() {
      if (!this.validate()) return;
      let requestData = processApiHelper.getCalculateRequestData(
        this.entry,
        this.template,
        DATA_TYPES.MARKETDATA
      );
      this.sendRequest(requestData).then(data => {
        let product = autoCompleteFields(data[0], this.template);
        this.$store.commit("setEditingEntry", product);
      });
    },
    save() {
      if (!this.validate()) return;
      this.validateID().then(() => {
        let requestData = processApiHelper.getUpdateRequestData(
          this.entry,
          this.template
        );
        this.sendRequest(requestData).then(data => {
          switch (this.status) {
            case EDITOR_STATUS.ADDING:
              this.$emit("add", data[0]);
              break;
            case EDITOR_STATUS.EDITING:
              this.$emit("edit", data[0]);
              break;
            case EDITOR_STATUS.CLONING:
              this.$emit("clone", data[0]);
              break;
          }
        });
      });
    },
    validateID() {
      if (this.isAdding) {
        let requestData = productApiHelper.getRequestData(
          this.defaultCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.PORTFOLIO
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert.visible = true;
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    sendRequest(requestData) {
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data);
          } else {
            return Promise.reject();
          }
        },
        function(err) {
          console.error(err);
          return Promise.reject();
        }
      );
    },
    reset() {
      switch (this.status) {
        case EDITOR_STATUS.ADDING:
          this.$store.commit(
            "setEditingEntry",
            autoCompleteFields({ attributes: {} }, this.template, true)
          );
          break;
        case EDITOR_STATUS.EDITING:
        case EDITOR_STATUS.CLONING:
          this.$store.commit(
            "setEditingEntry",
            autoCompleteFields(clone(this.selectedEntry), this.template)
          );
          break;
      }
      this.resetEditor();
    },
    resetEditor() {
      this.$refs.fieldsRenderer.forEach(renderer => renderer.reset());
      this.logs = [];
    },
    close() {
      this.$emit("close");
      this.resetEditor();
    }
  }
};
</script>
<style scoped>
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  height: calc(100% - 20px);
  border: 1px solid #ccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>
