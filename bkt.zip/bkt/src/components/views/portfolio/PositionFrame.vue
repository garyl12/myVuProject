<template>
  <div class="frame">
    <div class="positions" ref="top">
      <grid
          :need-index="true"
          :need-pager="true"
          :need-searcher="false"
          :repeat-select="true"
          :columns="columns"
          :data="positions.data"
          :page-count="positions.pageCount"
          :page-index="positions.pageIndex"
          @sort="retrievePositionData"
          @search="retrievePositionData"   
          @next-page="retrievePositionData"
          @prev-page="retrievePositionData"
          @jump-page="retrievePositionData"
          @select="selectPosition"
          ref="positionGrid"
          >
          <button-bar
            :padding-right="positions.pageCount>0?140:0"
            :buttons="buttons" />
        </grid>
        <searcher
          :visible="positions.searcherVisible"
          :fields="searchableFields"
          :conditions="positions.searchBy"
          @search="retrievePositionData"
          @close="positions.searcherVisible=false"
          /> 
        <portfolio-editor
          :calculable="true"
          :visible="positionEditor.visible"
          :status="positionEditor.status"
          @add="postAddPosition"
          @edit="postEditPosition"
          @clone="postAddPosition"
          @close="positionEditor.visible=false"
          />
        <file-downloader
          :src=downloader.src
          :visible="downloader.visible"
          :file-types="fileTypes"
          @select-type="exportPosition"
          @close="downloader.visible=false"
          />
    </div>
    <resizer axis="y" @resize="resizeY"></resizer>
    <div class="sub-window-area" ref="bottom">
      <sub-window-view ref="subWindowView">
      </sub-window-view>
    </div>
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import Searcher from "@/components/common/Searcher";
import SubWindowView from "@/components/sections/SubWindowView";
import Resizer from "@/components/common/Resizer";
import endpoints from "@/api/endpoints";
import Alert from "@/components/common/Alert";
import FileDownloader from "@/components/common/FileDownloader";
import ButtonBar from "@/components/common/ButtonBar";
import PortfolioEditor from "./PortfolioEditor";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import {
  clone,
  assembleDownloadUrl,
  getColumns,
  autoCompleteFields
} from "@/utils";
import mixin from "../mixin";
import {
  DATA_TYPES,
  EDITOR_STATUS,
  RESPONSE_CODE,
  FILE_TYPES,
  SIZE,
  PORTFOLIO_DATA_KEYS as KEYS
} from "@/consts";
export default {
  name: "PositionFrame",
  components: {
    Grid,
    Searcher,
    SubWindowView,
    Resizer,
    PortfolioEditor,
    Alert,
    FileDownloader,
    ButtonBar
  },
  mixins: [mixin],
  data() {
    return {
      positions: {
        data: [],
        pageCount: -1,
        pageIndex: -1,
        selectedItem: null,
        selectedIndex: -1,
        searchBy: null,
        sortBy: null,
        searcherVisible: false
      },
      positionEditor: {
        visible: false,
        status: 0
      },
      downloader: {
        src: "",
        visible: false
      },
      alert: {
        visible: false,
        title: "error",
        message: "",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      logAlert: {
        logs: []
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removePosition();
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      attributes: "getAttributes"
    }),
    template() {
      return this.templates[KEYS.TEMPLATES.POSITION];
    },
    fileTypes() {
      return FILE_TYPES;
    },
    columns() {
      let columns = [];
      if (this.views[KEYS.PORTFOLIO_MANAGEMENT]) {
        columns = getColumns(
          this.views[KEYS.PORTFOLIO_MANAGEMENT],
          KEYS.POSITION_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    searchableFields() {
      let fields = [];
      if (this.template) {
        this.template.measures.forEach(field => {
          if (field.searchAble) {
            fields.push(field);
          }
        });
      }
      return fields;
    },
    defaultCondition() {
      return {
        searchType: "LEAVES",
        searchValues: ["0"]
      };
    },
    buttons() {
      return [
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.positions.searcherVisible = true;
          }
        },
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.positionEditor.status = EDITOR_STATUS.ADDING;
            this.setEditorData("add");
          }
        },
        {
          icon: "icon-bianji",
          active: this.positions.selectedIndex !== -1,
          text: "edit",
          callback: () => {
            this.positionEditor.status = EDITOR_STATUS.EDITING;
            this.setEditorData("edit");
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.positions.selectedIndex !== -1,
          text: "clone",
          callback: () => {
            this.positionEditor.status = EDITOR_STATUS.CLONING;
            this.setEditorData("clone");
          }
        },
        {
          icon: "icon-shanchu",
          active: this.positions.selectedIndex !== -1,
          text: "remove",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-daochu",
          active: this.positions.pageCount > 0,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    }
  },
  watch: {
    "positions.selectedItem": function(val) {
      this.$store.commit("setSelectedEntry", val || {});
    }
  },
  mounted() {
    this.resetStore();
    this.loadPositionData();
  },
  methods: {
    loadPositionData() {
      if (this.cache[this.$route.path]) {
        this.positions = JSON.parse(this.cache[this.$route.path]).grid;
      } else {
        this.positions.data = [];
        this.positions.sortBy = null;
        this.positions.searchBy = null;
        this.positions.pageIndex = 1;
        this.positions.selectedIndex = -1;
        this.positions.selectedItem = null;
        let requestParameters = productApiHelper.getRequestData(
          this.defaultCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.PORTFOLIO,
          1
        );
        this.requestPositions(requestParameters);
      }
    },
    retrievePositionData({ sortBy, searchBy, pageIndex = 1 }) {
      this.positions.sortBy = sortBy || this.positions.sortBy;
      this.positions.searchBy = searchBy || this.positions.searchBy;
      this.positions.pageIndex = pageIndex;
      let requestParams = productApiHelper.getRequestData(
        this.defaultCondition,
        null,
        this.positions.searchBy,
        this.positions.sortBy,
        null,
        DATA_TYPES.PORTFOLIO,
        pageIndex
      );
      this.requestPositions(requestParams);
    },
    selectPosition({ currentItem, index }) {
      this.positions.selectedItem = currentItem;
      this.positions.selectedIndex = index;
    },
    setEditorData(status) {
      let editingEntry =
        status === "add"
          ? autoCompleteFields({ attributes: {} }, this.template, true)
          : autoCompleteFields(
              clone(this.positions.selectedItem),
              this.template
            );
      if (status === "clone") editingEntry.attributes["ID"].value = "";
      this.$store.commit("setEditingEntry", editingEntry);
      this.$store.commit("setEditingTemplate", this.template);
      this.positionEditor.visible = true;
    },
    postAddPosition(position) {
      this.positions.data.unshift(position);
      this.$refs.positionGrid.selectDefault();
      this.positionEditor.visible = false;
    },
    postEditPosition(position) {
      this.positions.data.splice(this.positions.selectedIndex, 1, position);
      this.$set(position, "_selected", true);
      this.positions.selectedItem = position;
      this.positionEditor.visible = false;
    },
    exportPosition(type) {
      let exportParameters = productApiHelper.getRequestData(
        this.defaultCondition,
        null,
        this.positions.searchBy,
        this.positions.sortBy,
        null,
        DATA_TYPES.PORTFOLIO,
        this.positions.pageIndex
      );
      exportParameters.queryResultAction = "DOWNLOAD";
      exportParameters.outputFormat = type;
      this.$api.request(endpoints.getProductData, exportParameters).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    },
    resizeY(offset) {
      let topHeight = this.$refs.top.clientHeight,
        bottomHeight = this.$refs.bottom.clientHeight,
        topMinHeight = SIZE.GRID.PAGER_HEIGHT + SIZE.GRID.TABLE_MIN_HEIGHT,
        bottomMinHeight = SIZE.SUB_WINDOW_MIN_HEIGHT,
        distance = Math.min(
          Math.max(topMinHeight - topHeight, offset),
          bottomHeight - bottomMinHeight
        );

      this.$refs.top.style.height = topHeight + distance + "px";
      this.$refs.bottom.style.height = bottomHeight - distance + "px";

      this.$refs.positionGrid.resize();
      this.$refs.subWindowView.resize();
    },
    removePosition() {
      let requestData = processApiHelper.getDeleteRequestData(
        this.positions.selectedItem,
        this.template,
        DATA_TYPES.PORTFOLIO
      );
      this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, data, messages }) => {
          this.removeConfirmation.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            this.positions.data.splice(this.positions.selectedIndex, 1);
            this.positions.selectedIndex = -1;
            this.positions.selectedItem = null;
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    requestPositions(requestParams) {
      this.$api
        .request(endpoints.getProductData, requestParams)
        .then(({ code, data, info }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.positions.pageCount = Math.ceil(
              data.recordCount / data.pageSize
            );
            this.positions.data = data.records;
            if (data.recordCount) {
              this.$refs.positionGrid.selectDefault();
              this.positions.searcherVisible = false;
            } else {
              this.positions.selectedIndex = -1;
              this.positions.selectedItem = null;
            }
          } else {
            this.alert.message = "";
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        });
    },
    resetStore() {
      this.$store.commit("setSelectedEntry", {});
      this.$store.commit("setEditingEntry", {});
      this.$store.commit("setEditingTemplate", {});
    },
    getCacheData() {
      return {
        grid: this.positions
      };
    }
  }
};
</script>

<style scoped>
.frame {
  height: 100%;
}
.positions,
.sub-window-area {
  height: calc(50% - 4px);
  height: -ms-calc(50% - 4px);
  height: -moz-calc(50% - 4px);
  height: -webkit-calc(50% - 4px);
}
</style>