<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" top="60px" 
    :close-on-click-modal="false" :show-close="false">
    <div class="template-selector" v-if="isAdding">
        <label>{{$t_("select_template")}}</label><label>:</label>
        <select v-model="templateName">
          <option v-for="(item,index) in availableTemplateNames" :key="index" :value="item">{{item}}</option>
        </select>
    </div>
    <div class="main-editor" :style="{'margin-top':isAdding?'0':'30px'}">
      <editor-logger :logs="logs" :above="true"/>
      <div class="editor-panel">
        <div v-for="(category,index) in categoryGroups" :key="index"> 
          <div class="section">
            <span class="panel-title">{{$t_(category.groupName)}}</span>
          </div>
          <fields-renderer
            :fields="category.fields"
            :entry="editingEntry"
            :adding="isAdding||isCloning"
            ref="fieldsRenderer"
            />
        </div>
        <div class="grid-panel">
          <div class="section">
            <span class="panel-title">{{$t_("curve_value")}}</span>
          </div>
          <div class="edit-area clearfix">
            <div class="table">
              <editable-grid
                v-if="isInput"
                :columns="columns"
                :data="gridData"
                @change="draw"
                ref="grid"
                />
              <grid
                v-else
                :columns="columns"
                :data="outputGridData"
                />
            </div>
            <div class="curve" ref="curve">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="calculate" v-show="!isInput">{{$t_("calculate")}}</el-button>
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
		</div>
    <alert :config="warningAlert" />
  </el-dialog>
</template>
<script>
import echarts from "echarts/dist/echarts.common.min.js";
import EditableGrid from "@/components/common/EditableGrid";
import Alert from "@/components/common/Alert";
import EditorLogger from "@/components/sections/EditorLogger";
import Grid from "@/components/common/Grid";
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import { mapGetters } from "vuex";
import {
  RESPONSE_CODE,
  EDITOR_STATUS,
  DATA_KEYS,
  DATA_TYPES,
  ACTION_TYPES,
  CURVE_OPTION_PATTERN,
  CURVE_YAXIS_DATA_PATTERN
} from "@/consts";
import {
  clone,
  convertStandardTermToDays,
  convertStandardTermToDate,
  validateStandardTerm,
  autoCompleteFields,
  isNumber,
  parseObjectToValueObject,
  getEditorTitle
} from "@/utils";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints.js";
export default {
  name: "CurveMainEditor",
  components: {
    EditableGrid,
    Alert,
    EditorLogger,
    Grid,
    FieldsRenderer
  },
  props: {
    visible: {
      required: true,
      type: Boolean
    },
    status: {
      required: true,
      type: Number
    }
  },
  data() {
    return {
      curveApp: null,
      logs: [],
      isInput: true,
      gridData: [],
      templateName: "",
      template: {},
      editingEntry: {},
      currentCurveData: {
        standardTerm: [],
        term: [],
        termValue: [],
        name: ""
      },
      warningAlert: {
        visible: false,
        title: "warning",
        message: "term_duplicated",
        buttons: [
          {
            title: "cancel",
            callback: () => {
              this.warningAlert.visible = false;
            }
          }
        ]
      },
      defaultCurveValue: {
        id: "Curve Value",
        type: "SURFACE",
        value: {
          dimensionCount: 1,
          surfaceValue: 0,
          surfaceValue1D: [],
          surfaceValue2D: [],
          surfaceValue3D: [],
          dimensions: [
            {
              dimension: []
            }
          ]
        },
        nestedType: ""
      }
    };
  },
  computed: {
    ...mapGetters({
      currentNav: "getCurrentNav",
      selectedEntry: "getSelectedEntry",
      templates: "getTemplates",
      marketDate: "getMarketDate"
    }),
    availableTemplateNames() {
      if (this.currentNav.templateFilter) {
        return this.currentNav.templateFilter.split(";").map(item => {
          return item.replace(/ /g, "_").toUpperCase();
        });
      } else {
        return [];
      }
    },
    outputGridData() {
      let data = [],
        gridData = clone(this.gridData);
      gridData.forEach(item => {
        data.push({
          attributes: parseObjectToValueObject(item)
        });
      });
      return data;
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return this.status === EDITOR_STATUS.ADDING;
    },
    isCloning() {
      return this.status === EDITOR_STATUS.CLONING;
    },
    categoryGroups() {
      if (this.template.measures) {
        return assembleTemplateCategories(this.template, this.$api);
      }
    },
    columns() {
      return [
        {
          attributeName: "standardTerm",
          displayName: "standard term",
          editable: true,
          required: true,
          drive: data => {
            if (!isNaN(Number(data.standardTerm))) {
              data.standardTerm += "D";
            }
            data.standardTerm = data.standardTerm.toUpperCase();
            data.term = convertStandardTermToDays(
              data.standardTerm,
              this.marketDate
            );
            data.date = convertStandardTermToDate(
              data.standardTerm,
              this.marketDate
            );
            return data;
          },
          validate: (val, rowIndex, editingEntry) => {
            let term = convertStandardTermToDays(val, this.marketDate);
            if (validateStandardTerm(val)) {
              if (rowIndex === "x") {
                return !this.gridData.some(item => item.term === term);
              } else {
                return !this.gridData.some((item, index) => {
                  return item.term === term && rowIndex !== index;
                });
              }
            }
            return false;
          }
        },
        {
          attributeName: "date",
          displayName: "date",
          sortable: true
        },
        {
          attributeName: "term",
          displayName: "term",
          sortable: true
        },
        {
          attributeName: "termValue",
          displayName: "term value",
          sortable: true,
          editable: true,
          required: true,
          validate: function(val) {
            return isNumber(val);
          }
        }
      ];
    },
    defaultCondition() {
      let condition = {
        searchType: "ID",
        searchValues: []
      };
      if (this.editingEntry.attributes) {
        condition.searchValues = [this.editingEntry.attributes["ID"].value];
      }
      return condition;
    },
    currencyPair() {
      let value = null;
      if (
        this.templateName === "CURVE_EXCHANGE_RATE" &&
        this.editingEntry.attributes
      ) {
        value = "{0}/{1}".format(
          this.editingEntry.attributes["Foreign Currency"].value,
          this.editingEntry.attributes["Domestic Currency"].value
        );
      }
      return value;
    }
  },
  watch: {
    visible(val) {
      if (val) {
        if (this.isAdding) {
          this.templateName = this.availableTemplateNames[0] || "";
        } else {
          this.templateName = this.selectedEntry.templateName;
        }
      } else {
        if (this.$refs.grid) {
          this.$refs.grid.clearAddingEntry();
        }
      }
    },
    editingEntry() {
      this.validationMap = {};
      if (
        this.editingEntry.attributes[DATA_KEYS.CURVE_VALUE] &&
        this.editingEntry.attributes[DATA_KEYS.CURVE_VALUE].value
      ) {
        let data = this.editingEntry.attributes[DATA_KEYS.CURVE_VALUE].value,
          term = data[DATA_KEYS.DIMENSIONS][0].dimension.map(standardTerm => {
            return convertStandardTermToDays(standardTerm, this.marketDate);
          });
        this.currentCurveData = {
          standardTerm: data[DATA_KEYS.DIMENSIONS][0].dimension,
          term: term,
          termValue: data[DATA_KEYS.SURFACE_VALUE_1D],
          name: this.editingEntry.id
        };
      } else {
        this.currentCurveData = {
          term: [],
          termValue: [],
          name: "",
          standardTerm: []
        };
      }
    },
    templateName(val) {
      if (val !== "") {
        this.template = this.templates[val];
        if (this.template) {
          this.template.measures.forEach(measure => {
            if (measure.attributeName === "Curve Value") {
              this.isInput = measure.input;
            }
          });
          this.reset();
        } else {
          console.error(`template: ${val} is not existing`);
        }
      }
    },
    currentCurveData() {
      var term = [],
        standardTerm = [],
        termValue = [];
      if (this.currentCurveData.standardTerm.length) {
        this.gridData = [];
        var mapTerm = {};
        this.currentCurveData.term.forEach((term, index) => {
          mapTerm[term] = {
            termValue: this.currentCurveData.termValue[index],
            standardTerm: this.currentCurveData.standardTerm[index]
          };
        });
        var sortTerm = this.currentCurveData.term.sort((a, b) => {
          return a - b;
        });
        sortTerm.forEach(item => {
          term.push(item);
          termValue.push(mapTerm[item].termValue);
          standardTerm.push(mapTerm[item].standardTerm);
          this.gridData.push({
            standardTerm: mapTerm[item].standardTerm,
            term: item,
            date: convertStandardTermToDate(
              mapTerm[item].standardTerm,
              this.marketDate
            ),
            termValue: mapTerm[item].termValue
          });
        });
      } else {
        this.gridData = [];
      }
      this.$nextTick(() => {
        this.initCurve({
          name: this.currentCurveData.name,
          term,
          termValue,
          standardTerm
        });
      });
    }
  },
  methods: {
    validateInner() {
      let isValid = false,
        invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      isValid = !invalidFields.length;
      if (isValid) {
        this.logs = [];
      } else {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      }
      if (this.templateName === "CURVE_EXCHANGE_RATE" && isValid) {
        if (
          this.editingEntry.attributes["Foreign Currency"].value ===
          this.editingEntry.attributes["Domestic Currency"].value
        ) {
          isValid = false;
          this.logs = [
            {
              msg: this.$t_("same_currency"),
              type: RESPONSE_CODE.WARNING
            }
          ];
        }
      }
      return isValid;
    },
    calculate() {
      //calculate the curve Value
      if (!this.validateInner()) return;
      let requestData = processApiHelper.getCalculateRequestData(
        this.editingEntry,
        this.template,
        DATA_TYPES.MARKETDATA
      );
      this.sendRequest(requestData).then(data => {
        let product = autoCompleteFields(data[0], this.template);
        this.editingEntry = product;
      });
    },
    save() {
      if (!this.validateInner()) return;
      if (this.isInput) {
        this.defaultCurveValue.value.surfaceValue1D = this.currentCurveData.termValue;
        this.defaultCurveValue.value.dimensions[0].dimension = this.currentCurveData.standardTerm;
        this.editingEntry.attributes[
          DATA_KEYS.CURVE_VALUE
        ] = this.defaultCurveValue;
        if (this.templateName === "CURVE_EXCHANGE_RATE") {
          this.editingEntry.attributes[
            "Currency Pair"
          ].value = this.currencyPair;
        }
      }
      this.validateID().then(() => {
        let requestData = processApiHelper.getUpdateRequestData(
          this.editingEntry,
          this.template
        );
        this.sendRequest(requestData).then(data => {
          let event = this.isAdding ? "add" : this.isCloning ? "clone" : "edit";
          this.$emit(event, data[0]);
          this.templateName = "";
        });
      });
    },
    close() {
      this.reset(true);
      this.resetEditor();
      this.$emit("close");
      this.templateName = "";
    },
    draw() {
      this.currentCurveData.term = [];
      this.currentCurveData.standardTerm = [];
      this.currentCurveData.termValue = [];
      var data = clone(this.gridData);
      data.sort((a, b) => {
        return (
          convertStandardTermToDays(a.term, this.marketDate) -
          convertStandardTermToDays(b.term, this.marketDate)
        );
      });
      if (data.length) {
        data.forEach(item => {
          this.currentCurveData.term.push(item.term);
          this.currentCurveData.standardTerm.push(item.standardTerm);
          this.currentCurveData.termValue.push(item.termValue);
        });
      }
      this.initCurve(this.currentCurveData);
    },
    resetEditor() {
      this.$refs.fieldsRenderer.forEach(renderer => renderer.reset());
    },
    reset(val) {
      this.resetBasicData();
      this.resetCurveData();
      this.logs = [];
    },
    resetBasicData() {
      let editingEntry;
      if (this.isAdding) {
        editingEntry = { attributes: {} };
      } else {
        editingEntry = clone(this.selectedEntry);
      }
      editingEntry = autoCompleteFields(
        editingEntry,
        this.template,
        this.isAdding
      );
      if (
        editingEntry.attributes[DATA_KEYS.CURVE_VALUE] &&
        editingEntry.attributes[DATA_KEYS.CURVE_VALUE].value
      ) {
        var data = editingEntry.attributes[DATA_KEYS.CURVE_VALUE].value;
        var term = data[DATA_KEYS.DIMENSIONS][0].dimension.map(standardTerm => {
          return convertStandardTermToDays(standardTerm, self.marketDate);
        });
        this.currentCurveData = {
          standardTerm: data[DATA_KEYS.DIMENSIONS][0].dimension,
          term: term,
          termValue: data[DATA_KEYS.SURFACE_VALUE_1D],
          name: editingEntry.id
        };
      } else {
        this.currentCurveData = {
          term: [],
          termValue: [],
          name: "",
          standardTerm: []
        };
      }
      this.editingEntry = editingEntry;
    },
    resetCurveData() {
      this.gridData = [];
    },

    initCurve(data) {
      if (this.curveApp) {
        this.curveApp.dispose();
        this.curveApp = null;
      }
      this.curveApp = echarts.init(this.$refs.curve);
      var curveAppOption = clone(CURVE_OPTION_PATTERN);
      curveAppOption.xAxis.data = data.standardTerm;
      var yAxisData = clone(CURVE_YAXIS_DATA_PATTERN);
      yAxisData.name = data.name;
      yAxisData.data = data.termValue;
      if (yAxisData.data.length === 1) {
        yAxisData.symbolSize = 5;
        yAxisData.symbol = "circle";
      }
      curveAppOption.series = [];
      curveAppOption.series.push(yAxisData);
      curveAppOption.tooltip.formatter = function(params) {
        return "Date: {0}<br/>Term: {1}<br/>value: {2}".format(
          convertStandardTermToDate(params[0].name, this.marketDate),
          params[0].name,
          params[0].value
        );
      }.bind(this);
      this.curveApp.setOption(curveAppOption);
    },
    showMessage(message) {
      this.logs = [
        {
          msg: message,
          type: RESPONSE_CODE.WARNING
        }
      ];
    },
    validateID() {
      if (this.isAdding || this.isCloning) {
        let requestData = productApiHelper.getRequestData(
          this.defaultCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.MARKETDATA
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.warningAlert.visible = true;
              this.warningAlert.message = "ID_duplicated";
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    sendRequest(requestData) {
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data);
          } else {
            return Promise.reject();
          }
        },
        error => {
          console.log(error);
          return Promise.reject();
        }
      );
    }
  }
};
</script>

<style scoped>
.main-editor {
  padding: 0 20px;
  height: calc(100% - 35px);
  height: -ms-calc(100% - 35px);
  height: -moz-calc(100% - 35px);
  height: -webkit-calc(100% - 35px);
}
.template-selector {
  padding: 0 10px;
  background-color: rgb(152, 164, 197);
  height: 30px;
  line-height: 30px;
}
.template-selector label {
  padding-right: 3px;
}
.editor-panel {
  border: 1px solid #ccc;
  height: calc(100% - 55px);
  height: -ms-calc(100% - 55px);
  height: -moz-calc(100% - 55px);
  height: -webkit-calc(100% - 55px);
  padding: 0 10px;
  overflow: auto;
}
.panel-title {
  display: inline-block;
  padding: 6px 12px;
  background-color: #4e586f;
  color: #ffffff;
  font-weight: bold;
  border-radius: 2px;
  margin-top: 6px;
  margin-bottom: 2px;
}
.section {
  border-bottom: 1px solid #ccc;
}
.grid-panel {
  margin-top: 10px;
}
.table,
.curve {
  height: 400px;
  width: 50%;
  float: left;
  overflow-y: auto;
}
</style>
