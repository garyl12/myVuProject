<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="template-selector" v-if="isAdding">
        <label>{{$t_("select_template")}}</label><label>:</label>
        <select v-model="templateName">
          <option v-for="(item,index) in availableTemplateNames" :key="index" :value="item">{{item}}</option>
        </select>
    </div>
    <div class="main-editor" :style="{'margin-top':isAdding?'0':'30px'}">
      <editor-logger :logs="logs" :above="true" />
      <div class="editor-title clearfix">
        <tabs :tabs="editorTabs" @click="showEditorTab" :active-index="activeTabIndex" />
      </div>
      <div class="editor-panel">
        <div v-for="(item,index) in editorTabs" :key="index" v-show="index===activeTabIndex">
          <basic-info-editor v-if="item===EDITOR_TAB_TYPES.BASIC_INFO" :ref="item" :is-adding="isAdding||isCloning" @message="showMessage" />
          <curve-editor v-else-if="item===EDITOR_TAB_TYPES.CURVE" :ref="item" @message="showMessage" />
          <common-tab-editor :editor-tab-type="item" v-else-if="item===EDITOR_TAB_TYPES.ISSUE_RECORD||item===EDITOR_TAB_TYPES.RATING||item===EDITOR_TAB_TYPES.THIRD_PARTY_VALUATION||item===EDITOR_TAB_TYPES.COLLATERAL_BOND_INFO" :ref="item" @message="showMessage" />
          <cashflow-editor v-else-if="item===EDITOR_TAB_TYPES.CASHFLOW" :ref="item" @message="showMessage" />
        </div>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="valuate">{{$t_("valuate")}}</el-button>
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
		</div>
    <alert :config="alert" />
  </el-dialog>
</template>
<script>
import BasicInfoEditor from "./editorTabs/BasicInfoEditor";
import CurveEditor from "./editorTabs/CurveEditor";
import CashflowEditor from "./editorTabs/CashflowEditor";
import CommonTabEditor from "./editorTabs/CommonTabEditor";
import EditorLogger from "@/components/sections/EditorLogger";
import Tabs from "@/components/common/Tabs";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import {
  EDITOR_TAB_TYPES,
  FIELD_TYPES,
  EDITOR_STATUS,
  RESPONSE_CODE,
  DATA_TYPES
} from "@/consts";
import { clone, autoCompleteFields, getEditorTitle } from "@/utils";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints.js";

export default {
  name: "InstrumentEditor",
  props: {
    visible: {
      required: true,
      type: Boolean
    },
    status: {
      required: true,
      type: Number
    }
  },
  components: {
    BasicInfoEditor,
    CurveEditor,
    CommonTabEditor,
    CashflowEditor,
    EditorLogger,
    Tabs,
    Alert
  },
  data() {
    return {
      activeTabIndex: 0,
      logs: [],
      templateName: "",
      template: {},
      alert: {
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      currentNav: "getCurrentNav",
      selectedEntry: "getSelectedEntry",
      templates: "getTemplates",
      currentEditingEntry: "getEditingEntry"
    }),
    editorTabs() {
      var tabs = [EDITOR_TAB_TYPES.BASIC_INFO, EDITOR_TAB_TYPES.CURVE];
      (this.template.measures || []).forEach(measure => {
        if (measure.dataType === FIELD_TYPES.TABLE) {
          tabs.push(measure.name);
        }
      });
      return tabs;
    },
    availableTemplateNames() {
      return (this.currentNav.templateFilter || "").split(";");
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return this.status === EDITOR_STATUS.ADDING;
    },
    isCloning() {
      return this.status === EDITOR_STATUS.CLONING;
    },
    EDITOR_TAB_TYPES() {
      return EDITOR_TAB_TYPES;
    },
    baseCondition() {
      let condition = {
        searchType: "ID",
        searchValues: []
      };
      if (this.currentEditingEntry.attributes) {
        condition.searchValues = [
          this.currentEditingEntry.attributes["ID"].value
        ];
      }
      return condition;
    }
  },
  watch: {
    visible(val) {
      this.templateName = "";
      if (val) {
        // reset data before popup window is visible
        this.resetTemplate();
      }
    },
    templateName(val) {
      if (val) {
        var templateKey = val.toUpperCase().replace(/[ ]/g, "_");
        this.template = this.templates[templateKey];
        if (!this.template) {
          console.error(templateKey + " can not be found.");
        }
        var editingEntry = autoCompleteFields(
          this.isAdding ? { attributes: {} } : clone(this.selectedEntry),
          this.template,
          this.isAdding
        );
        this.$store.commit("setEditingTemplate", this.template);
        this.$store.commit("setEditingEntry", editingEntry);
      } else {
        this.template = {};
        this.$store.commit("setEditingTemplate", {});
        this.$store.commit("setEditingEntry", { attributes: {} });
      }
    }
  },
  methods: {
    validate() {
      let { isValid, invalidFields } = this.$refs[
        EDITOR_TAB_TYPES.BASIC_INFO
      ][0].validate();
      if (!isValid) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    validateID() {
      if (this.isAdding || this.isCloning) {
        let requestData = productApiHelper.getRequestData(
          this.baseCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.MARKETDATA
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert.visible = true;
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    showEditorTab({ tab, index }) {
      this.activeTabIndex = index;
      switch (tab) {
        case EDITOR_TAB_TYPES.ISSUE_RECORD:
        case EDITOR_TAB_TYPES.RATING:
        case EDITOR_TAB_TYPES.THIRD_PARTY_VALUATION:
        case EDITOR_TAB_TYPES.CURVE:
        case EDITOR_TAB_TYPES.CASHFLOW:
        case EDITOR_TAB_TYPES.COLLATERAL_BOND_INFO:
          this.$refs[tab][0].show();
          break;
      }
    },
    save() {
      if (!this.validate()) return;
      this.validateID().then(() => {
        let requestData = processApiHelper.getUpdateRequestData(
          this.currentEditingEntry,
          this.template
        );
        this.sendRequest(requestData).then(data => {
          let event = this.isAdding ? "add" : this.isCloning ? "clone" : "edit";
          this.$emit(event, data[0]);
        });
      });
    },
    close() {
      this.reset();
      this.$emit("close");
    },
    valuate() {
      if (!this.validate()) return;
      let requestData = processApiHelper.getCalculateRequestData(
        this.currentEditingEntry,
        this.template,
        DATA_TYPES.MARKETDATA
      );
      this.sendRequest(requestData).then(data => {
        let product = autoCompleteFields(data[0], this.template);
        this.$store.commit("setEditingEntry", product);
      });
    },
    resetTemplate() {
      this.templateName = this.isAdding
        ? this.availableTemplateNames[0]
        : this.selectedEntry.templateName;
    },
    reset() {
      this.logs = [];
      this.activeTabIndex = 0;
      if (this.$refs[this.editorTabs[this.activeTabIndex]]) {
        this.$refs[this.editorTabs[this.activeTabIndex]][0].reset();
      }
    },
    showMessage(message) {
      this.logs = [
        {
          msg: message,
          type: RESPONSE_CODE.WARNING
        }
      ];
    },
    sendRequest(requestData) {
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data);
          } else {
            return Promise.reject();
          }
        },
        error => {
          console.log(error);
          return Promise.reject();
        }
      );
    }
  }
};
</script>
<style scoped>
.main-editor {
  padding: 0 20px;
  height: calc(100% - 35px);
  height: -ms-calc(100% - 35px);
  height: -moz-calc(100% - 35px);
  height: -webkit-calc(100% - 35px);
  margin-top: 30px;
}
.template-selector {
  padding: 0 10px;
  background-color: rgb(152, 164, 197);
  height: 30px;
  line-height: 30px;
}
.template-selector label {
  padding-right: 3px;
}
.editor-title {
  height: 30px;
  line-height: 28px;
  margin-top: 5px;
}
.editor-panel {
  border: 1px solid #ccc;
  height: calc(100% - 55px);
  height: -ms-calc(100% - 55px);
  height: -moz-calc(100% - 55px);
  height: -webkit-calc(100% - 55px);
  padding: 0 10px;
  overflow: auto;
}
.editor-panel > div {
  height: 100%;
}
</style>
