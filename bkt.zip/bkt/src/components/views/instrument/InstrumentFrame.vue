<template>
  <div class="main-frame" ref="frame">
    <div class="grid-area" ref="top">
      <grid
        :need-index="true"
        :need-pager="true"
        :columns="columns"
        :data="grid.data"
        :page-index="grid.pageIndex"
        :page-count="grid.pageCount"
        @select="select"
        @prev-page="retrieveData"
        @next-page="retrieveData"
        @jump-page="retrieveData"
        @sort="retrieveData"
        ref="gridView"
        >
        <button-bar
          :padding-right="grid.pageCount>0?140:0"
          :buttons="buttons" />
      </grid>
      <searcher
        :visible="grid.searcherVisible"
        :fields="searchableFields"
        :conditions="grid.searchBy"
        @search="retrieveData"
        @close="grid.searcherVisible=false"
        />
    </div>
    <resizer axis="y" @resize="resizeFrame"></resizer>
    <div class="sub-window-area" ref="bottom">
      <sub-window-view ref="subWindowView">
      </sub-window-view>
    </div>
    <instrument-editor
      :visible="editor.visible"
      :status="editor.status"
      v-if="menuName === MAIN_MENU_NAMES.INSTRUMENT "
      @edit="postEdit"
      @add="postAdd"
      @clone="postAdd"
      @close="editor.visible=false"
      />
    <curve-main-editor
      :visible="editor.visible"
      :status="editor.status"
      v-else-if="menuName===MAIN_MENU_NAMES.CURVE"
      @edit="postEdit"
      @add="postAdd"
      @clone="postAdd"
      @close="editor.visible=false"
      />
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
    <file-downloader
      :src="downloader.src"
      :visible="downloader.visible"
      :file-types="fileTypes"
      @select-type="exportProduct"
      @close="downloader.visible=false"
      />
  </div>
</template>
<script>
import Grid from "@/components/common/Grid";
import Searcher from "@/components/common/Searcher";
import SubWindowView from "@/components/sections/SubWindowView";
import Resizer from "@/components/common/Resizer";
import InstrumentEditor from "./InstrumentEditor";
import CurveMainEditor from "./CurveMainEditor";
import endpoints from "@/api/endpoints";
import Alert from "@/components/common/Alert";
import FileDownloader from "@/components/common/FileDownloader";
import ButtonBar from "@/components/common/ButtonBar";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import { clone, getViewName, assembleDownloadUrl } from "@/utils";
import mixin from "../mixin";
import {
  DATA_TYPES,
  PAGE_SIZE,
  DEFAULT,
  EDITOR_STATUS,
  MAIN_MENU_NAMES,
  RESPONSE_CODE,
  FILE_TYPES,
  SIZE
} from "@/consts";

export default {
  name: "InstrumentFrame",
  components: {
    Grid,
    Searcher,
    SubWindowView,
    Resizer,
    InstrumentEditor,
    CurveMainEditor,
    Alert,
    FileDownloader,
    ButtonBar
  },
  mixins: [mixin],
  data() {
    return {
      alert: {
        visible: false,
        title: "warning",
        message: "",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeConfirmation.visible = false;
              this.doRemove();
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
      grid: {
        searcherVisible: false,
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        pageCount: -1,
        pageIndex: -1,
        searchBy: null,
        sortBy: null,
        requestCondition: {}
      },
      editor: {
        visible: false,
        status: -1
      },
      downloader: {
        src: "",
        visible: false
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      currentNav: "getCurrentNav",
      mapping: "getMapping",
      selectedEntry: "getSelectedEntry",
      attributes: "getAttributes"
    }),
    menuName() {
      return this.$route.fullPath.split("/")[1];
    },
    searchableFields() {
      var availableTemplateNames = [];
      var detectedFieldNameMapping = {};
      var searchableFields = [];

      if (this.currentNav.templateFilter) {
        availableTemplateNames = this.currentNav.templateFilter
          .split(";")
          .map(item => {
            return item.replace(/ /g, "_").toUpperCase();
          });
      }
      availableTemplateNames.forEach(templateName => {
        if (this.templates[templateName]) {
          this.templates[templateName].measures.forEach(field => {
            if (field.searchAble && !detectedFieldNameMapping[field.name]) {
              searchableFields.push(field);
              detectedFieldNameMapping[field.name] = true;
            }
          });
        }
      });
      return searchableFields;
    },
    viewName() {
      let viewName = null;
      if (DEFAULT in this.views) {
        viewName = getViewName(this.currentNav.id, this.mapping, this.views);
      }
      return viewName ? viewName : DEFAULT;
    },
    columns() {
      let columns = [];
      if (DEFAULT in this.views) {
        let columnNames = this.views[this.viewName][0].attributesInMainGrid;
        columnNames.split(";").forEach(header => {
          if (this.attributes[header]) {
            columns.push(this.attributes[header]);
          } else {
            let defaultItem = {
              displayName: header,
              attributeName: header
            };
            columns.push(defaultItem);
          }
        });
      }
      return columns;
    },
    defaultCondition() {
      let searchValues = [];
      if (this.currentNav.dataFilter) {
        searchValues = this.currentNav.dataFilter.split(";");
      }
      return {
        searchType: "TYPE",
        searchValues
      };
    },
    fileTypes() {
      return FILE_TYPES;
    },
    buttons() {
      return [
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.grid.searcherVisible = true;
          }
        },
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active: this.grid.selectedIndex !== -1,
          text: "edit",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.grid.selectedIndex !== -1,
          text: "clone",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.CLONING;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.grid.selectedIndex !== -1,
          text: "remove",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-daochu",
          active: this.grid.pageCount > 0,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    },
    template() {
      let template = null;
      if (this.grid.selectedItem) {
        template = this.templates[this.grid.selectedItem.templateName];
      }
      return template;
    },
    MAIN_MENU_NAMES() {
      return MAIN_MENU_NAMES;
    }
  },
  watch: {
    currentNav() {
      this.loadGridData();
    },
    "grid.selectedItem": function(val) {
      this.$store.commit("setSelectedEntry", val || {});
    }
  },
  mounted() {
    // currentNav will be empty when entering this component after refreshing page
    // but when navigating from other component, it should be assigned
    if (this.currentNav.href) {
      this.loadGridData();
    }
  },
  methods: {
    loadGridData() {
      if (this.cache[this.$route.path]) {
        this.grid = JSON.parse(this.cache[this.$route.path]);
      } else {
        this.grid.data = [];
        this.grid.sortBy = null;
        this.grid.searchBy = null;
        this.grid.pageIndex = 1;
        this.grid.selectedIndex = -1;
        this.grid.selectedItem = null;
        let requestParameters = productApiHelper.getRequestData(
          this.defaultCondition,
          null,
          null,
          null,
          null,
          DATA_TYPES.MARKETDATA,
          1
        );
        this.requestData(requestParameters);
      }
    },
    requestData(requestParameters) {
      this.grid.requestCondition = requestParameters;
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ data }) => {
          this.grid.pageCount = Math.ceil(data.recordCount / data.pageSize);
          this.grid.data = data.records;
          if (data.recordCount) {
            this.$refs.gridView.selectDefault();
            this.grid.searcherVisible = false;
          } else {
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          }
        });
    },
    resizeFrame(offset) {
      //calculate distance first  then assignment directly
      let topHeight = this.$refs.top.clientHeight,
        bottomHeight = this.$refs.bottom.clientHeight,
        topMinHeight = SIZE.GRID.PAGER_HEIGHT + SIZE.GRID.TABLE_MIN_HEIGHT,
        bottomMinHeight = SIZE.SUB_WINDOW_MIN_HEIGHT,
        distance = Math.min(
          Math.max(topMinHeight - topHeight, offset),
          bottomHeight - bottomMinHeight
        );

      this.$refs.top.style.height = topHeight + distance + "px";
      this.$refs.bottom.style.height = bottomHeight - distance + "px";

      this.$refs.gridView.resize();
      this.$refs.subWindowView.resize();
    },
    select({ currentItem, index }) {
      this.grid.selectedIndex = index;
      this.grid.selectedItem = currentItem;
    },
    retrieveData({ sortBy, searchBy, pageIndex = 1 }) {
      this.grid.sortBy = sortBy || this.grid.sortBy;
      this.grid.searchBy = searchBy || this.grid.searchBy;
      this.grid.pageIndex = pageIndex;
      let requestParameters = productApiHelper.getRequestData(
        this.defaultCondition,
        null,
        this.grid.searchBy,
        this.grid.sortBy,
        null,
        DATA_TYPES.MARKETDATA,
        pageIndex
      );
      this.requestData(requestParameters);
    },
    exportProduct(type) {
      let exportParameters = productApiHelper.changeToExportRequestData(
        this.grid.requestCondition,
        type
      );
      this.$api.request(endpoints.getProductData, exportParameters).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    },
    doRemove() {
      let requestData = processApiHelper.getDeleteRequestData(
        this.selectedEntry,
        this.template
      );
      this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.grid.data.splice(this.grid.selectedIndex, 1);
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    postEdit(product) {
      this.grid.data.splice(this.grid.selectedIndex, 1, product);
      this.grid.selectedItem = product;
      this.$set(product, "_selected", true);
      this.editor.visible = false;
    },
    postAdd(product) {
      this.grid.data.unshift(product);
      this.$refs.gridView.selectDefault();
      this.editor.visible = false;
      if (!this.grid.pageCount) this.grid.pageCount = 1;
    },
    resize() {
      this.resizeFrame(0);
    },
    getCacheData() {
      return this.grid;
    }
  }
};
</script>
<style scoped>
.main-frame {
  height: 100%;
}
.grid-area {
  height: 60%;
}
.sub-window-area {
  height: calc(40% - 8px);
  height: -ms-calc(40% - 8px);
  height: -moz-calc(40% - 8px);
  height: -webkit-calc(40% - 8px);
}
</style>
