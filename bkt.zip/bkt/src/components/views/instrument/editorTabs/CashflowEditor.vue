<template>
  <div style="height: 100%">
    <div class="main-section clearfix" v-show="isInput">
      <div v-for="(field,index) in fields" :key="index" class="float-field">
        <display-field
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :field-val="(entry.attributes[field.name]||{value:''}).value|formatDisplay(field.displayFormat)"
          v-if="!field.editableInNew||!field.editableInEdit||field.output"
          />
        <text-field
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :field-val="editingRecord[field.name]"
          v-model="editingRecord[field.name]"
          v-else-if="field.dataType===FIELD_TYPES.STRING&&!field.list"
          :allow-multi="field.list"
          />
        <dropdownlist-field
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :field-val="editingRecord[field.name]"
          :options="dictionary | lookup(field.enumRef)"
          :for-boolean="field.dataType===FIELD_TYPES.BOOLEAN"
          v-model="editingRecord[field.name]"
          v-else-if="field.dataType===FIELD_TYPES.STRING&&field.enumRef||field.dataType===FIELD_TYPES.BOOLEAN"
          />
        <date-field
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :field-val="editingRecord[field.name]"
          v-model="editingRecord[field.name]"
          v-else-if="field.dataType===FIELD_TYPES.DATE"
          />
        <number-field
          :field-name="$t_(field.name)|decorateFieldName(field.displayFormat)"
          :field-val="editingRecord[field.name]"
          :format="field.displayFormat"
          :allow-multi="field.list"
          v-model="editingRecord[field.name]"
          v-else-if="field.dataType===FIELD_TYPES.DOUBLE||field.dataType===FIELD_TYPES.INTEGER"
          />
      </div>
    </div>
    <div class="button-section clearfix" v-show="isInput">
      <span class="btn btn-dark" @click="resetEditor">{{$t_("reset")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isRemoveEnabled}]" @click="remove">{{$t_("remove")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isSaveEnabled}]" @click="save">{{$t_("save")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isSaveEnabled}]" @click="cancel">{{$t_("cancel")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isEditEnabled}]" @click="edit">{{$t_("edit")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isAddEnabled}]" @click="add">{{$t_("add")}}</span>
    </div>
    <div :class="['grid-section','clearfix',{'grid-section-full':!isInput}]" :style="{height:gridSectionHeight}">
      <grid
        :need-index="true"
        :columns="gridColumns"
        :data="gridData"
        ref="grid"
        />
    </div>
    <alert :config="removeConfirmation" />
  </div>
</template>
<script>
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import NumberField from "@/components/fields/NumberUIField";
import DateField from "@/components/fields/DateUIField";
import DisplayField from "@/components/fields/DisplayField";
import Grid from "@/components/common/Grid";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import {
  parseEntityTableFieldValueToEntity,
  parseBeanToEntity,
  parseBeanToEntityTableFieldValue,
  parseEntityToBean,
  clone
} from "@/utils";
import {
  FIELD_TYPES,
  DATA_KEYS,
  TAB_TYPES,
  EDITOR_TAB_COLUMNS
} from "@/consts";
// field is 24px, its vertical margin is 4px
const fieldLineHeight = 24 + 4 + 4;

export default {
  name: "CashflowEditor",
  components: {
    TextField,
    DropdownlistField,
    NumberField,
    DateField,
    DisplayField,
    Grid,
    Alert
  },
  computed: {
    ...mapGetters({
      entry: "getEditingEntry",
      selectedEntry: "getSelectedEntry",
      template: "getEditingTemplate"
    }),
    fields() {
      var fields = [];
      if (this.template.measures) {
        this.template.measures.forEach(measure => {
          if (measure.name === this.key) {
            this.isInput = measure.input;
            fields = measure.subMeasures;
            return;
          }
        });
      }
      return fields;
    },
    gridColumns() {
      var cols = [];
      var colNames = EDITOR_TAB_COLUMNS.CASHFLOW;
      this.fields.forEach(field => {
        field.isSortable = false;
        cols.push(field);
      });
      return cols;
    },
    mainSectionHeight() {
      return Math.ceil(this.fields.length / 4) * fieldLineHeight;
    },
    gridSectionHeight() {
      if (this.isInput) {
        return "calc(100% - " + this.mainSectionHeight + "px)";
      } else {
        return "100%";
      }
    },
    isAddEnabled() {
      return this.editingRecordIndex === -1;
    },
    isEditEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex === -1
      );
    },
    isSaveEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex !== -1
      );
    },
    isRemoveEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex === -1
      );
    },
    FIELD_TYPES() {
      return FIELD_TYPES;
    }
  },
  watch: {
    entry() {
      this.initGridData();
    }
  },
  mounted() {
    this.initGridData();
  },
  data() {
    return {
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.gridData.splice(this.selectedGridRecordIndex, 1);
              this.entry.attributes[this.key].value.splice(
                this.selectedGridRecordIndex,
                1
              );
              this.selectedGridRecordIndex = -1;
              this.editingRecordIndex = -1;
              this.editingRecord = {};
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
      isAdding: true,
      isInput: false,
      key: DATA_KEYS.CASHFLOW_INFO,
      gridData: [],
      editingRecordIndex: -1,
      editingRecord: {},
      selectedGridRecordIndex: -1,
      selectedGridRecord: {}
    };
  },
  methods: {
    initGridData() {
      if (
        !this.entry.attributes[this.key] ||
        !this.entry.attributes[this.key].value
      ) {
        this.entry.attributes[this.key] = { value: [] };
      }
      this.gridData = parseEntityTableFieldValueToEntity(
        clone(this.entry.attributes[this.key].value)
      );
    },
    add() {
      if (!this.isAddEnabled) return;
      if (JSON.stringify(this.editingRecord) === JSON.stringify({})) return;
      this.gridData.push(parseBeanToEntity(this.editingRecord));
      this.entry.attributes[this.key].value.push(
        parseBeanToEntityTableFieldValue(this.editingRecord)
      );
      this.editingRecord = {};
    },
    edit() {
      if (!this.isEditEnabled) return;
      this.isAdding = false;
      this.editingRecord = clone(parseEntityToBean(this.selectedGridRecord));
      this.editingRecordIndex = this.selectedGridRecordIndex;
    },
    cancel() {
      this.editingRecordIndex = -1;
      this.editingRecord = {};
      this.isAdding = true;
    },
    save() {
      if (!this.isSaveEnabled) return;
      if (JSON.stringify(this.editingRecord) === JSON.stringify({})) return;
      this.gridData[this.editingRecordIndex] = parseBeanToEntity(
        this.editingRecord
      );
      this.gridData = clone(this.gridData);
      this.entry.attributes[this.key].value[
        this.selectedGridRecordIndex
      ] = parseBeanToEntityTableFieldValue(this.editingRecord);
      this.selectedGridRecordIndex = -1;
      this.editingRecordIndex = -1;
      this.editingRecord = {};
      this.isAdding = true;
    },
    remove() {
      if (!this.isRemoveEnabled) return;
      this.removeConfirmation.message = "remove_confirmation";
      this.removeConfirmation.visible = true;
    },
    resetEditor() {
      this.editingRecord = this.isAdding
        ? {}
        : clone(parseEntityToBean(this.selectedGridRecord));
    },
    show() {
      var self = this;
      this.$nextTick(function() {
        self.$refs.grid.resize();
      });
    },
    selectGridEntry({ currentItem, index }) {
      this.selectedGridRecord = currentItem;
      this.selectedGridRecordIndex = index;
    },
    resetEntry() {
      let records = this.$parent.$parent.isAdding
        ? []
        : clone(
            this.selectedEntry.attributes[this.key]
              ? this.selectedEntry.attributes[this.key].value
              : []
          );
      this.entry.attributes[this.key].value = records;
      this.gridData = parseEntityTableFieldValueToEntity(records);
    },
    reset() {
      this.resetEntry();
      this.isAdding = true;
      this.resetEditor();
    }
  }
};
</script>
<style scoped>
.main-section {
  height: 160px;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
.float-field {
  float: left;
  width: 25%;
  margin: 2px 0 0;
}
.button-section {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  padding: 20px 0;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  height: 70px;
}
.button-section > span {
  float: right;
}
</style>
