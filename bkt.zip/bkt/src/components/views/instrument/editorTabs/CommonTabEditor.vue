<template>
  <div style="height: 100%">
    <fields-renderer
      :fields="fields"
      :entry="editingRecord"
      :is-data-bean="true"
      :adding="isAdding"
      ref="fieldsRenderer"
      />
    <div class="button-section clearfix">
      <span class="btn btn-dark" @click="resetEditor">{{$t_("reset")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isRemoveEnabled}]" @click="remove">{{$t_("remove")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isSaveEnabled}]" @click="save">{{$t_("save")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isSaveEnabled}]" @click="cancel">{{$t_("cancel")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isEditEnabled}]" @click="edit">{{$t_("edit")}}</span>
      <span :class="['btn','btn-dark',{'disable':!isAddEnabled}]" @click="add">{{$t_("add")}}</span>
    </div>
    <div class="clearfix" :style="{height:gridSectionHeight}">
      <grid
        ref="grid"
        :need-index="true"
        :columns="gridColumns"
        :data="gridData"
        @select="selectGridEntry"
        />
    </div>
    <alert :config="removeConfirmation" />
  </div>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import Grid from "@/components/common/Grid";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import {
  parseEntityTableFieldValueToEntity,
  parseBeanToEntity,
  parseBeanToEntityTableFieldValue,
  parseEntityToBean,
  clone
} from "@/utils";
import { generateReferenceSelectorOption } from "@/components/sections/FieldsRenderer";
import { EDITOR_TAB_TYPES, DATA_KEYS } from "@/consts";

// field is 24px, margin-top is 2px
const fieldLineHeight = 24;
// button area hight is 70px
// margin top is 10px
// grid area margin top is 10px
const buttonAreaHeight = 80;

export default {
  name: "CommonTabEditor",
  components: {
    FieldsRenderer,
    Grid,
    Alert
  },
  props: {
    editorTabType: {
      type: String,
      required: true
    }
  },
  computed: {
    ...mapGetters({
      entry: "getEditingEntry",
      selectedEntry: "getSelectedEntry",
      template: "getEditingTemplate",
      dictionary: "getDicts"
    }),
    key() {
      let key = "";
      switch (this.editorTabType) {
        case EDITOR_TAB_TYPES.ISSUE_RECORD:
          key = DATA_KEYS.BOND_ISSUANCE_AND_GUARANTEE;
          break;
        case EDITOR_TAB_TYPES.RATING:
          key = DATA_KEYS.SECURITY_RATING_INFO;
          break;
        case EDITOR_TAB_TYPES.THIRD_PARTY_VALUATION:
          key = DATA_KEYS.THIRDPARTY_VALUATION;
          break;
        case EDITOR_TAB_TYPES.OPTION_SCHEDULE:
          key = DATA_KEYS.THIRDPARTY_VALUATION;
          break;
        case EDITOR_TAB_TYPES.COLLATERAL_BOND_INFO:
          key = DATA_KEYS.COLLATERAL_BOND_INFO;
          break;
        default:
          throw new Error(
            "Can not find key by property {editorTabType: " +
              this.editorTabType +
              "}"
          );
          break;
      }
      return key;
    },
    fields() {
      let subMeasures = [],
        fields = [];
      this.template.measures.some(measure => {
        if (measure.name === this.key) {
          subMeasures = measure.subMeasures;
          return true;
        }
      });
      subMeasures.forEach(measure => {
        if (measure.visible) {
          let field = clone(measure);
          if (field.reference) {
            field.options = generateReferenceSelectorOption(field, this.$api);
          }
          fields.push(field);
        }
      });
      return fields;
    },
    gridColumns() {
      var cols = [];
      this.fields.forEach(field => {
        field.isSortable = false;
        cols.push(field);
      });
      return cols;
    },
    mainSectionHeight() {
      return Math.ceil(this.fields.length / 4) * fieldLineHeight;
    },
    gridSectionHeight() {
      return (
        "calc(100% - " + (this.mainSectionHeight + buttonAreaHeight) + "px)"
      );
    },
    isAddEnabled() {
      return this.editingRecordIndex === -1;
    },
    isEditEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex === -1
      );
    },
    isSaveEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex !== -1
      );
    },
    isRemoveEnabled() {
      return (
        this.selectedGridRecordIndex !== -1 && this.editingRecordIndex === -1
      );
    }
  },
  watch: {
    entry() {
      this.initGridData();
    }
  },
  mounted() {
    this.initGridData();
  },
  data() {
    return {
      removeConfirmation: {
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "confirm",
            callback: () => {
              this.gridData.splice(this.selectedGridRecordIndex, 1);
              this.entry.attributes[this.key].value.splice(
                this.selectedGridRecordIndex,
                1
              );
              this.selectedGridRecordIndex = -1;
              this.editingRecordIndex = -1;
              this.editingRecord = {};
              this.removeConfirmation.visible = false;
            }
          }
        ],
        visible: false
      },
      isAdding: true,
      gridData: [],
      editingRecordIndex: -1,
      editingRecord: {},
      selectedGridRecordIndex: -1,
      selectedGridRecord: {}
    };
  },
  methods: {
    initGridData() {
      if (
        !this.entry.attributes[this.key] ||
        !this.entry.attributes[this.key].value
      ) {
        this.entry.attributes[this.key] = { value: [] };
      }
      this.gridData = parseEntityTableFieldValueToEntity(
        clone(this.entry.attributes[this.key].value)
      );
    },
    validate() {
      let { isValid, invalidFields } = this.$refs.fieldsRenderer.validate();
      if (!isValid) {
        this.$emit(
          "message",
          this.$t_("field_invalid_message") + ": " + invalidFields.join(",")
        );
      }
      return isValid;
    },
    add() {
      if (!this.isAddEnabled) return;
      if (!this.validate()) return;
      let isEmptyObject = true;
      for (let attr in this.editingRecord) {
        if (this.editingRecord[attr]) {
          isEmptyObject = false;
          break;
        }
      }
      if (isEmptyObject) return;
      this.gridData.push(parseBeanToEntity(this.editingRecord));
      this.entry.attributes[this.key].value.push(
        parseBeanToEntityTableFieldValue(this.editingRecord)
      );
      this.editingRecord = {};
      this.$parent.$parent.logs = [];
    },
    edit() {
      if (!this.isEditEnabled) return;
      this.isAdding = false;
      this.editingRecord = clone(parseEntityToBean(this.selectedGridRecord));
      this.editingRecordIndex = this.selectedGridRecordIndex;
    },
    cancel() {
      this.editingRecordIndex = -1;
      this.editingRecord = {};
      this.isAdding = true;
    },
    save() {
      if (!this.isSaveEnabled) return;
      if (!this.validate()) return;
      let isEmptyObject = true;
      for (let attr in this.editingRecord) {
        if (this.editingRecord[attr]) {
          isEmptyObject = false;
          break;
        }
      }
      if (isEmptyObject) return;
      this.gridData.splice(
        this.editingRecordIndex,
        1,
        parseBeanToEntity(this.editingRecord)
      );
      this.entry.attributes[this.key].value[
        this.selectedGridRecordIndex
      ] = parseBeanToEntityTableFieldValue(this.editingRecord);
      this.selectedGridRecordIndex = -1;
      this.editingRecordIndex = -1;
      this.editingRecord = {};
      this.isAdding = true;
    },
    remove() {
      if (!this.isRemoveEnabled) return;
      this.removeConfirmation.visible = true;
    },
    resetEditor() {
      this.editingRecord = this.isAdding
        ? {}
        : clone(parseEntityToBean(this.selectedGridRecord));
      this.$refs.fieldsRenderer.reset();
    },
    show() {
      this.$nextTick(function() {
        this.$refs.grid.resize();
      });
    },
    selectGridEntry({ currentItem, index }) {
      this.selectedGridRecord = currentItem;
      this.selectedGridRecordIndex = index;
    },
    resetEntry() {
      let records = this.$parent.$parent.isAdding
        ? []
        : clone(
            this.selectedEntry.attributes[this.key]
              ? this.selectedEntry.attributes[this.key].value
              : []
          );
      this.entry.attributes[this.key].value = records;
      this.gridData = parseEntityTableFieldValueToEntity(records);
    },
    reset() {
      this.resetEntry();
      this.isAdding = true;
      this.resetEditor();
    }
  }
};
</script>

<style scoped>
.button-section {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  margin-top: 10px;
  padding: 20px 0;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  height: 70px;
}
.button-section > span {
  float: right;
}
</style>
