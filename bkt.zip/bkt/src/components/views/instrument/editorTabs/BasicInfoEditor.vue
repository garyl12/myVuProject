<template>
  <div>
    <div class="category-group" v-for="(category,index) in categoryGroups" :key ="index" v-show="category.fields.length">
      <div class="section">
        <span class="category-title">{{$t_(category.groupName||"")}}</span>
      </div>
      <fields-renderer
        :fields="category.fields"
        :entry="entry"
        :adding="isAdding"
        ref="fieldsRenderer"
      />
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import { clone, autoCompleteFields } from "@/utils";

export default {
  name: "BasicInfoEditor",
  components: {
    FieldsRenderer
  },
  props: {
    isAdding: {
      type: Boolean,
      required: true
    }
  },
  computed: {
    ...mapGetters({
      template: "getEditingTemplate",
      entry: "getEditingEntry",
      selectedEntry: "getSelectedEntry",
      dictionary: "getDicts"
    }),
    categoryGroups() {
      if (this.template.measures) {
        return assembleTemplateCategories(this.template, this.$api);
      }
      return [];
    }
  },
  watch: {
    entry() {
      this.resetEditor();
    }
  },
  methods: {
    resetEditor() {
      this.$refs.fieldsRenderer.forEach(renderer => renderer.reset());
    },
    reset() {
      let measures = this.template.measures,
        base = autoCompleteFields(
          this.isAdding ? { attributes: {} } : clone(this.selectedEntry),
          this.template,
          this.isAdding
        );
      measures.forEach(measure => {
        if (!(measure.dataType === "TABLE" || measure.dataType === "surface")) {
          this.entry.attributes[measure.name] = base.attributes[measure.name];
        }
      });
      this.resetEditor();
    },
    validate() {
      let result = {
        isValid: true,
        invalidFields: []
      };
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          result.invalidFields = result.invalidFields.concat(
            temp.invalidFields
          );
        }
      });
      result.isValid = !result.invalidFields.length;
      return result;
    }
  }
};
</script>
<style scoped>
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>
