<template>
  <div class="curve-editor">
    <div class="curve-options">
      <label><strong>{{$t_("curve_name")}}</strong>:</label>
      <select name="" id="" v-model="currentCurveName">
        <option  v-for="(item,index) in curveOptions" :key="index" :value="item.name">{{item.name}}</option>
      </select>
    </div>
    <div class="curve-box" ref="curve">
    </div>
    <div class="curve-data">
      <div class="row-item title">
        <span class="col-item">{{$t_("term")}}</span><span class="col-item">{{$t_("term_value")}}</span>
      </div>
      <div class="row-item content" v-for="(item,index) in currentCurveData.terms" :key="index" >
        <span class="col-item">{{item}}</span><span class="col-item">{{currentCurveData.termValue[index]}}</span>
      </div>
    </div>
  </div>
</template>

<script>
import echarts from "echarts/dist/echarts.common.min.js";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import {
  clone,
  convertStandardTermToDays,
  convertStandardTermToDate
} from "@/utils";
import {
  DATA_KEYS,
  DATA_TYPES,
  CURVE_YAXIS_DATA_PATTERN,
  CURVE_OPTION_PATTERN,
  RESPONSE_CODE
} from "@/consts";

export default {
  name: "CurveEditor",
  computed: {
    ...mapGetters({
      template: "getEditingTemplate",
      entry: "getEditingEntry",
      marketDate: "getMarketDate"
    })
  },
  watch: {
    currentCurveName(val) {
      this.curveOptions.forEach(item => {
        if (item.name === val) {
          this.currentCurveData = item;
          this.chartInit(this.currentCurveData);
        }
      });
    }
  },
  data() {
    return {
      curveApp: null,
      currentCurveName: "",
      curveOptions: [],
      currentCurveData: { terms: [], name: "", termValue: [] }
    };
  },
  methods: {
    getCurveReference() {
      let referenceNames = [];
      if (this.template.id) {
        this.template.measures.forEach(measure => {
          if (measure.reference) {
            let attributeName = measure.name;
            if (this.entry.attributes[attributeName]) {
              let referenceValue = this.entry.attributes[attributeName].value;
              if (referenceValue) {
                if (measure.list) {
                  referenceValue.forEach((value, index) => {
                    if (
                      value &&
                      value !== "" &&
                      referenceNames.indexOf(value) === -1
                    ) {
                      referenceNames.push(value);
                    }
                  });
                } else {
                  referenceNames.push(referenceValue);
                }
              }
            }
          }
        });
      }
      return referenceNames;
    },
    getCurveData() {
      let availableNames = this.getCurveReference();
      if (availableNames.length) {
        let defaultCondition = {
            searchType: "ID",
            searchValues: availableNames
          },
          requestParameters = productApiHelper.getRequestData(
            defaultCondition,
            null,
            null,
            null,
            null,
            DATA_TYPES.MARKETDATA,
            1
          );
        this.curveOptions = [];
        this.$api
          .request(endpoints.getProductData, requestParameters)
          .then(({ code, data, messages }) => {
            if (code === RESPONSE_CODE.INFO) {
              if (data.records.length) {
                data.records.forEach((item, index) => {
                  if (item.type === DATA_KEYS.CURVE) {
                    let obj = {
                      terms:
                        item.attributes[DATA_KEYS.CURVE_VALUE].value[
                          DATA_KEYS.DIMENSIONS
                        ][0].dimension || [],
                      termValue:
                        item.attributes[DATA_KEYS.CURVE_VALUE].value[
                          DATA_KEYS.SURFACE_VALUE_1D
                        ] || [],
                      name: item.id
                    };
                    this.curveOptions.push(obj);
                  }
                });
                if (this.curveOptions.length) {
                  this.currentCurveName = this.curveOptions[0].name;
                }
              } else {
                this.reset();
              }
            } else {
              this.$emit("message", messages.join(","));
            }
          });
      }
    },
    chartInit(curveItem) {
      if (this.curveApp) {
        this.curveApp.dispose();
        this.curveApp = null;
      }
      let self = this,
        orderedCurveData = {
          group: {},
          terms: [],
          termValues: [],
          name: curveItem.name
        };
      if (curveItem.terms.length) {
        curveItem.terms.forEach((term, index) => {
          orderedCurveData.group[term] = curveItem.termValue[index];
        });
        orderedCurveData.terms = curveItem.terms.sort((a, b) => {
          return convertStandardTermToDays(a) - convertStandardTermToDays(b);
        });
        orderedCurveData.terms.forEach(term => {
          orderedCurveData.termValues.push(orderedCurveData.group[term]);
        });
      }
      this.curveApp = echarts.init(this.$refs.curve);
      var curveAppOption = clone(CURVE_OPTION_PATTERN);
      curveAppOption.xAxis.data = orderedCurveData.terms;
      var yAxisData = clone(CURVE_YAXIS_DATA_PATTERN);
      if (orderedCurveData.terms.length === 1) {
        yAxisData.symbolSize = 5;
        yAxisData.symbol = "circle";
      }
      yAxisData.name = orderedCurveData.name;
      yAxisData.data = orderedCurveData.termValues;
      curveAppOption.series = [];
      curveAppOption.series.push(yAxisData);
      curveAppOption.tooltip.formatter = function(params) {
        return "Date: {0}<br/>Term: {1}<br/>value: {2}".format(
          convertStandardTermToDate(params[0].name, self.marketDate),
          params[0].name,
          params[0].value
        );
      };
      this.curveApp.setOption(curveAppOption);
    },
    resetEditor() {
      this.currentCurveName = "";
      this.curveOptions = [];
      this.currentCurveData = { terms: [], name: "", termValue: [] };
      this.chartInit(this.currentCurveData);
    },
    reset() {},
    show() {
      this.resetEditor();
      this.getCurveData();
    }
  }
};
</script>

<style scoped>
.curve-editor {
  height: 100%;
}
.curve-options {
  height: 29px;
  line-height: 24px;
  padding: 10px 0;
}
.curve-editor .curve-box {
  height: 300px;
  overflow: hidden;
}
.curve-data {
  width: 100%;
  min-height: 270px;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  border-left: 1px solid #cccccc;
}
.curve-data .row-item {
  width: 100%;
  border-bottom: 1px solid #cccccc;
}
.curve-data .row-item .col-item {
  display: inline-block;
  padding: 6px 0;
  width: 50%;
  border-right: 1px solid #cccccc;
  text-align: center;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -o-box-sizing: border-box;
  -ms-box-sizing: border-box;
}
.curve-data .title {
  background-color: #4e586f;
  color: #ffffff;
}
.curve-data .title .col-item {
  height: 30px;
  line-height: 30px;
  padding: 0;
}
.curve-data .content:hover {
  background-color: #e9e7e7;
}
</style>
