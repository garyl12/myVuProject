<template>
 <div style="height:100%;" ref="reportDefineFrame">
   <div style="height:100%;border:1px solid #fff;" ref="reportTop">
    <grid
      :need-index="true"
      :need-pager="true"
      :columns="columns"
      :data="reports.data"
      :page-index="reports.pageIndex"
      :page-count="reports.pageCount"
      @select="selectData"
      @prev-page="retrieveData"
      @next-page="retrieveData"
      @jump-page="retrieveData"
      @sort="retrieveData"
      ref="grid">
      <button-bar
        :padding-right="reports.pageCount>0?140:0"
        :buttons="buttons" />
    </grid>
    <searcher
      :visible="reports.searcherVisible"
      :fields="searchableFields"
      :conditions="reports.searchBy"
      @search="retrieveData"
      @close="reports.searcherVisible=false"
      />
   </div>
    <report-definition-editor
      :visible="editor.isVisible"
      :status="editor.status"
      :available-template-names="availableTemplateNames"
      :editing-entry="editingEntry"
      @close="editor.isVisible = false"
      @save="saveReport"
      />
    <file-downloader
      :src=downloader.src
      :visible="downloader.visible"
      :file-types="fileTypes"
      @select-type="exportReport"
      @close="downloader.visible=false"
      />
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
    <log-alert :logs="logAlert.logs" />
 </div>
</template>

<script>
import endpoints from "@/api/endpoints";
import Grid from "@/components/common/Grid.vue";
import Searcher from "@/components/common/Searcher";
import ButtonBar from "@/components/common/ButtonBar";
import ReportDefinitionEditor from "./ReportDefinitionEditor";
import FileDownloader from "@/components/common/FileDownloader";
import Alert from "@/components/common/Alert";
import LogAlert from "@/components/sections/LogAlert";
import { mapGetters } from "vuex";
import { clone, getViewName, assembleDownloadUrl } from "@/utils";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import mixin from "../../mixin";

import {
  DEFAULT,
  DATA_TYPES,
  PAGE_SIZE,
  RESPONSE_CODE,
  EDITOR_STATUS,
  FILE_TYPES
} from "@/consts";
export default {
  name: "ReportDefinition",
  components: {
    Grid,
    Searcher,
    ButtonBar,
    ReportDefinitionEditor,
    FileDownloader,
    Alert,
    LogAlert
  },
  mixins: [mixin],
  data() {
    return {
      alert: {
        visible: false,
        title: "error",
        message: "",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      logAlert: { logs: [] },
      removeConfirmation: {
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeCurrentReport();
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ],
        visible: false
      },
      downloader: {
        src: "",
        visible: false
      },
      editor: {
        status: 0,
        isVisible: false
      },
      editingEntry: null,
      reports: {
        data: [],
        selectedItem: {},
        selectedIndex: -1,
        pageCount: 0,
        pageIndex: -1,
        searchBy: null,
        sortBy: null,
        requestCondition: null,
        searcherVisible: false
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      dicts: "getDicts",
      currentNav: "getCurrentNav",
      mapping: "getMapping",
      attributes: "getAttributes"
    }),
    availableTemplateNames() {
      return (this.currentNav.templateFilter || "").split(";");
    },
    needConfidenceLevel() {
      if (this.this.reports.selectedItem) {
        let defType = this.reports.selectedItem.attributes["Report Def Type"]
          .value;
        return (
          defType === "HISTORICAL_VAR_REPORT_DEF" ||
          defType === "MONTE_CARLO_VAR_REPORT_DEF"
        );
      } else {
        return false;
      }
    },
    searchableFields() {
      let availableTemplates = [],
        detectedFieldNameMapping = {},
        searchableFields = [];
      if (this.currentNav.templateFilter) {
        availableTemplates = this.currentNav.templateFilter
          .split(";")
          .map(item => {
            return item.replace(/ /g, "_").toUpperCase();
          });
      }
      availableTemplates.forEach(templateName => {
        if (this.templates[templateName]) {
          this.templates[templateName].measures.forEach(field => {
            if (field.searchAble && !detectedFieldNameMapping[field.name]) {
              searchableFields.push(field);
              detectedFieldNameMapping[field.name] = true;
            }
          });
        }
      });
      return searchableFields;
    },
    viewName() {
      let viewName = null;
      if (DEFAULT in this.views) {
        viewName = getViewName(this.currentNav.id, this.mapping, this.views);
      }
      return viewName || DEFAULT;
    },
    columns() {
      let columns = [];
      if (DEFAULT in this.views) {
        let columnNames = this.views[
          this.viewName
        ][0].attributesInMainGrid.split(";");
        columnNames.forEach(columnName => {
          if (this.attributes[columnName]) {
            columns.push(this.attributes[columnName]);
          } else {
            columns.push({
              displayName: columnName,
              attributeName: columnName
            });
          }
        });
      }
      return columns;
    },
    baseCondition() {
      return {
        searchValues: (this.currentNav.dataFilter || "").split(";"),
        attributeName: "Template Name"
      };
    },
    fileTypes() {
      return FILE_TYPES;
    },
    buttons() {
      return [
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.reports.searcherVisible = true;
          }
        },
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.editor.isVisible = true;
            this.editor.status = EDITOR_STATUS.ADDING;
            this.setEntry();
          }
        },
        {
          icon: "icon-bianji",
          active: this.reports.selectedIndex !== -1,
          text: "edit",
          callback: () => {
            this.editor.status = EDITOR_STATUS.EDITING;
            this.setEntry();
            this.editor.isVisible = true;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.reports.selectedIndex !== -1,
          text: "remove",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.reports.selectedIndex !== -1,
          text: "clone",
          callback: () => {
            this.editor.status = EDITOR_STATUS.CLONING;
            this.editingEntry = clone(this.reports.selectedItem);
            this.editor.isVisible = true;
          }
        },
        {
          icon: "icon-jisuanqi",
          active: this.reports.selectedIndex !== -1,
          text: "calculate",
          callback: () => {
            this.calculateDetail();
          }
        },
        {
          icon: "icon-chakan1",
          active: this.reports.selectedIndex !== -1,
          text: "view",
          callback: () => {
            this.jumpToDetail();
          }
        },
        {
          icon: "icon-daochu",
          active: this.reports.pageCount > 0,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    }
  },
  watch: {
    currentNav() {
      this.loadGridData();
    }
  },
  mounted() {
    this.loadGridData();
  },
  methods: {
    loadGridData() {
      if (this.cache[this.$route.path]) {
        this.reports = JSON.parse(this.cache[this.$route.path]);
      } else {
        this.reports.data = [];
        this.reports.sortBy = null;
        this.reports.searchBy = null;
        this.reports.pageIndex = 1;
        let requestParameters = productApiHelper.getRequestData(
          null,
          [this.baseCondition],
          null,
          null,
          null,
          DATA_TYPES.SCENARIO,
          1
        );
        this.requestData(requestParameters);
      }
    },
    requestData(requestParameters) {
      this.reports.requestCondition = requestParameters;
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.reports.data = data.records;
            if (data.records.length) {
              this.reports.pageCount = Math.ceil(
                data.recordCount / data.pageSize
              );
              this.$refs.grid.selectDefault();
              this.reports.searcherVisible = false;
            } else {
              this.reports.pageCount = 0;
              this.reports.selectedIndex = -1;
            }
          } else {
            this.alert.message = "";
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        });
    },
    calculateDetail() {
      let template = this.templates[this.reports.selectedItem.templateName];
      let requestData = processApiHelper.getCalculateRequestData(
        this.reports.selectedItem,
        template,
        DATA_TYPES.REPORT
      );
      return this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, data, messages }) => {
          this.logAlert.logs = messages;
        });
    },
    setEntry() {
      this.editingEntry =
        this.editor.status === EDITOR_STATUS.ADDING
          ? null
          : clone(this.reports.selectedItem);
    },
    retrieveData({ sortBy, searchBy, pageIndex = 1 }) {
      if (sortBy) this.reports.sortBy = sortBy;
      if (searchBy) this.reports.searchBy = searchBy;
      this.reports.pageIndex = pageIndex;
      let requestParameters = productApiHelper.getRequestData(
        null,
        [this.baseCondition],
        this.reports.searchBy,
        this.reports.sortBy,
        null,
        DATA_TYPES.SCENARIO,
        pageIndex
      );

      this.requestData(requestParameters);
    },
    exportReport(type) {
      let requestParameter = clone(this.reports.requestCondition);
      requestParameter.queryResultAction = "DOWNLOAD";
      requestParameter.outputFormat = type;
      this.$api.request(endpoints.getProductData, requestParameter).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    },
    jumpToDetail() {
      let item = this.reports.selectedItem,
        query = {
          name: item.name,
          temp: item.templateName,
          groupBy: (item.attributes["Group By"] || {}).value,
          defType: (item.attributes["Report Def Type"] || {}).value,
          level: (item.attributes["Confidence Level"] || {}).value
        };
      this.$router.push({
        path: "/reportdetail/" + item.id,
        query
      });
    },
    selectData({ currentItem, index }) {
      this.reports.selectedItem = currentItem;
      this.reports.selectedIndex = index;
    },
    removeCurrentReport() {
      let template = this.templates[this.reports.selectedItem.templateName],
        requestData = processApiHelper.getDeleteRequestData(
          this.reports.selectedItem,
          template,
          DATA_TYPES.REPORT
        );
      this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.reports.data.splice(this.reports.selectedIndex, 1);
            this.reports.selectedItem = null;
            this.reports.selectedIndex = -1;
          } else {
            this.alert.title = code;
            this.alert.visible = true;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    saveReport(report) {
      if (this.editor.status === EDITOR_STATUS.EDITING) {
        this.reports.data.splice(this.reports.selectedIndex, 1, report);
        this.$set(report, "_selected", true);
        this.reports.selectedItem = report;
      } else {
        this.reports.data.unshift(report);
        this.$refs.grid.selectDefault();
        if (this.reports.pageCount) this.reports.pageCount = 1;
      }
      this.editor.isVisible = false;
    },
    resize() {
      this.$refs.grid.resize();
    },
    getCacheData() {
      return this.reports;
    }
  }
};
</script>
