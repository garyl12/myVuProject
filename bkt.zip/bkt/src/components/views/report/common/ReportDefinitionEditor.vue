<template>
  <el-dialog class="editor" top="60px"
    :title="$t_(title)" 
    :visible="visible"  
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false">
    <div class="template-selector" v-show="isAdding">
      <label>{{$t_("select_template")}}</label>
      <label>:</label>
      <select v-model="templateName">
        <option v-for="(item,index) in availableTemplateNames" :key="index" :value="item">{{item}}</option>
      </select>
    </div>
    <div class="main-editor">
      <editor-logger :logs="logs" />      
      <div >
        <div class="group" v-for="(group,index) in categoryGroup" :key="index">
          <div class="section">
            <span class="category-title">{{$t_(group.groupName)}}</span>
          </div>
          <fields-renderer
            :fields="group.fields"
            :entry="entry"
            :adding="isAdding"
            ref="fieldsRenderer"
            />
        </div>
      </div>
     </div>
    <div slot="footer" class="dialog-footer">
      <el-button  @click="save">{{$t_("save")}}</el-button>
      <el-button  @click="resetEntry">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
    </div>
    <alert :config="alert" />
  </el-dialog>
</template>

<script>
import EditorLogger from "@/components/sections/EditorLogger";
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import Alert from "@/components/common/Alert";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints.js";
import { autoCompleteFields, getEditorTitle, clone } from "@/utils";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import { mapGetters } from "vuex";
import { RESPONSE_CODE, EDITOR_STATUS, DATA_TYPES } from "@/consts";
export default {
  name: "ReportDefinitionEditor",
  components: {
    FieldsRenderer,
    EditorLogger,
    Alert
  },
  props: {
    visible: {
      type: Boolean,
      required: true
    },
    status: {
      type: Number,
      required: true
    },
    availableTemplateNames: {
      type: Array,
      required: true
    },
    editingEntry: {
      type: Object
    }
  },
  data() {
    return {
      logs: [],
      entry: null,
      template: null,
      templateName: "",
      validationMap: {},
      alert: {
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      currentNav: "getCurrentNav"
    }),
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    },
    categoryGroup() {
      if (this.template) {
        return assembleTemplateCategories(this.template, this.$api);
      }
      return [];
    },
    baseConditions() {
      return [
        {
          attributeName: "ID",
          operator: "EQUAL",
          searchType: "CUSTOMIZED",
          searchValues: this.entry.attributes
            ? [this.entry.attributes["ID"].value]
            : [],
          valueType: "STRING"
        },
        {
          attributeName: "Template Name",
          operator: "EQUAL",
          searchType: "CUSTOMIZED",
          searchValues: (this.currentNav.dataFilter || "").split(";"),
          valueType: "STRING"
        }
      ];
    }
  },
  watch: {
    editingEntry(val) {
      if (val) {
        this.resetEntry();
      }
    },
    templateName(val) {
      let templateKey = val.toUpperCase().replace(/[ ]/g, "_");
      this.template = this.templates[templateKey];
      this.resetEntry();
    },
    visible(val) {
      if (val) {
        this.templateName = this.isAdding
          ? this.availableTemplateNames[0]
          : this.editingEntry.templateName;
      } else {
        this.templateName='';
      }
    }
  },
  methods: {
    resetEditor() {
      this.$refs.fieldsRenderer.forEach(renderer => renderer.reset());
      this.logs = [];
    },
    close() {
      this.$emit("close");
      this.resetEditor();
    },
    save() {
      if (!this.validate()) return;
      if (this.isAdding)
        this.entry.attributes["ID"].value = this.entry.attributes[
          "Report Def ID"
        ].value;
      this.validateID().then(() => {
        let requestData = processApiHelper.getUpdateRequestData(
          this.entry,
          this.template,
          DATA_TYPES.REPORT
        );
        this.$api
          .request(endpoints.processProduct, requestData)
          .then(({ code, data, messages }) => {
            this.logs = messages;
            if (code === RESPONSE_CODE.INFO) {
              this.$emit("save", data[0]);
            }
          });
      });
    },
    resetEntry() {
      if (this.template) {
        if (this.status === EDITOR_STATUS.ADDING) {
          this.entry = autoCompleteFields(
            { attributes: {} },
            this.template,
            true
          );
        }
        if (this.status === EDITOR_STATUS.EDITING) {
          this.entry = autoCompleteFields(
            clone(this.editingEntry),
            this.template,
            false
          );
        }
        if (this.status === EDITOR_STATUS.CLONING) {
          this.entry = autoCompleteFields(
            clone(this.editingEntry),
            this.template,
            true
          );
          this.entry.attributes["ID"].value = "";
        }
      }
    },
    validate() {
      let invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    validateID() {
      if (this.isAdding) {
        let requestData = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.REPORT
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert.visible = true;
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    }
  }
};
</script>

<style scoped>
.template-selector {
  padding: 0 10px;
  background-color: rgb(152, 164, 197);
  height: 30px;
  line-height: 30px;
}
.template-selector label {
  padding-right: 3px;
}
.main-editor {
  height: calc(100% - 50px);
  height: -ms-calc(100% - 50px);
  height: -moz-calc(100% - 50px);
  height: -webkit-calc(100% - 50px);
  margin: 0 20px;
  padding: 0 10px;
  border: 1px solid #cccccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.editor-title {
  margin: 0 10px;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>