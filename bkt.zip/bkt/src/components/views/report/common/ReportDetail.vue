<template>
  <div style="height:100%">
    <advanced-tree-grid
      :columns="columns"
      :data="rootData"
      :dataLoader="dataLoader"
      childAttribute="children"
      ref="grid"
      >
    <div class="info clearfix">
      <div><span>{{$t_('ID')+' : '}}</span><span>{{$route.params.id}}</span></div>
      <div><span>{{$t_('Name')+' : '}}</span><span>{{$route.query.name}}</span></div>
      <div class="field-box" >
        <span>{{$t_('group_by')+' : '}}</span>
        <select class="selector" :value="groupBy" v-model="groupBy">
          <option  v-for="(item,index) in groupByOptions" :key="index" :value="item.value" >{{item.label}}</option>
        </select>
      </div>
      <div class="field-box" v-show="confidenceLevel">
        <span>{{$t_('confidence_level')+' : '}}</span>
        <select class="selector" :value="confidenceLevel" v-model="confidenceLevel">
          <option  v-for="(item,index) in confidenceLevelOptions" :key="index" :value="item.value" >{{item.label}}</option>
        </select>
      </div>
      <div class="field-box">
        <span>{{$t_('report_date')+' : '}}</span>
        <div class="date-picker"><el-date-picker v-model="selectedDate" value-format="yyyy-MM-dd" /></div>
      </div>
      <div  class="button-box">
        <span class="btn btn-dark" @click="refreshReportData">{{$t_('refresh')}}</span>
      </div>
    </div>
    </advanced-tree-grid>
    <log-alert :logs="logAlert.logs" />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import AdvancedTreeGrid from "@/components/common/advancedGrid/AdvancedTreeGrid";
import DisplayField from "@/components/fields/DisplayField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import DateField from "@/components/fields/DateUIField.vue";
import ButtonBar from "@/components/common/ButtonBar";
import Alert from "@/components/common/Alert";
import LogAlert from "@/components/sections/LogAlert";
import { DATA_TYPES, RESPONSE_CODE, REPORT_UNIT_TYPE } from "@/consts";
import { clone, parseToDate, merge } from "@/utils";
import productApiHelper from "@/utils/productApiHelper";
import mixin from "../../mixin";

export default {
  name: "ReportDetail",
  components: {
    AdvancedTreeGrid,
    ButtonBar,
    DisplayField,
    DropdownlistField,
    DateField,
    Alert,
    LogAlert
  },
  mixins: [mixin],
  computed: {
    ...mapGetters({
      views: "getViews",
      attributes: "getAttributes",
      dictionary: "getDicts",
      user: "getUser",
      marketDate: "getMarketDate"
    }),
    templateName() {
      return REPORT_UNIT_TYPE[this.$route.query.temp];
    },
    view() {
      return this.views[this.templateName];
    },
    groupByOptions() {
      return (
        (this.dictionary["Report Group By Type"] || { childs: [] }).childs || []
      );
    },
    confidenceLevelOptions() {
      return (
        (this.dictionary["Confidence Level"] || { childs: [] }).childs || []
      );
    },
    columns() {
      let columns = [];
      if (this.view) {
        this.needAssemble = false;
        let columnObj = {};
        this.view.forEach(element => {
          if (!element.isRepeated) {
            if (element.groupName) {
              columnObj[element.groupName] = {
                columns: element.attributesInMainGrid,
                keyColumns: element.keyMeasuresName
              };
            } else {
              // should only have one element with its groupName 'null'
              element.attributesInMainGrid.split(";").forEach(col => {
                if (this.attributes[col]) {
                  columns.push(this.attributes[col]);
                } else {
                  columns.push({
                    displayName: col,
                    attributeName: col
                  });
                }
              });
            }
          }
        });
        columns.forEach(col => {
          if (columnObj[col.attributeName]) {
            col.keyColumns = columnObj[col.attributeName].keyColumns.split(";");
            col.columns = [];
            columnObj[col.attributeName].columns.split(";").forEach(subCol => {
              if (this.attributes[subCol]) {
                col.columns.push(this.attributes[subCol]);
              } else {
                col.columns.push({
                  displayName: subCol,
                  attributeName: subCol
                });
              }
            });
          }
        });
        if (this.rootData.length && this.attributes["Scenario Value"]) {
          this.view.forEach(element => {
            if (element.isRepeated) {
              this.needAssemble = true;
              let dataKey = element.groupName.replace(/\[|\]/g, ""),
                liveNames = element.attributesInMainGrid.split(";"),
                records = this.rootData[0].attributes["PL Records"].value || [],
                groupNames = records.map(
                  record => record.attributes["Scenario ID"].value
                );
              groupNames.forEach(groupName => {
                let keyColumn = groupName + "." + element.keyMeasuresName,
                  liveItem = {
                    attributeName: groupName,
                    displayName: groupName,
                    columns: [],
                    keyColumns: [keyColumn]
                  };
                liveNames.forEach(name => {
                  let measure = clone(this.attributes[name]);
                  measure.attributeName =
                    groupName + "." + measure.attributeName;

                  liveItem.columns.push(measure);
                });
                columns.push(liveItem);
              });
            }
          });
        }
      }
      return columns;
    },
    defaultDate() {
      let date = null;
      if (this.marketDate) {
        date = parseToDate(this.marketDate.getTime());
      }
      return date;
    },
    requestParam() {
      return {
        "Report Def ID": this.$route.params.id,
        "Group By": this.groupBy,
        "Report Def Type": this.$route.query.temp,
        "Report Date": this.selectedDate,
        "Confidence Level": this.confidenceLevel
      };
    }
  },
  watch: {
    $route() {
      //worked when switch reportDetailTab
      this.queryReportData();
    }
  },
  mounted() {
    this.queryReportData();
  },
  data() {
    return {
      rootData: [],
      selectedDate: null,
      confidenceLevel: null,
      groupBy: "",
      logAlert: { logs: [] }
    };
  },
  methods: {
    queryReportData(trigger) {
      this.$nextTick(() => {
        this.reset();
        if (this.cache[this.$route.path]) {
          this.rootData = JSON.parse(this.cache[this.$route.path]);
        } else {
          this.requestData().then(({ code, data, messages }) => {
            let needAssemble = this.view.some(item => item.isRepeated);
            if (needAssemble && data.records) {
              this.rootData = this.assembleData(data.records);
            } else {
              this.rootData = data.records || [];
            }
            if (code === RESPONSE_CODE.ERROR) {
              this.logAlert.logs = messages;
            }
          });
        }
      });
    },
    refreshReportData() {
      this.$api
        .request(endpoints.refreshReportData, this.requestParam)
        .then(({ code, data, messages }) => {
          let needAssemble = this.view.some(item => item.isRepeated);
          if (needAssemble && data) {
            this.rootData = this.assembleData(data);
          } else {
            this.rootData = data || [];
          }
          if (code === RESPONSE_CODE.ERROR) {
            this.logAlert.logs = messages;
          }
        });
    },
    dataLoader(parent) {
      let parentId = parent ? parent.id : "0";
      return this.requestData(parentId).then(
        ({ data }) => {
          let newData = [];
          if (this.needAssemble && data.records) {
            newData = this.assembleData(data.records);
          } else {
            newData = data.records;
          }
          return Promise.resolve(newData);
        },
        () => {
          return Promise.resolve([]);
        }
      );
    },
    assembleData(data) {
      let newData = clone(data);
      newData.forEach(record => {
        record.attributes["PL Records"].value.forEach(plRecord => {
          let scenario = clone(plRecord);
          this.view.forEach(item => {
            if (item.isRepeated) {
              let obj = {};
              item.attributesInMainGrid.split(";").forEach(attributeName => {
                let dataKey = item.groupName.replace(/\[|\]/g, ""),
                  key =
                    scenario.attributes[dataKey].value + "." + attributeName;
                obj[key] = {
                  value: (scenario.attributes[attributeName] || { value: "" })
                    .value
                };
              });
              merge(scenario.attributes, obj, true);
              merge(record.attributes, scenario.attributes, true);
            }
          });
        });
      });
      return newData;
    },
    requestData(pId) {
      let id = this.$route.params.id;
      let baseConditions = [
          {
            searchValues: [this.templateName],
            attributeName: "Template Name"
          },
          {
            searchValues: [id],
            attributeName: "Report Def ID"
          },
          {
            searchValues: pId ? [pId] : ["0"],
            attributeName: "Parent ID"
          },
          {
            searchValues: [this.user.userNo],
            attributeName: "Owner ID"
          }
        ],
        requestParameters = productApiHelper.getRequestData(
          null,
          baseConditions,
          null,
          null,
          null,
          DATA_TYPES.REPORT_UNIT,
          1
        );
      return this.$api.request(endpoints.getProductData, requestParameters);
    },
    reset() {
      this.groupBy = this.$route.query.groupBy;
      this.selectedDate = this.defaultDate;
      this.confidenceLevel = this.$route.query.level;
    },
    resize() {
      this.$refs.grid.resize();
    },
    getCacheData() {
      return this.rootData;
    }
  }
};
</script>

<style scoped>
.info {
  margin: 6px 0;
  height: 24px;
  line-height: 24px;
}
.info > div {
  float: left;
  margin: 0 10px;
}
.picker {
  width: 80px;
  height: 24px;
  outline: 0;
  border-radius: 4px;
  border: 1px solid #bfcbd9;
}
.picker:hover {
  outline: 0;
  border-color: #8391a5;
}
.picker:focus {
  outline: 0;
  border-color: #20a0ff;
}
.date-picker {
  display: inline-block;
  width: 100px;
}
.info > div.button-box {
  float: right;
}
</style>