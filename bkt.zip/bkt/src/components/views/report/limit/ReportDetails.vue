<template>
  <div style="height: 100%">
    <grid
      :columns="columns"
      :data="data"
      :need-pager="true"
      >
      <div class="title">
        <div class="field"><display-field :field-name="$t_('portfolio_id')" :field-val="$route.query.portfolioId" /></div>
        <div class="field"><display-field :field-name="$t_('group_by')" :field-val="$route.query.groupBy" /></div>
        <div class="field"><display-field :field-name="$t_('test')" :field-val="$route.query.groupBy" /></div>
        <div class="field"><display-field :field-name="$t_('analysis_currency')" :field-val="$route.query.ac" /></div>
        <div class="field"><display-field :field-name="$t_('limit_calculate_type')" :field-val="$route.query.lct" /></div>
      </div>
    </grid>
    <log-alert :logs="logs"/>
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import LogAlert from "@/components/sections/LogAlert";
import DisplayField from "@/components/fields/DisplayField";
import { mapGetters } from "vuex";
import { clone, parseToDate } from "@/utils";
import { RESPONSE_CODE } from "@/consts";
import endpoints from "@/api/endpoints";
import mixin from "../../mixin";

export default {
  name: "LimitReportDetail",
  components: { Grid, DisplayField, LogAlert },
  mixins: [mixin],
  data() {
    return {
      data: [],
      logs: []
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      views: "getViews",
      currentNav: "getCurrentNav",
      marketDate: "getMarketDate"
    }),
    viewColumnMap() {
      let map = {};
      if (this.views["LIMIT_REPORT_UNIT"]) {
        (this.views["LIMIT_REPORT_UNIT"][0].attributesInMainGrid || "")
          .split(";")
          .forEach(c => (map[c] = true));
      }
      return map;
    },
    template() {
      return this.templates["LIMIT_REPORT_UNIT"];
    },
    columns() {
      let columns = [];
      if (this.template) {
        this.template.measures.forEach(measure => {
          if (this.viewColumnMap[measure.attributeName]) {
            columns.push(measure);
          }
        });
      }
      return columns;
    },
    reportDate() {
      let date = "";
      if (this.marketDate) {
        date = parseToDate(this.marketDate.getTime());
      }
      return date;
    },
    requestData() {
      return {
        "Report Def ID": this.$route.params.id,
        "Group By": this.$route.query.groupBy,
        "Report Def Type": "LIMIT_REPORT_DEF",
        "Report Date": this.reportDate
      };
    }
  },
  watch: {
    $route() {
      this.loadFrame();
    }
  },
  mounted() {
    this.loadFrame();
  },
  methods: {
    loadFrame() {
      if (this.cache[this.$route.path]) {
        this.data = JSON.parse(this.cache[this.$route.path]);
      }
      if (!this.data.length) {
        this.loadData().then(({ data, code, messages }) => {
          this.logs = messages;
          this.data = data || [];
        });
      }
    },
    loadData() {
      return this.$api.request(endpoints.refreshReportData, this.requestData);
    },
    getCacheData() {
      return this.data;
    }
  }
};
</script>

<style scoped>
.title {
  height: 36px;
  padding: 6px 0;
  line-height: 22px;
  margin-right: 150px;
}
.field {
  float: left;
  width: 20%;
  min-width: 180px;
}
</style>