<template>
   <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="logger">
      <editor-logger :logs="logs" />
    </div>
    <div class="editor-inner">
      <fields-renderer
        :fields="fields"
        :entry="entry"
        :is-data-bean="true"
        :adding="isAdding"
        ref="fieldsRenderer"
        />
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
	  </div>
  </el-dialog>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import {
  generateTreeSelectorOption,
  generateReferenceSelectorOption
} from "@/components/sections/FieldsRenderer";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import {
  clone,
  getEditorTitle,
  parseEntityTableFieldValueToBean,
  parseBeanToEntityTableFieldValue
} from "@/utils";
import {
  EDITOR_STATUS,
  RESPONSE_CODE,
  DATA_TYPES,
  REFERENCE_FIELD_TYPE
} from "@/consts";

export default {
  name: "LimitReportDefDetailsEditor",
  components: { FieldsRenderer, EditorLogger },
  props: {
    visible: {
      required: true,
      type: Boolean
    },
    status: {
      required: true,
      type: Number
    },
    detailIndex: {
      required: true,
      type: Number
    }
  },
  data() {
    return {
      logs: [],
      entry: {},
      fields: []
    };
  },
  computed: {
    ...mapGetters({
      selectedEntry: "getSelectedEntry",
      templates: "getTemplates",
      dictionary: "getDicts"
    }),
    template() {
      return this.templates["LIMIT_REPORT_DEF"];
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    }
  },
  watch: {
    visible() {
      if (this.visible) {
        this.reset();
        this.setFields();
      }
    }
  },
  methods: {
    validate() {
      let result = this.$refs.fieldsRenderer.validate();
      if (result.isValid) {
        this.logs = [];
      } else {
        this.logs = [
          {
            msg:
              this.$t_("field_invalid_message") +
              result.invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      }
      return result.isValid;
    },
    save() {
      if (this.validate()) {
        // merge current entry to report definition
        let reportDef = clone(this.selectedEntry);
        let reportDetail = parseBeanToEntityTableFieldValue(this.entry);
        if (this.isAdding) {
          reportDef.attributes["Limit Detail Def"].value.push(reportDetail);
        } else {
          reportDef.attributes["Limit Detail Def"].value.splice(
            this.detailIndex,
            1,
            reportDetail
          );
        }
        this.sendRequest(reportDef).then(record => {
          let event =
            this.status === EDITOR_STATUS.ADDING
              ? "add"
              : this.status === EDITOR_STATUS.EDITING ? "edit" : "clone";
          this.$emit(event, record);
        });
      }
    },
    sendRequest(entry) {
      let requestData = processApiHelper.getUpdateRequestData(
        entry,
        this.template,
        DATA_TYPES.REPORT
      );
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data[0]);
          } else {
            return Promise.reject();
          }
        },
        _ => {
          return Promise.reject();
        }
      );
    },
    reset() {
      this.logs = [];
      if (this.status === EDITOR_STATUS.ADDING) {
        this.entry = {};
      } else {
        let detail = this.selectedEntry.attributes["Limit Detail Def"].value[
          this.detailIndex
        ];
        this.entry = parseEntityTableFieldValueToBean(clone(detail));
      }
    },
    setFields() {
      this.fields = [];
      let subMeasures = [],
        fields = [];
      if (this.template) {
        this.template.measures.some(measure => {
          if (measure.name === "Limit Detail Def") {
            subMeasures = measure.subMeasures;
            return true;
          }
        });
        subMeasures.forEach(measure => {
          let field = clone(measure);
          if (field.reference) {
            field.options = generateReferenceSelectorOption(field, this.$api);
          }
          if (field.name === "Limit Object ID") {
            this.setLimitObjectIdFieldOptions(field);
          }
          fields.push(field);
        });
      }
      this.fields = fields;
    },
    setLimitObjectIdFieldOptions(field) {
      let parentPortfolioId = this.selectedEntry.attributes["Portfolio ID"]
        .value;
      let groupBy = this.selectedEntry.attributes["Group By"].value;
      field.options = null;
      if (groupBy === "Portfolio") {
        this.setAsPortfolioField(field, parentPortfolioId);
      } else if (groupBy === "Counter Party") {
        this.setAsCounterPartyField(field);
      } else {
        field.reference = false;
        field.type = null;
        field.options = ((this.dictionary[groupBy] || {}).childs || []).map(
          item => {
            return {
              logicVal: item.value,
              displayVal: item.label
            };
          }
        );
      }
    },
    setAsPortfolioField(field, parentPortfolioId) {
      field.reference = true;
      field.type = REFERENCE_FIELD_TYPE.TREE;
      field.options = generateTreeSelectorOption(
        field,
        this.$api,
        parentPortfolioId
      );
    },
    setAsCounterPartyField(field) {
      field.reference = true;
      field.type = REFERENCE_FIELD_TYPE.TABLE;
      field.options = {
        refAttribute: "ID",
        columns: [
          {
            attributeName: "ID",
            displayName: "ID",
            width: 100
          },
          {
            attributeName: "Full CN Name",
            displayName: "Full CN Name",
            width: 100
          },
          {
            attributeName: "Full EN Name",
            displayName: "Full EN Name",
            width: 100
          }
        ],
        resolver(pageIndex, searchingCondition) {
          let searchBy = [];
          let dataType = DATA_TYPES.LEGALENTITY;
          for (let key in searchingCondition) {
            let searchObj = {
              value: searchingCondition[key],
              valueType: FIELD_TYPES.STRING,
              key
            };
            searchBy.push(searchObj);
          }
          let requestParameters = productApiHelper.getRequestData(
            { searchType: "TYPE", searchValues: ["Legal Entity"] },
            null,
            searchBy,
            null,
            null,
            dataType,
            pageIndex,
            10
          );
          return this.$api
            .request(endpoints.getProductData, requestParameters)
            .then(
              ({ code, data }) => {
                if (code === RESPONSE_CODE.INFO) {
                  let pageCount = Math.ceil(data.recordCount / 10);
                  let refs = data.records.map(res => {
                    let data = {};
                    for (let attr in res.attributes) {
                      data[attr] = res.attributes[attr].value;
                    }
                    return data;
                  });
                  return Promise.resolve({ data: refs, pageCount });
                }
              },
              () => {
                return Promise.resolve({ data: [], pageCount: 0 });
              }
            );
        }
      };
    },
    close() {
      this.reset();
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.logger {
  margin: 0 20px;
}
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  margin-top: 30px;
  height: calc(100% - 50px);
  border: 1px solid #ccc;
}
</style>