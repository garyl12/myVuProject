<template>
  <div style="height: 100%" ref="frame">
    <div class="report-main" ref="left">
      <grid
        :need-pager="true"
        :columns="reportDefColumns"
        :data="reportDefs.data"
        :page-index="reportDefs.pageIndex"
        :page-count="reportDefs.pageCount"
        @select="selectDef"
        @sort="loadDefsPaginal"
        @prev-page="loadDefsPaginal"
        @next-page="loadDefsPaginal"
        ref="reportDefsGrid">
        <button-bar
          :buttons="reportDefsButtons"
          />
      </grid>
      <report-definition-editor
        :visible="defEditor.visible"
        :status="defEditor.status"
        @add="postAddDef"
        @edit="postEditDef"
        @clone="postAddDef"
        @close="defEditor.visible=false"
        />
    </div>
    <resizer axis="x" @resize="resizeX" />
    <div class="report-detail" ref="right">
      <grid
        :need-pager="true"
        :columns="reportDetailColumns"
        :data="reportDefDetails.data"
        @select="selectDetail"
        ref="reportDetailsGrid">
        <button-bar
          :buttons="reportDetailsButtons"
          />
      </grid>
      <report-def-details-editor
        :visible="detailEditor.visible"
        :status="detailEditor.status"
        :detail-index="reportDefDetails.selectedItemIndex"
        @add="postAddDetail"
        @edit="postEditDetail"
        @clone="postAddDetail"
        @close="detailEditor.visible=false"
        />
    </div>
    <alert :config="confirmation" />
    <alert :config="alert" />
    <log-alert :logs="logAlert.logs" />
  </div>
</template>

<script>
import Resizer from "@/components/common/Resizer";
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Alert from "@/components/common/Alert";
import LogAlert from "@/components/sections/LogAlert";
import ReportDefinitionEditor from "./ReportDefinitionEditor";
import ReportDefDetailsEditor from "./ReportDefDetailsEditor";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints";
import mixin from "../../mixin";
import { clone, parseEntityTableFieldValueToEntity, getColumns } from "@/utils";
import {
  EDITOR_STATUS,
  PAGE_SIZE,
  DATA_TYPES,
  SIZE,
  RESPONSE_CODE
} from "@/consts";
import { mapGetters } from "vuex";

export default {
  name: "LimitReportDefinition",
  components: {
    Resizer,
    Grid,
    ButtonBar,
    Alert,
    LogAlert,
    ReportDefinitionEditor,
    ReportDefDetailsEditor
  },
  mixins: [mixin],
  data() {
    return {
      reportDefs: {
        data: [],
        pageIndex: 1,
        pageCount: -1,
        selectedItemIndex: -1,
        selectedItem: null,
        searchBy: null,
        sortBy: null
      },
      defEditor: {
        visible: false,
        status: -1
      },
      reportDefDetails: {
        data: [],
        selectedItemIndex: -1,
        selectedItem: null
      },
      detailEditor: {
        visible: false,
        status: -1
      },
      confirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback() {}
          },
          {
            title: "cancel",
            callback: () => {
              this.confirmation.visible = false;
            }
          }
        ]
      },
      alert: {
        visible: false,
        title: "error",
        message: "",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      logAlert: { logs: [] }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      attributes: "getAttributes"
    }),
    reportDefColumns() {
      let columns = [];
      if (this.views["LIMIT_MANAGEMENT"]) {
        columns = getColumns(
          this.views["LIMIT_MANAGEMENT"],
          "LIMIT_REPORT_DEF_GROUP",
          this.attributes
        );
      }
      return columns;
    },
    reportDefsButtons() {
      return [
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.defEditor.visible = true;
            this.defEditor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "edit",
          callback: () => {
            this.defEditor.visible = true;
            this.defEditor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "clone",
          callback: () => {
            this.defEditor.visible = true;
            this.defEditor.status = EDITOR_STATUS.CLONING;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "delete",
          callback: () => {
            this.confirmation.buttons[0].callback = () => {
              this.doRemoveRef();
              this.confirmation.visible = false;
            };
            this.confirmation.visible = true;
          }
        },
        {
          icon: "icon-jisuanqi",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "calculate",
          callback: () => {
            this.calculateReport();
          }
        },
        {
          icon: "icon-chakan1",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "view",
          callback: () => {
            this.gotoReportDetails();
          }
        }
      ];
    },
    reportDetailColumns() {
      let columns = [];
      if (this.views["LIMIT_MANAGEMENT"]) {
        columns = getColumns(
          this.views["LIMIT_MANAGEMENT"],
          "LIMIT_REPORT_DETAIL_DEF_GROUP",
          this.attributes
        );
      }
      return columns;
    },
    reportDetailsButtons() {
      return [
        {
          icon: "icon-xinjian",
          active: this.reportDefs.selectedItemIndex > -1,
          text: "add",
          callback: () => {
            this.detailEditor.visible = true;
            this.detailEditor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active: this.reportDefDetails.selectedItemIndex > -1,
          text: "edit",
          callback: () => {
            this.detailEditor.visible = true;
            this.detailEditor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.reportDefDetails.selectedItemIndex > -1,
          text: "clone",
          callback: () => {
            this.detailEditor.visible = true;
            this.detailEditor.status = EDITOR_STATUS.CLONING;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.reportDefDetails.selectedItemIndex > -1,
          text: "delete",
          callback: () => {
            this.confirmation.buttons[0].callback = () => {
              this.doRemoveRefDetail();
              this.confirmation.visible = false;
            };
            this.confirmation.visible = true;
          }
        }
      ];
    },
    template() {
      return this.templates["LIMIT_REPORT_DEF"];
    },
    reportDefBaseCondition() {
      return {
        attributeName: "Template Name",
        searchValues: ["LIMIT_REPORT_DEF"]
      };
    }
  },
  watch: {
    "reportDefs.selectedItem": function(entry) {
      this.$store.commit("setSelectedEntry", entry);
      this.getReportDefDetailsData();
    }
  },
  mounted() {
    this.loadFrame();
  },
  methods: {
    loadFrame() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.reportDefs = cacheData.reportDefs;
        this.reportDefDetails = cacheData.reportDefDetails;
      } else {
        this.loadDefsPaginal({});
      }
    },
    loadDefsPaginal({ sortBy, pageIndex = 1 }) {
      this.reportDefs.sortBy = sortBy || this.reportDefs.sortBy;
      let requestData = productApiHelper.getRequestData(
        null,
        [this.reportDefBaseCondition],
        null,
        this.reportDefs.sortBy,
        null,
        DATA_TYPES.REPORT,
        pageIndex
      );
      this.$api.request(endpoints.getProductData, requestData).then(
        ({ data }) => {
          this.reportDefs.data = data.records;
          this.reportDefs.pageCount = Math.ceil(data.recordCount / PAGE_SIZE);
          this.$refs.reportDefsGrid.selectDefault();
        },
        () => {
          this.reportDefs.data = [];
          this.reportDefs.pageCount = 0;
        }
      );
    },
    postAddDef(record) {
      this.reportDefs.data.unshift(record);
      this.$refs.reportDefsGrid.selectDefault();
      this.defEditor.visible = false;
    },
    postEditDef(record) {
      this.$set(record, "_selected", true);
      this.reportDefs.data.splice(this.reportDefs.selectedItemIndex, 1, record);
      this.reportDefs.selectedItem = record;
      this.defEditor.visible = false;
    },
    getReportDefDetailsData() {
      let data = [];
      if (this.reportDefs.selectedItem) {
        data = parseEntityTableFieldValueToEntity(
          (
            this.reportDefs.selectedItem.attributes["Limit Detail Def"] || {
              value: []
            }
          ).value
        );
      }
      this.reportDefDetails.data = data;
    },
    postAddDetail(record) {
      this.postEditDef(record);
      this.detailEditor.visible = false;
    },
    postEditDetail(record) {
      this.postEditDef(record);
      this.detailEditor.visible = false;
      this.$nextTick(() => {
        this.$refs.reportDetailsGrid.selectRow(
          this.reportDefDetailsData[this.reportDefDetails.selectedItemIndex],
          this.reportDefDetails.selectedItemIndex
        );
      });
    },
    selectDef({ currentItem, index }) {
      this.reportDefs.selectedItem = currentItem;
      this.reportDefs.selectedItemIndex = index;
      if (!currentItem.attributes["Limit Detail Def"]) {
        currentItem.attributes["Limit Detail Def"] = { value: [] };
      }
    },
    selectDetail({ currentItem, index }) {
      this.reportDefDetails.selectedItem = currentItem;
      this.reportDefDetails.selectedItemIndex = index;
    },
    doRemoveRef() {
      let requestData = processApiHelper.getDeleteRequestData(
        this.reportDefs.selectedItem,
        this.template,
        DATA_TYPES.REPORT
      );
      return this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.reportDefs.data.splice(this.reportDefs.selectedItemIndex, 1);
            this.$refs.reportDefsGrid.selectDefault();
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.message = "";
          }
        });
    },
    doRemoveRefDetail() {
      let entry = clone(this.reportDefs.selectedItem);
      entry.attributes["Limit Detail Def"].value.splice(
        this.reportDefDetails.selectedItemIndex,
        1
      );
      let requestData = processApiHelper.getUpdateRequestData(
        entry,
        this.template,
        DATA_TYPES.REPORT
      );
      return this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.postEditDef(data[0]);
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    calculateReport() {
      let requestData = processApiHelper.getCalculateRequestData(
        this.reportDefs.selectedItem,
        this.template,
        DATA_TYPES.REPORT
      );
      return this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ messages }) => {
          this.logAlert.logs = messages;
        });
    },
    gotoReportDetails() {
      let entry = this.reportDefs.selectedItem;
      this.$router.push({
        path: "/limitreportdetails/" + entry.id,
        query: {
          name: entry.name,
          groupBy: (entry.attributes["Group By"] || {}).value,
          portfolioId: (entry.attributes["Portfolio ID"] || {}).value,
          ac: (entry.attributes["Analysis Currency"] || {}).value, //Analysis Currency
          lct: (entry.attributes["Limit Calculate Type"] || {}).value //Limit Calculate Type
        }
      });
    },
    resizeX(offset) {
      let totalWidth = this.$refs.frame.clientWidth,
        leftWidth = this.$refs.left.clientWidth,
        leftMinWidth = SIZE.LIMIT_REPORT_DEF_MIN_WIDTH,
        rightWidth = this.$refs.right.clientWidth,
        rightMinWidth = SIZE.LIMIT_REPORT_DEF_DETAILS_MIN_WIDTH,
        distance = Math.min(
          Math.max(leftMinWidth - leftWidth, offset),
          rightWidth - rightMinWidth
        );
      this.$refs.left.style.width = leftWidth + distance + "px";
      this.$refs.right.style.width = rightWidth - distance + "px";
      this.resize();
    },
    resize() {
      this.$refs.reportDefsGrid.resize();
      this.$refs.reportDetailsGrid.resize();
    },
    getCacheData() {
      return {
        reportDefs: this.reportDefs,
        reportDefDetails: this.reportDefDetails
      };
    }
  }
};
</script>

<style scoped>
.report-main {
  float: left;
  height: 100%;
  width: 40%;
}
.report-detail {
  float: left;
  height: 100%;
  width: calc(60% - 8px);
  width: -ms-calc(60% - 8px);
  width: -moz-calc(60% - 8px);
  width: -webkit-calc(60% - 8px);
}
</style>