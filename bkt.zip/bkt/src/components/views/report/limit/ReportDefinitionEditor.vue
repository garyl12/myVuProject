<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-inner">
      <editor-logger :logs="logs" />
      <div class="category-group" v-for="(category,index) in categoryGroups" :key ="index" v-show="category.fields.length">
        <div class="section">
          <span class="category-title">{{ $t_(category.groupName || "") }}</span>
        </div>
        <fields-renderer
          :fields="category.fields"
          :entry="entry"
          :adding="isAdding"
          ref="fieldsRenderer"
          />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
	  </div>
    <alert :config="alert" />
  </el-dialog>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import Alert from "@/components/common/Alert";
import endpoints from "@/api/endpoints";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import { mapGetters } from "vuex";
import { clone, getEditorTitle, autoCompleteFields } from "@/utils";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import { EDITOR_STATUS, RESPONSE_CODE, DATA_TYPES } from "@/consts";

export default {
  name: "LimitReportDefinitionEditor",
  components: { FieldsRenderer, EditorLogger, Alert },
  props: {
    visible: {
      required: true,
      type: Boolean
    },
    status: {
      required: true,
      type: Number
    }
  },
  data() {
    return {
      logs: [],
      entry: {},
      alert: {
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  watch: {
    visible() {
      if (this.visible) {
        this.reset();
      }
    }
  },
  computed: {
    ...mapGetters({
      selectedEntry: "getSelectedEntry",
      templates: "getTemplates"
    }),
    template() {
      return this.templates["LIMIT_REPORT_DEF"];
    },
    categoryGroups() {
      if (this.template) {
        return assembleTemplateCategories(this.template, this.$api);
      }
      return [];
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    },
    baseConditions() {
      return [
        {
          attributeName: "ID",
          operator: "EQUAL",
          searchType: "CUSTOMIZED",
          searchValues: this.entry.attributes
            ? [this.entry.attributes["ID"].value]
            : [],
          valueType: "STRING"
        },
        {
          attributeName: "Template Name",
          operator: "EQUAL",
          searchType: "CUSTOMIZED",
          searchValues: ["LIMIT_REPORT_DEF"],
          valueType: "STRING"
        }
      ];
    }
  },
  methods: {
    validate() {
      let invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    validateID() {
      if (this.isAdding) {
        let requestData = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.REPORT
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert.visible = true;
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    save() {
      if (this.validate()) {
        if (this.isAdding)
          this.entry.attributes["ID"].value = this.entry.attributes[
            "Report Def ID"
          ].value;
        this.validateID().then(() => {
          this.sendRequest(this.entry).then(record => {
            let event =
              this.status === EDITOR_STATUS.ADDING
                ? "add"
                : this.status === EDITOR_STATUS.EDITING ? "edit" : "clone";
            this.$emit(event, record);
          });
        });
      }
    },
    sendRequest(entry) {
      let requestData = processApiHelper.getUpdateRequestData(
        entry,
        this.template,
        DATA_TYPES.REPORT
      );
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data[0]);
          } else {
            return Promise.reject();
          }
        },
        _ => {
          return Promise.reject();
        }
      );
    },
    reset() {
      this.logs = [];
      this.entry =
        this.status === EDITOR_STATUS.ADDING
          ? autoCompleteFields({ attributes: {} }, this.template, true)
          : autoCompleteFields(clone(this.selectedEntry), this.template);
    },
    close() {
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  height: calc(100% - 20px);
  border: 1px solid #ccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>