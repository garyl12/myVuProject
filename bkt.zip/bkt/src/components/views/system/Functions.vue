<template>

</template>

<script>
export default {
  name: "FunctionManagement"
};
</script>

<style scoped>
</style>