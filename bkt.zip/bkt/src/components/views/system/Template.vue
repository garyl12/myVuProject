<template>
  <div class="template-frame clearfix" ref="frame">
      <div class="template-type">
        <grid
          :need-index="true"
          :columns="templateColumns"
          :data="templateList"
          :need-searcher="true"
          :searcherPlaceholder="template.defaultSearcher.placeholder"
          @search="searchTemplate"
          @select="selectTemplate"
          ref="templateGrid"
          >    
        </grid>
      </div>
      <div class="h-drag" onselectstart="return false;">
        <div class="mid" onselectstart="return false;"></div>
        <div class="h-drag-shadow" onselectstart="return false;" ref="xShadow">
          <div onselectstart="return false;">
          </div>
        </div>
      </div>
      <div class="template-subclass">
        <div class="detailCon">
					<table class="tableItem" >
						<thead>
							<tr>
								<th></th>
								<th :title="$t_('name')">{{$t_("name")}}</th>
								<th :title="$t_('groupName')">{{$t_("groupName")}}</th>
								<th :title="$t_('dataType')">{{$t_("dataType")}}</th>
								<th :title="$t_('name')">{{$t_("input")}}</th>
								<th :title="$t_('input')">{{$t_("output")}}</th>
								<th :title="$t_('reference')">{{$t_("reference")}}</th>
								<th :title="$t_('refTypes')">{{$t_("refTypes")}}</th>
								<th :title="$t_('enumRef')">{{$t_("enumRef")}}</th>
							</tr>
						</thead>
						<tbody>
							<tr v-for="(el,index) in detailData" v-if="el.show" :key="index" :class="[{'selected':el.selected}]" @click="selectRow(el)" >
								<td class="first"><span @click="toggleState(el,index)" :class="{'indent':el.isChild}"><i class="iconfont" :class="el.icon"></i></span></td>
								<td :title="el.name">{{el.name}}</td>
								<td :title="el.groupName">{{el.groupName}}</td>
								<td :title="el.dataType">{{el.dataType}}</td>
								<td :title="el.input">{{el.input}}</td>
								<td :title="el.output">{{el.output}}</td>
								<td :title="el.reference">{{el.reference}}</td>
								<td :title="el.refTypes">{{el.refTypes}}</td>
								<td :title="el.enumRef">{{el.enumRef}}</td>
							</tr>
              <tr >
                <td colspan="9" v-show="!detailData.length">
                  <p class="no-record" >
                    {{$t_("no record")}}
                  </p>
                </td>
              </tr>
						</tbody>
					</table>
				</div>

      </div>
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { PAGE_SIZE } from "@/consts";
import { parseBeanToEntityAttributes, clone } from "@/utils";

const transferColumns = ["id", "name", "type"];

export default {
  name: "TemplateManagement",
  components: {
    Grid
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates"
    }),
    templateList() {
      let templateList = [],
        originalData = clone(this.templates);
      for (let key in originalData) {
        let item = parseBeanToEntityAttributes(
          originalData[key],
          transferColumns
        );
        let searchVal = this.currentSearchCondition;
        let isInvolved = this.isIncluded(searchVal, item);
        if (isInvolved) {
          templateList.push({
            attributes: item
          });
        }
      }
      return templateList;
    },
    templateColumns() {
      return [
        {
          attributeName: "id",
          displayName: "id"
        },
        {
          attributeName: "name",
          displayName: "name"
        },
        {
          attributeName: "type",
          displayName: "type"
        }
      ];
    }
  },
  watch: {
    templateList() {
      this.$refs.templateGrid.selectDefault();
    }
  },
  data() {
    return {
      template: {
        defaultSearcher: {
          searchText: "",
          placeholder: "name, code"
        }
      },
      currentSearchCondition: null,
      subTemplate: {
        data: []
      },
      detailData: []
    };
  },
  methods: {
    selectTemplate({ currentItem }) {
      this.subTemplate.data = currentItem.attributes.measures;
      this.setDetailDate(currentItem.attributes.measures);
    },
    searchTemplate({ searchBy }) {
      this.currentSearchCondition = searchBy;
    },
    isIncluded(key, item) {
      let involved = false;
      if (
        !key ||
        item.id.value.indexOf(key) !== -1 ||
        item.name.value.indexOf(key) !== -1 ||
        item.type.value.indexOf(key) !== -1
      ) {
        involved = true;
      }
      item.measures.forEach(measure => {
        if (measure.name.indexOf(key) !== -1) {
          involved = true;
        }
        if (measure.subMeasures.length) {
          measure.subMeasures.forEach(subMeasure => {
            if (subMeasure.name.indexOf(key) !== -1) {
              involved = true;
            }
          });
        }
      });
      return involved;
    },
    setDetailDate(data) {
      let _this = this;
      _this.detailData = [];
      let attributes = [];
      if (data.length) {
        for (let i = 0; i < data.length; i++) {
          let item = clone(data[i]);
          item.referenceName = data[i].name;
          item.selected = false;
          item.isChild = false;
          item.childShow = false;
          item.show = true;
          if (data[i].dataType === "TABLE") {
            item.icon = "icon-plus2";
            item.hasChild = true;
            attributes.push(item);
            for (let j = 0; j < data[i].subMeasures.length; j++) {
              let measure = clone(data[i].subMeasures[j]);
              measure.referenceName = data[i].name;
              measure.hasChild = false;
              measure.isChild = true;
              measure.childShow = false;
              measure.show = false;
              measure.icon = "icon-dot";
              attributes.push(measure);
            }
          } else {
            item.hasChild = false;
            item.icon = "icon-dot";
            attributes.push(item);
          }
        }
        _this.detailData = attributes;
      } else {
        _this.detailData = [];
      }
    },
    selectRow(el) {
      this.detailData.forEach(item => {
        item.selected = false;
      });
      el.selected = true;
    },
    toggleState(el, index) {
      let _this = this,
        name = el.name;
      if (el.hasChild) {
        if (!el.childShow) {
          for (let i = 0; i < _this.detailData.length; i++) {
            if (_this.detailData[i].referenceName === name) {
              if (!_this.detailData[i].hasChild) {
                _this.detailData[i].show = true;
              } else {
                _this.detailData[i].icon = "icon-minus2";
                _this.detailData[i].childShow = true;
              }
            }
          }
        } else {
          for (let i = 0; i < _this.detailData.length; i++) {
            if (_this.detailData[i].referenceName == name) {
              if (!_this.detailData[i].hasChild) {
                _this.detailData[i].show = false;
              } else {
                _this.detailData[i].icon = "icon-plus2";
                _this.detailData[i].childShow = false;
              }
            }
          }
        }
      } else {
        return;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.template-frame {
  height: 100%;
}
.h-drag {
  cursor: default;
}
.template-type {
  height: 100%;
  width: 50%;
  float: left;
}
.template-subclass {
  height: 100%;
  width: calc(50% - 8px);
  width: -ms-calc(50% -8px);
  width: -moz-calc(50% - 8px);
  width: -webkit-calc(50% - 8px);
  float: left;
}
.detailCon {
  margin: 5px 10px 0 10px;
  height: 100%;
  width: calc(100% - 20px);
  width: -ms-calc(100% -20px);
  width: -moz-calc(100% - 20px);
  width: -webkit-calc(100% - 20px);
  overflow-y: auto;
  overflow-x: hidden;
  .tableItem {
    width: 100%;
    overflow: auto;
    border-right: 1px solid #dddddd;
    border-left: 1px solid #dddddd;
    thead {
      tr {
        background-color: #383f52;
        th {
          color: #ffffff;
          text-align: left;
          padding: 0px 6px;
          height: 30px;
          line-height: 30px;
          text-align: left;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
      }
    }
    tbody {
      tr.selected {
        background-color: #e9e7e7;
      }
      tr {
        background-color: #ffffff;
        td {
          height: 24px;
          line-height: 24px;
          border-bottom: 1px solid #dddddd;
          border-right: 1px solid #dddddd;
          box-sizing: border-box;
          -moz-box-sizing: border-box;
          -webkit-box-sizing: border-box;
          text-align: left;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          span.indent {
            padding-left: 10px;
          }
        }
        td.first {
          width: 30px;
          text-align: left;
          padding-left: 6px;
        }
      }
      tr:hover {
        background-color: #e9e7e7;
      }
    }
  }
}
</style>
