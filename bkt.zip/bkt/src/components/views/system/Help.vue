<template>
  	<div class="client-help">
		<div class="help-wrap">
			<ul class="download-list">			
        <li v-for="(item,i) in  contentData" :key="i">
          <div class="title">
						{{item.title}}
					</div>
					<div class="download-link">
						<a :href="item.href" download>{{item.moduleName}}</a>
					</div>
          </li>			
			</ul>
			<div class="introduction">
				<div class="instroduce">
					<div class="instroduce-wrap">
						<h3 class="instroduce-title">{{introduce.title}}:</h3>
						<div class="technology">
              <p>{{introduce.content}}</p>	
						</div>
					</div>
				</div>
				<div class="company-adress">
          <span class="left">{{introduce.companyName}}</span><span class="middle">{{introduce.companyName}}</span><span>{{introduce.companyAddress}}</span>
				</div>
			</div>

		</div>
	</div>
</template>
<script>
export default {
  name: "help",
  data() {
    return {
      display: {},
      contentData: [
        {
          title: "批量导入用户信息用量",
          moduleName: "用户信息批量添加excel样例",
          href: "../../static/data/module.xls"
        },
        {
          title: "批量导入功能及模块信息样例",
          moduleName: "功能及模块批量导入excel样例",
          href: "../../static/data/module.xls"
        },
        {
          title: "批量导入字典数据样例",
          moduleName: "字典数据批量添加excel样例",
          href: "../../static/data/module.xls"
        }
      ],
      introduce: {
        title: "技术支持：",
        content:
          "上海巴刻汀信息技术有限公司（简称巴刻汀）总部位于上海（研发中心位于浙江省杭州市），注册资金1000万人民币。巴刻汀公司拥有一支成熟的、具有深厚经验的运营、管理及研发团队, 核心研发团队主要来自Algo，巴刻汀团队人员来自Algorithmics、RiskGrid、枫叶银行等。核心团队平均10年以上行业经验，对金融行业有深刻的理解和认识。我们致力于为金融行业提供拥有自主知识产权、安全可控的市场风险管理系统及相关SAAS服务产品。",
        companyName: "公司名称:上海巴刻汀信息技术有限公司",
        servicePhone: "服务电话：0571-88117171",
        companyAddress: "公司地址：杭州市滨江区滨盛路1505号银丰大厦2202A"
      }
    };
  }
};
</script>
<style lang="scss" scoped>
.client-help {
  background: #ecf1f5;
  padding: 10px 10px 0 10px;
  .help-wrap {
    width: 100%;
    background-color: #ffffff;
    ul.download-list {
      height: 400px;
      overflow: auto;
      background-color: #ffffff;
      padding: 45px 45px 0px 45px;
      border-bottom: 1px solid #cccccc;
      box-shadow: 1px 0px 1px 1px #ccc;
      li {
        display: block;
        border-top: 2px solid #cccccc;
        margin: 0;
        position: relative;
        box-sizing: border-box;
        .title {
          color: #2b3245;
          font-weight: 900;
          background-color: #ffffff;
          position: absolute;
          z-index: 1;
          left: 0;
          top: -16px;
          font-size: 16px;
          line-height: 30px;
          padding: 0 6px 0 0;
          span {
            display: inline-block;
          }
        }
        .download-link {
          display: inline-block;
          min-width: 330px;
          height: 35px;
          line-height: 35px;
          margin-top: 40px;
          margin: 18px 0 35px 0px;
          a {
            margin-left: 20px;
            display: inline-block;
            font-size: 16px;
            color: #337ab7;
            text-decoration: none;
            height: 26px;
            line-height: 26px;
          }
          a:hover {
            text-decoration: none;
          }
        }
      }
    }
    .introduction {
      border: 1px solid #cccccc;
      border-top: 0;
      box-shadow: 1px 0px 1px 1px #cccccc;
      padding: 30px 20px 20px 20px;
      .instroduce {
        width: 99.8%;
        border: 1px solid #333333;
        position: relative;
        .instroduce-title {
          display: inline-block;
          padding: 0 10px 0 10px;
          position: absolute;
          top: -17px;
          line-height: 28px;
          font-weight: 600;
          font-size: 16px;
          border: 0;
          background-color: #ffffff;
          margin-left: 20px;
        }
        .technology {
          border: 1px solid #cccccc;
          height: 170px;
          margin-top: 30px;
          box-shadow: 1px 0px 1px 0px #cccccc;
          margin: 20px 10px 0 10px;
          padding: 16px;
          p {
            color: #000000;
            font-size: 16px;
            line-height: 26px;
            text-indent: 20px;
          }
        }
      }
      .company-adress {
        background-color: #2b3245;
        height: 55px;
        span {
          display: inline-block;
          height: 100%;
          line-height: 55px;
          font-size: 16px;
          color: #ffffff;
          font-weight: bold;
          width: 33.3%;
          text-align: left;
          padding-left: 20px;
          box-sizing: border-box;
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          -o-box-sizing: border-box;
          -ms-box-sizing: border-box;
        }
        span.middle {
          padding-left: 6%;
        }
      }
    }
  }
}
</style>
