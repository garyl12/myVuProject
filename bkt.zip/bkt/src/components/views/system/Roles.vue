<template>
    <div class="roles-page">
        <div class="role-detail">
            <div class="detail-header">{{display.details.title}}</div>
            <div class="detail-main">
                <div class="button-area">
                    <span class="btn btn-white" @click="edit" v-show="!isEditing">{{display.details.buttons.edit}}</span>
                    <span class="btn btn-white" @click="save" v-show="isEditing">{{display.details.buttons.save}}</span>
                    <span class="btn btn-white" @click="add">{{display.details.buttons.add}}</span>
                    <span class="btn btn-white" @click="cancel" v-show="isAdding||isEditing">{{display.details.buttons.cancel}}</span>
                </div>
                <div class="field-area">
                    <div v-show="!isEditing && !isAdding">
                      <display-field field-name="角色ID" :field-val="currentItem.id"></display-field>
                      <display-field field-name="角色名称" :field-val="currentItem.roleName"></display-field>
                      <display-field field-name="角色权限" field-val="查看详情" :show-as-link="true" @click="showRoleRights"></display-field>
                      <display-field field-name="数据授权范围" :field-val="currentItem.dataScope"></display-field>
                      <display-field field-name="角色描述" :field-val="currentItem.roleDesc"></display-field>                        
                    </div>
                    <div v-show="isEditing && !isAdding">
                      <display-field field-name="角色ID" :field-val="currentItem.id"></display-field>
                      <text-field field-name="角色名称" :required="true" :field-val="currentItem.roleName" v-model="currentItem.roleName"></text-field>
                      <display-field field-name="角色权限" field-val="编辑" :show-as-link="true" @click="showRoleRights"></display-field>                      
                      <dropdownlist-field field-name="数据授权范围" :options="dataAuthRangeOptions" :required="true" :field-val="currentItem.dataScope" v-model="currentItem.dataScope"></dropdownlist-field>
                      <text-field field-name="角色描述" field-type="textarea" :required="true" :field-val="currentItem.roleDesc" v-model="currentItem.roleDesc"></text-field>
                    </div>
                    <div v-show="isAdding && !isEditing">
                      <display-field field-name="角色ID" :field-val="currentItem.id"></display-field>
                      <text-field field-name="角色名称" :required="true" :field-val="currentItem.roleName" v-model="currentItem.roleName"></text-field>
                      <display-field field-name="角色权限" field-val="添加" :show-as-link="true" @click="showRoleRights"></display-field>                      
                      <dropdownlist-field field-name="数据授权范围" :options="dataAuthRangeOptions" :required="true" :field-val="currentItem.dataScope" v-model="currentItem.dataScope"></dropdownlist-field>
                      <text-field field-name="角色描述" field-type="textarea" :required="true" :field-val="currentItem.roleDesc" v-model="currentItem.roleDesc"></text-field>
                    </div>
                </div>
            </div>
        </div>
        <div class="roles-table">
          <grid
            :need-index="true"
            :need-searcher="true"
            :searcher-placeholder="''"
            :columns="gridColumns"
            :data="data"
            :page-count="pageCount"
            @jump-page="gotoPage" 
            @prev-page="gotoPage" 
            @next-page="gotoPage"
            @search="search"
            @select="selectRow"
            >
              <span class="btn btn-dark" @click="add">{{display.table.buttons.add}}</span>
              <span class="btn btn-dark" @click="remove">{{display.table.buttons.delete}}</span>
            </grid>
        </div>
        <el-dialog :title="display.warning.title" class="popup dark tiny" :visible.sync="isEditingWarningVisible" :show-close="false">
          <span>{{display.warning.quitEditingMsg}}</span>
          <span slot="footer">
            <el-button @click="isEditingWarningVisible=false">{{display.warning.cancel}}</el-button>
            <el-button type="primary" @click="quit">{{display.warning.ok}}</el-button>
			    </span>
		    </el-dialog>
        <el-dialog :title="display.roleFunctionsPicker.title" class="popup white" :visible.sync="roleFunctionsPicker.visible" :show-close="false">
          <div v-if="!roleFunctionsPicker.readonly">
				    <el-tree :data="roleFunctionsPicker.functions" show-checkbox node-key="role-functions-picker" :default-expand-all=true :default-checked-keys="roleFunctionsPicker.checkedFunctions" :props="roleFunctionsPicker.treeProps">
				    </el-tree>
			    </div>
          <div v-if="roleFunctionsPicker.readonly">
				    <el-tree :data="roleFunctionsPicker.functions" node-key="role-functions-picker" :default-expand-all=true :default-checked-keys="roleFunctionsPicker.checkedFunctions" :props="roleFunctionsPicker.treeProps">
				    </el-tree>
			    </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelRoleFunctions">{{display.roleFunctionsPicker.cancel}}</el-button>
            <el-button type="primary" @click="saveRoleFunctions" v-show="!roleFunctionsPicker.readonly">{{display.roleFunctionsPicker.ok}}</el-button>
			    </div>
        </el-dialog>
    </div>
</template>
<script>
import Grid from "@/components/common/Grid";
import DisplayField from "@/components/fields/DisplayField";
import TextField from "@/components/fields/TextUIField";
import DropdownlistField from "@/components/fields/DropdownlistUIField";
import endpoints from "@/api/endpoints";
import { clone, convertPropertiesToAttributes } from "@/utils";
import { RESPONSE_CODE } from "@/consts";

export default {
  name: "Roles",
  components: {
    Grid,
    DisplayField,
    TextField,
    DropdownlistField
  },
  data() {
    return {
      display: {
        table: {
          buttons: {
            add: "添加",
            delete: "删除"
          }
        },
        details: {
          buttons: {
            edit: "编辑",
            add: "添加",
            save: "保存",
            cancel: "取消"
          },
          title: "详情"
        },
        roleFunctionsPicker: {
          title: "角色功能选择",
          ok: "确定",
          cancel: "取消"
        },
        warning: {
          title: "提示",
          quitEditingMsg: "点击确定放弃编辑",
          ok: "确定",
          cancel: "取消"
        }
      },
      gridColumns: [
        {
          attributeName: "id",
          displayName: "角色ID",
          colWidth: 100
        },
        {
          attributeName: "roleName",
          displayName: "角色名称",
          colWidth: 100
        },
        {
          attributeName: "dataScope",
          displayName: "数据授权范围",
          colWidth: 100
        },
        {
          attributeName: "roleDesc",
          displayName: "角色描述",
          colWidth: 100
        }
      ],
      data: [],
      pageCount: 0,
      isEditing: false,
      isAdding: false,
      currentItem: {},
      targetItem: null,
      addingItem: {},
      gridOption: {
        pageSize: 10,
        pageIndex: 1,
        condition: ""
      },
      selectedRoleId: -1,
      dataAuthRangeOptions: [],
      isEditingWarningVisible: false,
      roleFunctionsPicker: {
        visible: false,
        readonly: true,
        functions: [],
        checkedFunctions: [],
        treeProps: {
          label: "functionDesc",
          children: "childs"
        }
      }
    };
  },
  mounted() {
    var self = this;
    var $ = this.$;
    //details panel on right side is 300px
    //grid has 10 px left and right padding
    //grid has a 50px sequence column
    var gridDefaultWidth = $(".main-body").width() - 300 - 20 - 50;
    var columnWidth = gridDefaultWidth / 4;
    this.gridColumns.forEach(col => (col.width = columnWidth));
    this.$api
      .request(endpoints.getRoles, {
        pageSize: this.gridOption.pageSize,
        pageNo: this.gridOption.pageIndex,
        condition: this.gridOption.condition
      })
      .then(({ code, data }) => {
        if (code === RESPONSE_CODE.INFO) {
          if (data) {
            this.data = convertPropertiesToAttributes(data.list);
            this.pageCount = data.pages;
            this.currentItem = clone(self.data[0]);
            this.$set(this.data[0], "_selected", true);
          }
        }
      });
    this.$api
      .request(endpoints.getDataAuthRangeOptions)
      .then(({ code, data }) => {
        if (code === RESPONSE_CODE.INFO) {
          data.forEach(item => {
            self.dataAuthRangeOptions.push({
              logicVal: item.value,
              displayVal: item.label
            });
          });
        }
      });
  },
  methods: {
    gotoPage(params) {
      //TODO: params.sortBy & params.searchBy => 'condition'
      this.$api
        .request(endpoints.getRoles, {
          pageSize: this.gridOption.pageSize,
          pageNo: params.pageIndex,
          condition: this.gridOption.condition
        })
        .then(({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.data = convertPropertiesToAttributes(data.list);
            this.pageCount = data.pages;
          }
        });
    },
    search(params) {
      //TODO: params.sortBy & params.searchBy => 'condition'
      this.$api
        .request(endpoints.getRoles, {
          pageSize: this.gridOption.pageSize,
          pageNo: 1,
          condition: this.gridOption.condition
        })
        .then(({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.data = convertPropertiesToAttributes(data.list);
            this.pageCount = data.pages;
          }
        });
    },
    selectRow({ previousItem, currentItem }) {
      if (this.isEditing || this.isAdding) {
        previousItem._selected = true;
        currentItem._selected = false;
        this.isEditingWarningVisible = true;
        this.targetItem = currentItem;
      } else {
        this.currentItem = clone(currentItem);
        this.selectedRoleId = currentItem.id;
      }
    },
    edit() {
      if (this.isAdding) {
        this.isEditingWarningVisible = true;
      } else if (this.currentItem.id) {
        this.isEditing = true;
        this.targetItem = null;
      }
    },
    add() {
      if (this.isEditing) {
        this.isEditingWarningVisible = true;
      } else {
        this.isEditing = false;
        this.isAdding = true;
        this.currentItem = {};
      }
    },
    save() {
      //TODO: post data, lacking functionIds
      this.$api
        .request(endpoints.addRole, {
          roleName: this.currentItem.roleName,
          roleDesc: this.currentItem.roleDesc,
          dataScope: this.currentItem.dataScope,
          functionIds: ""
        })
        .then(({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            if (data) {
              this.isAdding = false;
              this.isEditing = false;
            }
          }
        });
    },
    showRoleRights() {
      var self = this;
      //TODO: when adding, orgId? roleId?
      this.$api
        .request(endpoints.getRoleFunctions, {
          orgId: this.currentItem.orgId,
          roleId: this.currentItem.id
        })
        .then(({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            if (data) {
              self.roleFunctionsPicker.functions = data;
              self.roleFunctionsPicker.readonly = !(
                self.isAdding || self.isEditing
              );
              self.roleFunctionsPicker.visible = true;
            }
          }
        });
    },
    quit() {
      var self = this;
      // 4 kinds of switching
      // adding -> showing === by selecting another row
      // adding -> editing === by hitting edit button
      // editing -> showing === by selecting another row
      // editing -> adding === by hitting add button
      if (this.isAdding) {
        this.isAdding = false;
        if (this.targetItem) {
          // adding -> showing
          this.data.forEach(item => (item._selected = false));
          this.targetItem._selected = true;
          this.currentItem = clone(this.targetItem);
          this.targetItem = null;
        } else {
          // adding -> editing
          this.data.forEach(item => {
            if (item._selected) {
              self.currentItem = clone(item);
            }
          });
          this.isEditing = true;
        }
      } else if (this.isEditing) {
        this.isEditing = false;
        if (this.targetItem) {
          // editing -> showing
          this.targetItem._selected = true;
          this.data.forEach(item => (item._selected = false));
          this.currentItem = clone(this.targetItem);
          this.targetItem = null;
        } else {
          // editing -> adding
          this.currentItem = {};
          this.isAdding = true;
        }
      }
      this.isEditingWarningVisible = false;
    },
    cancel() {
      this.isAdding = false;
      this.isEditing = false;
      var self = this;
      this.data.forEach(item => {
        if (item._selected) {
          self.currentItem = clone(item);
        }
      });
    },
    remove() {
      this.$api
        .request(endpoints.removeRole, {
          roleIdStr: this.selectedRoleId
        })
        .then(() => {});
    },
    saveRoleFunctions() {
      if (this.roleFunctionsPicker.readonly) {
        return;
      } else {
        //TODO: collect checked role functions
      }
    },
    cancelRoleFunctions() {
      this.roleFunctionsPicker.visible = false;
      // to scroll the popup window to top
      this.roleFunctionsPicker.functions = [];
    }
  }
};
</script>
<style scoped>
.roles-page {
  height: 100%;
}
.roles-table {
  margin-right: 300px;
  height: 100%;
}
.role-detail {
  float: right;
  width: 300px;
  height: 100%;
}
.detail-header {
  text-align: center;
  background-color: #383f52;
  height: 30px;
  margin-top: 10px;
  color: #ffffff;
  line-height: 30px;
}
.detail-main {
  background-color: #383f52;
  margin-top: 20px;
  height: -webkit-calc(100% - 60px);
  height: -ms-calc(100% - 60px);
  height: -moz-calc(100% - 60px);
  height: -o-calc(100% - 60px);
  height: calc(100% - 60px);
  overflow: auto;
}
.button-area {
  margin: 20px 0 0 20px;
}
.field-area {
  margin: 20px 0 0 20px;
  color: #ffffff;
}
</style>
