<template>
  <div style="height:100%">
    <grid
      :columns="columns"
      :data="grid.data"
      :need-index="true"
      :need-searcher="true"
      :condition="grid.searchBy"
      @search="loadData"
      @select="select"
      ref="grid">
      <button-bar :buttons="buttons"/>
    </grid>
    <time-interval-editor
      :visible="editor.visible"
      :status="editor.status"
      :selected-entry="grid.selectedItem"
      @close="editor.visible=false"
      @add="postAdd"
      @edit="postEdit"
      />
    <alert :config="alert"/>
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Alert from "@/components/common/Alert";
import TimeIntervalEditor from "./TimeIntervalEditor";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { RESPONSE_CODE, DATA_TYPES, EDITOR_STATUS, FILE_TYPES } from "@/consts";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import mixin from "../mixin";

export default {
  name: "TimeIntervalManagement",
  components: { Grid, ButtonBar, Alert, TimeIntervalEditor },
  mixins: [mixin],
  data() {
    return {
      grid: {
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        searchBy: null
      },
      editor: {
        visible: false,
        status: -1
      },
      alert: {
        title: "",
        message: "",
        logs: [],
        buttons: [],
        visible: false
      }
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      views: "getViews"
    }),
    template() {
      return this.templates["DRM_TIME_INTERVAL"];
    },
    view() {
      return this.views["DEFAULT"];
    },
    columns() {
      return [
        {
          attributeName: "ID",
          displayName: "ID"
        },
        {
          attributeName: "Time Interval Name",
          displayName: "Time Interval Name"
        },
        {
          attributeName: "Time Interval Code",
          displayName: "Time Interval Code"
        },
        {
          attributeName: "Interval Start Days",
          displayName: "Interval Start Days"
        },
        {
          attributeName: "Interval End Days",
          displayName: "Interval End Days"
        }
      ];
    },
    buttons() {
      return [
        {
          text: "add",
          icon: "icon-xinjian",
          active: true,
          callback: () => {
            this.editor.status = EDITOR_STATUS.ADDING;
            this.editor.visible = true;
          }
        },
        {
          text: "edit",
          icon: "icon-bianji",
          active: this.grid.selectedIndex > -1,
          callback: () => {
            this.editor.status = EDITOR_STATUS.EDITING;
            this.editor.visible = true;
          }
        },
        {
          text: "delete",
          icon: "icon-shanchu",
          active: true,
          callback: () => {
            this.alert = {
              title: "warning",
              message: "remove_confirmation",
              logs: [],
              buttons: [
                {
                  title: "confirm",
                  callback: () => {
                    this.doRemove();
                    this.alert.visible = false;
                  }
                },
                {
                  title: "cancel",
                  callback: () => {
                    this.alert.visible = false;
                  }
                }
              ],
              visible: true
            };
          }
        }
      ];
    },
    baseConditions() {
      return [
        {
          attributeName: "Template Name",
          searchValues: ["DRM_TIME_INTERVAL"]
        }
      ];
    }
  },
  created() {
    this.loadData({});
  },
  methods: {
    select({ currentItem, index }) {
      this.grid.selectedItem = currentItem;
      this.grid.selectedIndex = index;
    },
    loadData({ searchBy }) {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.grid = cacheData;
      } else {
        this.grid.searchBy = searchBy;
        let requestParam = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          searchBy,
          null,
          this.columns,
          DATA_TYPES.TIME_INTERVAL,
          0,
          0
        );
        this.$api
          .request(endpoints.getProductData, requestParam)
          .then(({ code, data }) => {
            if (code === RESPONSE_CODE.INFO) {
              this.grid.data = data.records;
              this.$refs.grid.selectDefault();
            }
          });
      }
    },
    postAdd(record) {
      this.grid.data.unshift(record);
      this.$refs.grid.selectDefault();
      this.editor.visible = false;
    },
    postEdit(record) {
      this.grid.data.splice(this.grid.selectedIndex, 1, record);
      this.$refs.grid.selectDefault(this.grid.selectedIndex);
      this.editor.visible = false;
    },
    doRemove() {
      let delRequestParam = processApiHelper.getDeleteRequestData(
        this.grid.selectedItem,
        this.template,
        DATA_TYPES.TIME_INTERVAL
      );
      this.$api
        .request(endpoints.processProduct, delRequestParam)
        .then(({ code, messages }) => {
          this.alert = {
            visible: true,
            title: code,
            message: "",
            buttons: [
              {
                title: "OK",
                callback: () => {
                  this.alert.visible = false;
                }
              }
            ],
            logs: []
          };
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "remove_successfully";
            this.grid.data.splice(this.grid.selectedIndex, 1);
            this.$refs.grid.selectDefault();
          } else {
            this.alert.logs = messages;
          }
        });
    },
    getCacheData() {
      return this.grid;
    }
  }
};
</script>

<style scoped>
</style>