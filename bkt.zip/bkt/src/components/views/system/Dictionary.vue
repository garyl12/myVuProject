<template>
  <div class="frame clearfix" ref="frame">
      <div class="dictionary">
        <grid
          :columns="dictionaryColumns"
          :data="dictionary.data"
          :need-index="true"
          :need-searcher="true"
          :repeat-select="true"
          :condition="dictionary.searchBy"
          @search="searchDictionary"   
          @select="selectDictionary"
          ref="dictionaryGrid">
          <button-bar :buttons="dictionaryButtons" />
          </grid>
      </div>
      <resizer axis="x"/>
      <div class="option">
        <grid
          :columns="optionColumns"
          :data="dictionaryOption.data"
          :need-index="true"
          :need-searcher="true"
          :condition="dictionaryOption.searchBy"
          @search="searchOption"
          @select="selectOption"
          ref="optionGrid"
          >
          <button-bar :buttons="optionButtons" />
        </grid>
      </div>
      <dictionary-editor
        :visible="editor.visible"
        :status="editor.status"
        :dictionary="dictionary.selectedItem"
        :option="dictionaryOption.selectedItem"
        :sort="nextSort"
        @close="editor.visible=false"
        @add="postAdd"
        @edit="postEdit"
        />
      <alert :config="moveAlert" />
      <alert :config="removeConfirmation" />
      <alert :config="alert" />
      <file-downloader
        :src="downloader.src"
        :visible="downloader.visible"
        :file-types="fileTypes"
        @select-type="exportProduct"
        @close="downloader.visible=false"
        />
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Resizer from "@/components/common/Resizer";
import Alert from "@/components/common/Alert";
import DictionaryEditor from "./DictionaryEditor";
import FileDownloader from "@/components/common/FileDownloader";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { RESPONSE_CODE, DATA_TYPES, EDITOR_STATUS, FILE_TYPES } from "@/consts";
import { assembleDownloadUrl } from "@/utils";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import mixin from "../mixin";

export default {
  name: "DictionaryManagement",
  components: {
    Grid,
    Alert,
    Resizer,
    ButtonBar,
    DictionaryEditor,
    FileDownloader
  },
  mixins: [mixin],
  data() {
    return {
      moveAlert: {
        visible: false,
        title: "warning",
        message: "has_new_message",
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.moveNewlyAdded();
              this.moveAlert.visible = false;
            }
          }
        ]
      },
      alert: {
        visible: false,
        title: "warning",
        message: "",
        logs: [],
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.doRemove();
              this.removeConfirmation.visible = false;
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
      dictionary: {
        data: [],
        selectedItem: null,
        searchBy: null
      },
      dictionaryOption: {
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        searchBy: null
      },
      editor: {
        visible: false,
        status: -1
      },
      hasNewInGrid: false,
      downloader: {
        src: "",
        visible: false
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates"
    }),
    fileTypes() {
      return FILE_TYPES;
    },
    view() {
      return this.views["DICT_MANAGEMENT"];
    },
    template() {
      return this.templates["SYS_DICT"];
    },
    dictionaryColumns() {
      let columns = [];
      if (this.view) {
        columns = this.view[0].attributesInMainGrid.split(";").map(attr => {
          return {
            attributeName: attr,
            displayName: attr,
            dataType: "STRING"
          };
        });
      }
      return columns;
    },
    optionColumns() {
      let columns = [];
      if (this.view) {
        columns = this.view[1].attributesInMainGrid.split(";").map(attr => {
          return {
            attributeName: attr,
            displayName: attr,
            dataType: "STRING"
          };
        });
      }
      return columns;
    },
    dictionaryButtons() {
      return [
        {
          icon: "icon-daochu",
          active: true,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    },
    optionButtons() {
      return [
        {
          icon: "icon-xinjian",
          active:
            !!this.dictionary.selectedItem &&
            this.dictionary.selectedItem.attributes["Editable"].value,
          text: "add",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active:
            !!this.dictionary.selectedItem &&
            this.dictionary.selectedItem.attributes["Editable"].value &&
            !!this.dictionaryOption.selectedItem &&
            this.dictionaryOption.selectedItem.attributes["Editable"].value,
          text: "edit",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-shanchu",
          active:
            !!this.dictionary.selectedItem &&
            this.dictionary.selectedItem.attributes["Editable"].value &&
            !!this.dictionaryOption.selectedItem &&
            this.dictionaryOption.selectedItem.attributes["Editable"].value,
          text: "delete",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-triangleU",
          active: this.dictionaryOption.selectedIndex > 0,
          text: "up",
          callback: () => {
            if (this.hasNewInGrid) {
              this.moveAlert.visible = true;
            } else {
              this.move(false);
            }
          }
        },
        {
          icon: "icon-triangleD",
          active:
            this.dictionaryOption.selectedIndex <
            this.dictionaryOption.data.length - 1,
          text: "down",
          callback: () => {
            if (this.hasNewInGrid) {
              this.moveAlert.visible = true;
            } else {
              this.move(true);
            }
          }
        }
      ];
    },
    baseConditions() {
      // before dictionary grid loaded,  dictionary.selectedItem is null
      // after it's loaded, dictionary.selectedItem will never be null
      // baseConditions will be used to generate request parameters for dictionary options
      let conditions = [
        {
          searchType: "CUSTOMIZED",
          searchValues: ["SYS_DICT"],
          operator: "EQUAL",
          valueType: "STRING",
          attributeName: "Template Name"
        },
        {
          searchType: "CUSTOMIZED",
          searchValues: ["dictType"],
          operator: "EQUAL",
          valueType: "STRING",
          attributeName: "Dict Type"
        }
      ];
      if (this.dictionary.selectedItem) {
        conditions[1].searchValues = [
          this.dictionary.selectedItem.attributes["Value"].value
        ];
      }
      return conditions;
    },
    exportBaseCondition() {
      return [
        {
          searchType: "CUSTOMIZED",
          searchValues: ["SYS_DICT"],
          operator: "EQUAL",
          valueType: "STRING",
          attributeName: "Template Name"
        }
      ];
    },
    nextSort() {
      let data = this.dictionaryOption.data;
      if (data.length) {
        let lastOption = data[data.length - 1];
        return lastOption.attributes["Sort"].value + 1;
      }
      return 1;
    }
  },
  created() {
    this.loadDictionary();
  },
  methods: {
    loadDictionary() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.dictionary = cacheData.dictionary;
        this.dictionaryOption = cacheData.dictionaryOption;
      } else {
        this.loadData(null, null).then(({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.dictionary.data = data.records;
            this.$refs.dictionaryGrid.selectDefault();
          }
        });
      }
    },
    loadData(searchingFields, searchCondition) {
      let requestParam = productApiHelper.getRequestData(
        null,
        this.baseConditions,
        searchCondition,
        {
          attributeName: "Sort",
          _order: true
        },
        searchingFields,
        DATA_TYPES.DICT,
        0,
        0
      );
      return this.$api.request(endpoints.getProductData, requestParam);
    },
    searchDictionary({ searchBy }) {
      this.dictionary.selectedItem = null;
      this.dictionary.searchBy = searchBy;
      this.loadData(this.dictionaryColumns, this.dictionary.searchBy).then(
        ({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.dictionary.data = data.records;
            this.$refs.dictionaryGrid.selectDefault();
          }
        }
      );
    },
    searchOption({ searchBy }) {
      this.dictionaryOption.searchBy = searchBy;
      this.loadData(this.optionColumns, this.dictionaryOption.searchBy).then(
        ({ code, data }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.dictionaryOption.data = data.records;
            this.$refs.optionGrid.selectDefault();
          }
        }
      );
    },
    selectDictionary({ currentItem }) {
      this.dictionary.selectedItem = currentItem;
      this.dictionaryOption.data = [];
      this.dictionaryOption.selectedItem = null;
      this.loadData(null, null).then(({ code, data }) => {
        if (code === RESPONSE_CODE.INFO) {
          this.dictionaryOption.data = data.records;
          this.$refs.optionGrid.selectDefault();
        }
      });
    },
    selectOption({ currentItem, index }) {
      this.dictionaryOption.selectedItem = currentItem;
      this.dictionaryOption.selectedIndex = index;
    },
    moveNewlyAdded() {
      this.dictionaryOption.data.push(
        this.dictionaryOption.data.splice(0, 1)[0]
      );
      this.hasNewInGrid = false;
      this.$refs.optionGrid.selectDefault();
    },
    move(down) {
      let updatingOptions = [];
      let currentOption = this.dictionaryOption.selectedItem;
      let originalSort = this.dictionaryOption.selectedItem.attributes["Sort"]
        .value;
      if (down) {
        let nextOption = this.dictionaryOption.data[
          this.dictionaryOption.selectedIndex + 1
        ];
        currentOption.attributes["Sort"].value = originalSort + 1;
        nextOption.attributes["Sort"].value = originalSort;
        updatingOptions = [currentOption, nextOption];
        this.updateOptions(updatingOptions).then(
          () => {
            this.dictionaryOption.data.splice(
              this.dictionaryOption.selectedIndex + 1,
              1,
              currentOption
            );
            this.dictionaryOption.data.splice(
              this.dictionaryOption.selectedIndex,
              1,
              nextOption
            );
            this.dictionaryOption.selectedIndex++;
          },
          () => {
            currentOption.attributes["Sort"].value = originalSort;
            nextOption.attributes["Sort"].value = originalSort + 1;
          }
        );
      } else {
        let previousOption = this.dictionaryOption.data[
          this.dictionaryOption.selectedIndex - 1
        ];
        previousOption.attributes["Sort"].value = originalSort;
        currentOption.attributes["Sort"].value = originalSort - 1;
        updatingOptions = [previousOption, currentOption];
        this.updateOptions(updatingOptions).then(
          () => {
            this.dictionaryOption.data.splice(
              this.dictionaryOption.selectedIndex - 1,
              1,
              currentOption
            );
            this.dictionaryOption.data.splice(
              this.dictionaryOption.selectedIndex,
              1,
              previousOption
            );
            this.dictionaryOption.selectedIndex--;
          },
          () => {
            currentOption.attributes["Sort"].value = originalSort;
            previousOption.attributes["Sort"].value = originalSort - 1;
          }
        );
      }
    },
    updateOptions(options) {
      let requestData = processApiHelper.getUpdateRequestDataMulti(
        options,
        this.template,
        DATA_TYPES.DICT
      );
      return this.$api.request(endpoints.processProduct, requestData);
    },
    postAdd(record) {
      this.dictionaryOption.data.unshift(record);
      this.hasNewInGrid = true;
      this.$refs.optionGrid.selectDefault();
      this.editor.visible = false;
    },
    postEdit(record) {
      this.$set(record, "_selected", true);
      this.dictionaryOption.data.splice(
        this.dictionaryOption.selectedIndex,
        1,
        record
      );
      this.$refs.optionGrid.selectDefault(this.dictionaryOption.selectedIndex);
      this.editor.visible = false;
    },
    exportProduct(type) {
      let requestParam = productApiHelper.getRequestData(
        null,
        this.exportBaseCondition,
        null,
        {
          attributeName: "Sort",
          _order: true
        },
        null,
        DATA_TYPES.DICT,
        0,
        0
      );
      requestParam = productApiHelper.changeToExportRequestData(
        requestParam,
        type
      );
      this.$api.request(endpoints.getProductData, requestParam).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    },
    doRemove() {
      let delRequestParam = processApiHelper.getDeleteRequestData(
        this.dictionaryOption.selectedItem,
        this.template,
        DATA_TYPES.DICT
      );
      this.$api
        .request(endpoints.processProduct, delRequestParam)
        .then(({ code, messages }) => {
          this.alert.title = code;
          this.alert.visible = true;
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "remove_successfully";
            this.dictionaryOption.data.splice(
              this.dictionaryOption.selectedIndex,
              1
            );
            this.$refs.optionGrid.selectDefault();
          } else {
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    getCacheData() {
      return {
        dictionary: this.dictionary,
        dictionaryOption: this.dictionaryOption
      };
    }
  }
};
</script>

<style scoped>
.frame {
  height: 100%;
}
.dictionary {
  height: 100%;
  width: 50%;
  float: left;
}
.option {
  height: 100%;
  width: calc(50% - 8px);
  width: -ms-calc(50% -8px);
  width: -moz-calc(50% - 8px);
  width: -webkit-calc(50% - 8px);
  float: left;
}
</style>
