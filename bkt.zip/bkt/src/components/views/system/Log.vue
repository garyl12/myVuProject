<template>
  <div class="frame" style="height:100%;">
    <grid
    :columns="columns"
    :data="logs.data"
    :need-index="true"
    :need-pager="true"
    :page-index="logs.pageIndex"
    :page-count="logs.pageCount"
    @next-page="loadDataPaginal"
    @prev-page="loadDataPaginal"
    @jump-page="loadDataPaginal"
    ref="logGrid"
    >
    <button-bar :buttons="buttons" />
    </grid>
    <searcher
      :visible="searcher.visible"
      :fields="searchableFields"
      :conditions="logs.searchBy"
       @search="loadDataPaginal"
      @close="searcher.visible=false"
      />
    <file-downloader
      :src=downloader.src
      :visible="downloader.visible"
      :file-types="fileTypes"
      @select-type="exportLog"
      @close="downloader.visible=false"
      /> 
  </div>

</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Searcher from "@/components/common/Searcher";
import Alert from "@/components/common/Alert";
import FileDownloader from "@/components/common/FileDownloader";
import { mapGetters } from "vuex";
import {
  EDITOR_STATUS,
  DATA_TYPES,
  RESPONSE_CODE,
  DEFAULT,
  FILE_TYPES
} from "@/consts";
import { getViewName,assembleDownloadUrl } from "@/utils";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints";

export default {
  name: "LogManagement",
  components: { Grid, ButtonBar, Searcher, Alert, FileDownloader },
  data() {
    return {
      logs: {
        data: [],
        pageIndex: 0,
        pageCount: 0,
        sortBy: null,
        searchBy: null,
        selectedItem: null,
        selectedIndex: -1
      },
      requestParameters: {},
      searcher: {
        visible: false
      },
      downloader: {
        src: "",
        visible: false
      },
      alert: {
        visible: false,
        title: "information",
        message: "",
        logs: [],
        buttons: [
          {
            title: "ok",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      attributes: "getAttributes",
      templates: "getTemplates",
      views: "getViews",
      currentNav: "getCurrentNav"
    }),
    fileTypes() {
      return FILE_TYPES;
    },
    template() {
      return this.templates[this.currentNav.templateFilter] || null;
    },
    buttons() {
      return [
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.searcher.visible = true;
          }
        },
        {
          icon: "icon-daochu",
          active: this.logs.data.length > 0,
          text: "export",
          callback: () => {
            this.downloader.visible = true;
          }
        }
      ];
    },
    columns() {
      let columns = [];
      if (DEFAULT in this.views) {
        let viewName =
          getViewName(this.currentNav.id, this.mapping, this.views) || DEFAULT;
        let columnNames = this.views[viewName][0].attributesInMainGrid;
        columnNames.split(";").forEach(header => {
          columns.push(
            this.attributes[header] || {
              displayName: header,
              attributeName: header
            }
          );
        });
      }
      return columns;
    },
    searchableFields() {
      let fields = [];
      (this.template || { measures: [] }).measures.forEach(measure => {
        if (measure.searchAble) {
          fields.push(measure);
        }
      });
      return fields;
    },
    baseConditions() {
      return [
        {
          attributeName: "Template Name",
          searchValues: ["SYS_MAS_LOG"]
        }
      ];
    }
  },
  mounted() {
    this.loadDataPaginal({});
  },
  methods: {
    loadDataPaginal({ searchBy, sortBy, pageIndex = 1 }) {
      if (searchBy) this.logs.searchBy = searchBy;
      if (sortBy) this.logs.sortBy = sortBy;
      this.logs.pageIndex = pageIndex || 1;
      let params = productApiHelper.getRequestData(
        null,
        this.baseConditions,
        this.logs.searchBy,
        this.logs.sortBy,
        null,
        DATA_TYPES.LOG,
        this.logs.pageIndex
      );
      this.requestParameters = params;
      this.$api
        .request(endpoints.getProductData, params)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.logs.data = data.records;
            this.logs.pageCount = Math.ceil(data.recordCount / data.pageSize);
            if (data.records.length && this.searcher.visible)
              this.searcher.visible = false;
          } else {
            this.alert.message = "";
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        });
    },
    exportLog(type) {
      let exportParameters = productApiHelper.changeToExportRequestData(
        this.requestParameters,
        type
      );
      this.$api.request(endpoints.getProductData, exportParameters).then(
        ({ code, data, messages }) => {
          this.downloader.visible = false;
          if (code === RESPONSE_CODE.INFO) {
            if (data.contentUrl) {
              this.downloader.src = assembleDownloadUrl({
                fileName: data.contentUrl
              });
            }
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        },
        () => {
          this.downloader.visible = false;
        }
      );
    }
  }
};
</script>

<style scoped>
</style>