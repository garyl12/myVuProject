<template>
<el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-inner">
      <editor-logger :logs="logs" />
      <div v-for="(category, index) in fieldCategories" :key="index">
        <div class="section">
          <span class="category-title">{{$t_(category.groupName)}}</span>
        </div>
        <fields-renderer
          :fields="category.fields"
          :entry="entry"
          :adding="isAdding"
          ref="fieldsRenderer"
        />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button type="primary" @click="cancel">{{$t_("cancel")}}</el-button>
		</div>
    <alert :config="alert" />
  </el-dialog>
</template>

<script>
import Alert from "@/components/common/Alert";
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import { mapGetters } from "vuex";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import { getEditorTitle, autoCompleteFields, clone, guid } from "@/utils";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import endpoints from "@/api/endpoints";
import {
  EDITOR_STATUS,
  RESPONSE_CODE,
  DATA_TYPES,
  FIELD_TYPES
} from "@/consts";

export default {
  name: "currencyEditor",
  components: { FieldsRenderer, EditorLogger, Alert },
  props: {
    visible: {
      type: Boolean,
      required: true
    },
    status: {
      type: Number,
      required: true
    },
    currency: Object
  },
  data() {
    return {
      alert: {
        visible: false,
        title: "",
        message: "",
        logs: "",
        buttons: [
          {
            title: "OK",
            callback: () => {}
          }
        ]
      },
      logs: [],
      entry: {}
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates"
    }),
    template() {
      return this.templates["CURRENCY"];
    },
    fieldCategories() {
      let categories = [];
      if (this.template) {
        categories = assembleTemplateCategories(this.template, this.$api);
      }
      return categories;
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    },
    baseConditions() {
      return [
        {
          attributeName: "ID",
          searchValues: [this.entry.attributes["ID"].value]
        },
        {
          searchValues: ["CURRENCY"],
          attributeName: "Template Name"
        }
      ];
    },
    title() {
      return getEditorTitle(this.status);
    }
  },
  watch: {
    visible() {
      if (this.visible) {
        this.reset();
      }
    }
  },
  methods: {
    cancel() {
      this.reset();
      this.$emit("close");
    },
    validate() {
      let invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    validateID() {
      if (this.isAdding) {
        let requestData = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.CURRENCY,
          1,
          -1
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert = {
                visible: true,
                title: "warning",
                message: "id_duplicated",
                buttons: [
                  {
                    title: "OK",
                    callback: () => {
                      this.alert.visible = false;
                    }
                  }
                ],
                logs: []
              };
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    save() {
      if (this.validate()) {
        this.validateID().then(() => {
          this.sendRequest(this.entry).then(record => {
            let event = this.status === EDITOR_STATUS.ADDING ? "add" : "edit";
            this.$emit(event, record);
          });
        }).catch()
      }
    },
    sendRequest(entry) {
      let requestData = processApiHelper.getUpdateRequestData(
        entry,
        this.template,
        DATA_TYPES.CURRENCY
      );
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data[0]);
          } else {
            return Promise.reject();
          }
        },
        _ => {
          return Promise.reject();
        }
      );
    },
    reset() {
      this.logs = [];
      this.entry = autoCompleteFields(
        this.isAdding ? { attributes: {} } : clone(this.currency),
        this.template,
        this.isAdding
      );
    }
  }
};
</script>

<style scoped>
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  height: calc(100% - 20px);
  border: 1px solid #ccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>