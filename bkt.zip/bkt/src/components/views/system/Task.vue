<template>
  <div style="height: 100%">
    <grid
      :columns="columns"
      :data="grid.data"
      :need-index="true"
      :need-pager="true"
      :page-index="grid.pageIndex"
      :page-count="grid.pageCount"
      @select="selectEntry"
      @next-page="loadDataPaginal"
      @prev-page="loadDataPaginal"
      @jump-page="loadDataPaginal"
      ref="grid"
      >
      <button-bar :buttons="buttons" />
    </grid>
    <searcher
      :visible="searcher.visible"
      :fields="searchableFields"
      :conditions="grid.searchBy"
      @close="searcher.visible=false"
      />
    <task-editor
      :visible="editor.visible"
      :status="editor.status"
      :selected-entry="grid.selectedItem"
      @close="editor.visible=false"
      @add="postAdd"
      @clone="postAdd"
      @edit="postEdit"
      />
    <alert :config="removeConfirmation" />
    <alert :config="alert" />
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Searcher from "@/components/common/Searcher";
import Alert from "@/components/common/Alert";
import TaskEditor from "./TaskEditor";
import { mapGetters } from "vuex";
import { EDITOR_STATUS, DATA_TYPES, RESPONSE_CODE } from "@/consts";
import mixin from "../mixin";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import endpoints from "@/api/endpoints";

export default {
  name: "TaskManagement",
  components: { Grid, ButtonBar, Searcher, TaskEditor, Alert },
  mixins: [mixin],
  data() {
    return {
      grid: {
        data: [],
        pageIndex: 0,
        pageCount: 0,
        sortBy: null,
        searchBy: null,
        selectedItem: null,
        selectedIndex: -1
      },
      searcher: {
        visible: false
      },
      editor: {
        visible: false,
        status: -1
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeConfirmation.visible = false;
              this.doRemove();
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
      alert: {
        visible: false,
        title: "information",
        message: "",
        logs: [],
        buttons: [
          {
            title: "ok",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      views: "getViews",
      attributes: "getAttributes"
    }),
    template() {
      return this.templates["TASK_SCHEDULE_JOB"];
    },
    columns() {
      let columns = [];
      if (this.views["TASK_SCHEDULE_JOB"]) {
        (this.views["TASK_SCHEDULE_JOB"][0].attributesInMainGrid || "")
          .split(";")
          .forEach(attr => {
            if (this.attributes[attr]) {
              columns.push(this.attributes[attr]);
            } else {
              columns.push({
                displayName: attr,
                attributeName: attr
              });
            }
          });
      }
      return columns;
    },
    searchableFields() {
      let fields = [];
      if (this.template) {
        this.template.measures.forEach(measure => {
          if (measure.searchAble) {
            fields.push(measure);
          }
        });
      }
      return fields;
    },
    buttons() {
      return [
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.searcher.visible = true;
          }
        },
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active: this.grid.selectedIndex > -1,
          text: "edit",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-fuzhi",
          active: this.grid.selectedIndex > -1,
          text: "clone",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.CLONING;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.grid.selectedIndex > -1,
          text: "delete",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        },
        {
          icon: "icon-triangleR",
          active: this.grid.selectedIndex > -1,
          text: "start",
          callback: () => {
            this.startTask();
          }
        },
        {
          icon: "icon-stop",
          active: this.grid.selectedIndex > -1,
          text: "pause",
          callback: () => {
            this.pauseTask();
          }
        },
        {
          icon: "icon-reset",
          active: this.grid.selectedIndex > -1,
          text: "resume",
          callback: () => {
            this.resumeTask();
          }
        },
        {
          icon: "icon-terminate",
          active: this.grid.selectedIndex > -1,
          text: "terminate",
          callback: () => {
            this.terminateTask();
          }
        }
      ];
    },
    baseConditions() {
      return [
        {
          attributeName: "Del Flag",
          searchValues: ["0"]
        },
        {
          attributeName: "System Name",
          searchValues: ["MAS"]
        },
        {
          attributeName: "Template Name",
          searchValues: ["TASK_SCHEDULE_JOB"]
        }
      ];
    }
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      if (this.cache[this.$route.path]) {
        this.grid = JSON.parse(this.cache[this.$route.path]);
      } else {
        let requestParameters = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.TASK,
          1
        );
        this.requestData(requestParameters);
      }
    },
    loadDataPaginal({ sortBy, searchBy, pageIndex = 1 }) {
      this.grid.sortBy = sortBy || this.grid.sortBy;
      this.grid.searchBy = searchBy || this.grid.searchBy;
      this.grid.pageIndex = pageIndex;
      let requestParameters = productApiHelper.getRequestData(
        null,
        this.baseConditions,
        this.grid.searchBy,
        this.grid.sortBy,
        null,
        DATA_TYPES.TASK,
        pageIndex
      );
      this.requestData(requestParameters);
    },
    requestData(requestParameters) {
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ data }) => {
          this.grid.pageCount = Math.ceil(data.recordCount / data.pageSize);
          this.grid.data = data.records;
          if (data.recordCount) {
            this.$refs.grid.selectDefault();
            this.searcher.visible = false;
          } else {
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          }
        });
    },
    selectEntry({ currentItem, index }) {
      this.grid.selectedItem = currentItem;
      this.grid.selectedIndex = index;
    },
    postAdd(record) {
      this.grid.data.unshift(record);
      this.$nextTick(() => {
        this.$refs.grid.selectDefault();
      });
      this.editor.visible = false;
      if (!this.grid.pageCount) this.grid.pageCount = 1;
    },
    postEdit(record) {
      this.$set(record, "_selected", true);
      this.grid.data.splice(this.grid.selectedIndex, 1, record);
      this.grid.selectedItem = record;
      this.editor.visible = false;
    },
    doRemove() {
      let requestData = processApiHelper.getDeleteRequestData(
        this.grid.selectedItem,
        this.template,
        DATA_TYPES.TASK
      );
      this.$api
        .request(endpoints.processProduct, requestData)
        .then(({ code, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.grid.data.splice(this.grid.selectedIndex, 1);
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    startTask() {
      this.$api
        .request(endpoints.startTask, {
          taskId: this.grid.selectedItem.attributes["Task ID"].value,
          groupName: this.grid.selectedItem.attributes["Group Name"].value
        })
        .then(({ code, messages }) => {
          this.alert.visible = true;
          this.alert.title = code;
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "task_started";
          } else {
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    pauseTask() {
      this.$api
        .request(endpoints.pauseTask, {
          taskId: this.grid.selectedItem.attributes["Task ID"].value,
          groupName: this.grid.selectedItem.attributes["Group Name"].value
        })
        .then(({ code, messages }) => {
          this.alert.visible = true;
          this.alert.title = code;
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "task_paused";
          } else {
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    resumeTask() {
      this.$api
        .request(endpoints.resumeTask, {
          taskId: this.grid.selectedItem.attributes["Task ID"].value,
          groupName: this.grid.selectedItem.attributes["Group Name"].value
        })
        .then(({ code, messages }) => {
          this.alert.visible = true;
          this.alert.title = code;
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "task_resumed";
          } else {
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    terminateTask() {
      this.$api
        .request(endpoints.terminateTask, {
          taskId: this.grid.selectedItem.attributes["Task ID"].value,
          groupName: this.grid.selectedItem.attributes["Group Name"].value
        })
        .then(({ code, messages }) => {
          this.alert.visible = true;
          this.alert.title = code;
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "task_terminated";
          } else {
            this.alert.message = "";
            this.alert.logs = messages;
          }
        });
    },
    resize() {
      this.$refs.grid.resize();
    },
    getCacheData() {
      return this.grid;
    }
  }
};
</script>

<style scoped>
</style>