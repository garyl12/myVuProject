<template>
  <div style="height: 100%">
    <grid
      :columns="columns"
      :data="grid.data"
      :need-index="true"
      :need-searcher="true"
      :condition="grid.searchBy"
      @search="searchCurrency"
      @select="selectCurrency"
      ref="grid">
      <button-bar :buttons="buttons" />
    </grid>
    <currency-editor
      :visible="editor.visible"
      :status="editor.status"
      :selected-entry="grid.selectedItem"
      :currency="grid.selectedItem"
      @close="editor.visible=false"
      @add="postAdd"
      @edit="postEdit"
      />
    <alert :config="removeConfirmation" />
  </div>
</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import CurrencyEditor from "./CurrencyEditor";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import endpoints from "@/api/endpoints";
import mixin from "../mixin";
import {
  EDITOR_STATUS,
  DATA_TYPES,
  RESPONSE_CODE
} from "@/consts";

export default {
  name: "CurrencyManagement",
  components: { Grid, ButtonBar, CurrencyEditor, Alert },
  mixins: [mixin],
  data() {
    return {
      grid: {
        data: [],
        selectedItem: null,
        selectedIndex: null,
        searchBy: null
      },
      editor: {
        visible: false,
        status: -1
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeConfirmation.visible = false;
              this.doRemove();
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      },
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      views: "getViews",
      attributes: "getAttributes"
    }),
    template() {
      return this.templates["CURRENCY"];
    },
    columns() {
      let columns = [
        {
          attributeName: "ID",
          displayName: "ID"
        },
        {
          attributeName: "Currency Name",
          displayName: "Currency Name"
        },
        {
          attributeName: "Currency Code",
          displayName: "Currency Code"
        }
      ];

      return columns;
    },
    baseConditions() {
      return [
        {
          searchValues: ["CURRENCY"],
          attributeName: "Template Name"
        }
      ];
    },
    buttons() {
      return [
       {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.ADDING;
          }
        },
        {
          icon: "icon-bianji",
          active: this.grid.selectedIndex > -1,
          text: "edit",
          callback: () => {
            this.editor.visible = true;
            this.editor.status = EDITOR_STATUS.EDITING;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.grid.selectedIndex > -1,
          text: "delete",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        }
      ]
    }
  },
  created() {
    this.loadData(null, null);
  },
  methods: {
    loadData(searchingFields, searchCondition) {
      if (this.cache[this.$route.path]) {
        this.grid = JSON.parse(this.cache[this.$route.path]);
      } else {
        let requestParameters = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          searchCondition,
          null,
          searchingFields,
          DATA_TYPES.CURRENCY,
          1,
          -1
        );
        this.requestData(requestParameters);
      }
    },
    requestData(requestParameters) {
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ data }) => {
          this.grid.data = data.records;
          if (data.recordCount) {
            this.$refs.grid.selectDefault();
          } else {
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          }
        });
    },
    searchCurrency({ searchBy }) {
      this.grid.selectedItem = null;
      this.grid.searchBy = searchBy;
      this.loadData(this.columns, searchBy);
    },
    selectCurrency({ currentItem, index }) {
      this.grid.selectedItem = currentItem;
      this.grid.selectedIndex = index;
    },
    postAdd(record) {
      this.grid.data.unshift(record);
      this.hasNewInGrid = true;
      this.$refs.grid.selectDefault();
      this.editor.visible = false;
    },
    postEdit(record) {
      this.$set(record, "_selected", true);
      this.grid.data.splice(
        this.grid.selectedIndex,
        1,
        record
      );
      this.$refs.grid.selectDefault(this.grid.selectedIndex);
      this.editor.visible = false;
    },
    doRemove() {
      let delRequestParam = processApiHelper.getDeleteRequestData(
        this.grid.selectedItem,
        this.template,
        DATA_TYPES.CURRENCY
      );
      this.$api
        .request(endpoints.processProduct, delRequestParam)
        .then(({ code, messages }) => {
          this.alert = {
            visible: true,
            title: code,
            message: "",
            buttons: [
              {
                title: "OK",
                callback: () => {
                  this.alert.visible = false;
                }
              }
            ],
            logs: []
          };
          if (code === RESPONSE_CODE.INFO) {
            this.alert.message = "remove_successfully";
            this.grid.data.splice(this.grid.selectedIndex, 1);
            this.$refs.grid.selectDefault();
          } else {
            this.alert.logs = messages;
          }
        });
    },
    getCacheData() {}
  }
};
</script>

<style scoped>
</style>