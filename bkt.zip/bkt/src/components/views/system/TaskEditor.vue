<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-inner">
      <editor-logger :logs="logs" />
      <div class="section">
        <span class="category-title">{{$t_("generic")}}</span>
      </div>
      <fields-renderer
        :fields="fields"
        :entry="entry"
        :adding="isAdding"
        ref="taskFieldsRenderer"
      />
      <div v-show="refTemplateFields.length">
        <div class="section">
          <span class="category-title">{{$t_("ref_task_params")}}</span>
        </div>
        <fields-renderer
          :fields="refTemplateFields"
          :entry="taskParamEntry"
          :adding="true"
          :is-data-bean="true"
          ref="paramFieldsRenderer"
          />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
		</div>
    <alert :config="alert" />
  </el-dialog>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import { generateReferenceSelectorOption } from "@/components/sections/FieldsRenderer";
import { getEditorTitle, autoCompleteFields, clone, guid } from "@/utils";
import processApiHelper from "@/utils/processApiHelper";
import endpoints from "@/api/endpoints";
import {
  EDITOR_STATUS,
  RESPONSE_CODE,
  DATA_TYPES,
  FIELD_TYPES
} from "@/consts";

export default {
  name: "TaskEditor",
  components: { FieldsRenderer, Alert, EditorLogger },
  props: {
    visible: {
      type: Boolean,
      required: true
    },
    status: {
      type: Number,
      required: true
    },
    selectedEntry: Object
  },
  data() {
    return {
      entry: {},
      taskParamEntry: {},
      logs: [],
      fields: [],
      alert: {
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates"
    }),
    template() {
      return this.templates["TASK_SCHEDULE_JOB"];
    },
    title() {
      return getEditorTitle(this.status);
    },
    isAdding() {
      return (
        this.status === EDITOR_STATUS.ADDING ||
        this.status === EDITOR_STATUS.CLONING
      );
    },
    refTemplate() {
      let template = null;
      if (
        this.entry.attributes &&
        this.entry.attributes["Ref Task Template Name"].value
      ) {
        template = this.templates[
          this.entry.attributes["Ref Task Template Name"].value
        ];
      }
      return template;
    },
    refTemplateFields() {
      let fields = [];
      this.taskParamEntry = {};
      if (this.refTemplate) {
        let taskParamField = null;
        this.refTemplate.measures.forEach(measure => {
          if (measure.name === "Task Parameters") {
            taskParamField = measure;
          }
        });
        if (taskParamField) {
          taskParamField.subMeasures.forEach(measure => {
            measure.visible = true;
            measure.editableInNew = true;
            measure.driveExt = () => {
              this.assembleTaskParams();
            };
            fields.push(measure);
          });
        }
      }
      if (this.entry.attributes) {
        let taskParams = this.entry.attributes["Task Params"].value;
        if (taskParams) {
          let keys = [],
            values = [];
          taskParams.split(";").forEach((item, index) => {
            if (index) {
              // parameter value
              values = item.split(",");
            } else {
              // parameter name
              keys = item.split(",");
            }
          });
          keys.forEach((key, index) => {
            this.$set(this.taskParamEntry, key, values[index]);
          });
        }
      }
      return fields;
    }
  },
  watch: {
    visible() {
      if (this.visible) {
        this.reset();
        this.initFields();
      }
    }
  },
  methods: {
    initFields() {
      if (!this.fields.length) {
        this.template.measures.forEach(measure => {
          if (
            !measure.visible ||
            measure.dataType === FIELD_TYPES.TABLE ||
            measure.dataType === FIELD_TYPES.SURFACE
          )
            return;
          if (!measure.groupName) return;
          let field = clone(measure);
          if (measure.name === "Task Params") {
            field.editableInNew = false;
            field.editableInEdit = false;
          } else if (field.name === "Ref Task Template Name") {
            field.reference = true;
            field.options = this.generateFieldOption();
            field.driveExt = template => {
              this.initTaskParamSection(template);
            };
          } else if (field.reference) {
            field.options = generateReferenceSelectorOption(field, this.$api);
          }
          this.fields.push(field);
        });
      }
    },
    initTaskParamSection(refTemplate) {
      this.entry.attributes["Task Params"].value = "";
    },
    generateFieldOption() {
      let option = {
        columns: [
          {
            attributeName: "templateName",
            displayName: "templateName",
            width: 150
          },
          {
            attributeName: "jobName",
            displayName: "jobName",
            width: 150
          },
          {
            attributeName: "jobDesc",
            displayName: "jobDesc",
            width: 150
          }
        ],
        refAttribute: "templateName"
      };
      let templates = [];
      option.resolver = searchingCondition => {
        if (templates.length) {
          return new Promise(resolve => {
            let tempTemplates = [];
            templates.forEach(template => {
              if (
                searchingCondition.templateId &&
                template.templateId.indexOf(searchingCondition.templateId) > -1
              ) {
                tempTemplates.push(template);
              } else if (
                searchingCondition.jobName &&
                template.jobName.indexOf(searchingCondition.jobName) > -1
              ) {
                tempTemplates.push(template);
              } else if (
                searchingCondition.jobDesc &&
                template.jobDesc.indexOf(searchingCondition.jobDesc) > -1
              ) {
                tempTemplates.push(template);
              } else {
                tempTemplates.push(template);
              }
            });
            let pageCount = Math.ceil(tempTemplates / 10);
            resolve({
              data: tempTemplates,
              pageCount
            });
          });
        } else {
          return this.$api.request(endpoints.getTaskRefTemplate, {}).then(
            ({ data }) => {
              templates = data;
              let tempTemplates = [];
              templates.forEach(template => {
                if (searchingCondition.name) {
                  if (template.name.indexOf(searchingCondition.name) !== -1) {
                    tempTemplates.push(template);
                  }
                } else {
                  tempTemplates.push(template);
                }
              });
              let pageCount = Math.ceil(tempTemplates / 10);
              return Promise.resolve({
                data: tempTemplates,
                pageCount
              });
            },
            _ => {
              return Promise.resolve({
                data: [],
                pageCount: 0
              });
            }
          );
        }
      };
      return option;
    },
    assembleTaskParams() {
      let keys = [],
        values = [];
      for (let key in this.taskParamEntry) {
        keys.push(key);
        values.push(this.taskParamEntry[key]);
      }
      if (keys.length) {
        this.entry.attributes["Task Params"].value = [
          keys.join(","),
          values.join(",")
        ].join(";");
      }
    },
    validate() {
      let invalidFields = [];
      if (this.refTemplateFields.length) {
        let temp = this.$refs.paramFieldsRenderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      }
      let temp = this.$refs.taskFieldsRenderer.validate();
      if (!temp.isValid) {
        invalidFields = invalidFields.concat(temp.invalidFields);
      }
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    save() {
      if (this.validate()) {
        this.sendRequest(this.entry).then(record => {
          let event =
            this.status === EDITOR_STATUS.ADDING
              ? "add"
              : this.status === EDITOR_STATUS.EDITING ? "edit" : "clone";
          this.$emit(event, record);
        });
      }
    },
    sendRequest(entry) {
      let requestData = processApiHelper.getUpdateRequestData(
        entry,
        this.template,
        DATA_TYPES.TASK
      );
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data[0]);
          } else {
            return Promise.reject();
          }
        },
        _ => {
          return Promise.reject();
        }
      );
    },
    reset() {
      this.logs = [];
      this.entry =
        this.status === EDITOR_STATUS.ADDING
          ? autoCompleteFields(
              { attributes: { ID: { value: guid() } } },
              this.template,
              true
            )
          : autoCompleteFields(clone(this.selectedEntry), this.template);
    },
    close() {
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  height: calc(100% - 20px);
  border: 1px solid #ccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>