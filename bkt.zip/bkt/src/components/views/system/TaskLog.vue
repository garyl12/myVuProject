<template>
  <grid
    :data="grid.data"
    :columns="columns"
    :need-index="true"
    :need-pager="true"
    :condition="grid.searchBy"
    :page-count="grid.pageCount"
    :page-index="grid.pageIndex"
    :need-searcher="true"
    @next-page="loadDataPaginal"
    @prev-page="loadDataPaginal"
    @jump-page="loadDataPaginal"
    >
      <button-bar :buttons="[]" />
    </grid>
</template>

<script>
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import { DATA_TYPES } from "@/consts";
import mixin from "../mixin";

export default {
  name: "TaskLog",
  components: { Grid, ButtonBar },
  mixins: [mixin],
  computed: {
    ...mapGetters({
      views: "getViews"
    }),
    view() {
      return this.views["TASK_SCHEDULE_JOB_LOG"];
    },
    columns() {
      let columns = [];
      if (this.view) {
        this.view[0].attributesInMainGrid.split(";").forEach(attr => {
          columns.push({
            attributeName: attr,
            displayName: attr
          });
        });
      }
      return columns;
    },
    baseConditions() {
      return [
        {
          attributeName: "Template Name",
          searchValues: ["TASK_SCHEDULE_JOB_LOG"]
        }
      ];
    }
  },
  data() {
    return {
      grid: {
        data: [],
        pageCount: 0,
        pageIndex: 0
      }
    };
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      if (this.cache[this.$route.path]) {
        this.grid = JSON.parse(this.cache[this.$route.path]);
      } else {
        let requestParameters = productApiHelper.getRequestData(
          null,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.TASK,
          1
        );
        this.requestData(requestParameters);
      }
    },
    loadDataPaginal({ searchBy, pageIndex = 1 }) {
      this.grid.searchBy = searchBy || this.grid.searchBy;
      this.grid.pageIndex = pageIndex;
      let requestParameters = productApiHelper.getRequestData(
        null,
        this.baseConditions,
        this.grid.searchBy,
        this.grid.sortBy,
        null,
        DATA_TYPES.TASK,
        pageIndex
      );
      this.requestData(requestParameters);
    },
    requestData(requestParameters) {
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ data }) => {
          this.grid.pageCount = Math.ceil(data.recordCount / data.pageSize);
          this.grid.data = data.records;
          if (data.recordCount) {
            this.$refs.grid.selectDefault();
            this.searcher.visible = false;
          } else {
            this.grid.selectedIndex = -1;
            this.grid.selectedItem = null;
          }
        });
    },
    getCacheData() {
      return this.grid;
    }
  }
};
</script>

<style scoped>
</style>