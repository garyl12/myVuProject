<template>
  <div class="wrap clearfix">
      <div class="right-wrap">
          <div class="aside-title">
                <div >
                  <h3>{{display.asideTitle}}</h3>
                </div>
          </div>
          <div class="aside-content">
              <div class="aside-actions">
                  <span class="btn btn-white" @click="edit" v-show="!isAdd&&!isEdit">{{display.editBtn}}</span>
                  <span class="btn btn-white" @click="add" v-show="!isAdd&&!isEdit">{{display.addBtn}}</span>
                  <span class="btn btn-white" v-show="isAdd||isEdit" @click="confirm">{{display.confirmBtn}}</span>
                  <span class="btn btn-white" v-show="isAdd||isEdit" @click="cancel">{{display.cancelBtn}}</span>
              </div>      
              <div class="aside-field-wrap">
                  <div class="inner-title">
                      <span ><i class="iconfont icon-acountInfo"></i></span>
                      <h3>{{display.asideInnerTitle}}</h3>
                  </div>
                  <div class="aside-fields">
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.code}}</span> :</label>
                        <input  class="field-cell-edit" type="text"  v-show="isAdd" v-model="newAccount.userNo" @blur="validate('userNo')">
                        <p class="field-cell-detail" v-show="isEdit" v-html="editAccount.userNo"></p>
                        <p class="field-cell-detail" v-show="!isEdit&&!isAdd">{{currentAccount.userNo}}</p>
                        <span v-show="isAdd">
                          <i class="required" v-show="!valite.userNo">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.userNo"></i>
                        </span>
                    </div>
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.name}}</span> :</label>
                        <input  class="field-cell-edit" type="text"  v-show="isAdd" v-model="newAccount.name" @blur="validate('name')">
                        <input  class="field-cell-edit" type="text"  v-show="isEdit" v-model="editAccount.name" @blur="validate('name')">
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit" >{{currentAccount.name}}</p>
                        <span v-show="isAdd">
                          <i class="required" v-show="!valite.name">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.name"></i>
                        </span>
                        <span v-show="isEdit">
                          <i class="required" v-show="valite.name">*</i>
                          <i class="iconfont warning icon-warning" v-show="!valite.name"></i>
                        </span>
                    <div class="field-item">
                    </div>
                        <label><span class="cell-name">{{display.account.dept}}</span> :</label>
                        <input  class="field-cell-edit" type="text" @focus="chooseDept"  v-show="isAdd" v-model="newAccount.orgName">
                        <input  class="field-cell-edit" type="text" @focus="chooseDept"  v-show="isEdit" v-model="editAccount.orgName">
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit" >{{currentAccount.orgName}}</p>
                        <span v-show="isAdd">
                          <i class="required" v-show="!valite.organization">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.organization"></i>
                        </span>
                        <span v-show="isEdit">
                          <i class="required" v-show="valite.organization">*</i>
                          <i class="iconfont warning icon-warning" v-show="!valite.organization"></i>
                        </span>
                    </div>
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.leader}}</span> :</label>
                        <select class="field-cell-edit"  value="1"  v-show="isEdit" v-model="editAccount.leaderId">
                          <option v-for="item in leaderList" :value="item.id" :key="item.id">{{item.name}}</option>
                        </select>
                        <select class="field-cell-edit"  value="1"  v-show="isAdd" v-model="newAccount.leaderId">
                          <option v-for="item in leaderList" :value="item.id" :key="item.id">{{item.name}}</option>
                        </select>
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.leaderName}}</p>
                    </div>
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.phone}}</span> :</label>
                        <input  class="field-cell-edit" type="text"  v-show="isAdd" v-model="newAccount.phone">
                        <input  class="field-cell-edit" type="text"  v-show="isEdit" v-model="editAccount.phone">
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.phone}}</p>
                    </div>
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.mobile}}</span> :</label>
                        <input  class="field-cell-edit" type="text"  v-show="isAdd" v-model="newAccount.mobile" @blur="validate('mobile')">
                        <input  class="field-cell-edit" type="text"  v-show="isEdit" v-model="editAccount.mobile" @blur="validate('mobile')">
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.mobile}}</p>
                        <span v-show="isAdd">
                          <i class="required" v-show="!valite.mobile">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.mobile"></i>
                        </span>
                        <span v-show="isEdit">
                          <i class="required" v-show="valite.mobile">*</i>
                          <i class="iconfont warning icon-warning" v-show="!valite.mobile"></i>
                        </span>
                    </div>
                    <div class="field-item">
                        <label><span class="cell-name">{{display.account.email}}</span> :</label>
                        <input  class="field-cell-edit" type="text"  v-show="isAdd" v-model="newAccount.email"  @blur="validate('email')">
                        <input  class="field-cell-edit" type="text"  v-show="isEdit" v-model="editAccount.email"  @blur="validate('email')">
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.email}}</p>
                        <span v-show="isAdd">
                          <i class="required" v-show="!valite.email">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.email"></i>
                        </span>
                        <span v-show="isEdit">
                          <i class="required" v-show="valite.email">*</i>
                          <i class="iconfont warning icon-warning" v-show="!valite.email"></i>
                        </span>
                    </div>
                     <div class="field-item">
                        <label><span class="cell-name">{{display.account.state}}</span> :</label>
                        <select class="field-cell-edit"  v-show="isAdd" v-model="newAccount.status">
                          <option value="0">{{display.account.userState.enable}}</option>
                          <option value="1">{{display.account.userState.disable}}</option>
                        </select>
                        <select class="field-cell-edit"  v-show="isEdit" v-model="editAccount.status">
                          <option value="0">{{display.account.userState.enable}}</option>
                          <option value="1">{{display.account.userState.disable}}</option>
                        </select>
                        <p class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.statusFormatter}}</p>
                    </div>
                    <div class="field-item">
                        <label v-show="isAdd"><span class="cell-name">{{display.account.originPassword}}</span> :</label>
                        <label v-show="!isAdd"><span class="cell-name">{{display.account.resetPassword}}</span> :</label>
                        <input  class="field-cell-edit" type="text" v-show="isAdd" v-model="newAccount.password"  @blur="validate('password')">
                        <p class="field-cell-detail" v-show="!isAdd"><a href="javascript:;" @click="goResetPassword" class="resetPassword" >{{display.account.resetPassword}}</a></p>    
                        <span v-show="isAdd">
                          <i class="required">*</i>
                          <i class="iconfont warning icon-warning" v-show="valite.password"></i>
                        </span>
                    </div>
                     <div class="field-item role-names">
                        <label><span class="cell-name">{{display.account.role}}</span> :</label>
                        <div class="field-cell-edit" v-show="isEdit">{{editAccount.roleNames}}</div>
                        <div class="field-cell-edit" v-show="isAdd">{{newAccount.roleNames}}</div>
                        <div class="field-cell-detail" v-show="!isAdd&&!isEdit">{{currentAccount.roleNames}}</div>
                    </div>
                    <div class="field-item select-role-btn" v-show = "isAdd||isEdit">
                        <span @click="editRole">+</span>
                    </div>
                  </div>
              </div>
          </div>
      </div>
       <div class="left-wrap">
         <div class="user-content">
            <div class="account-table">
              <grid
                :need-index="true"
                :need-column-checker ="true"
                :searcher-placeholder="display.table.accountPlaceholder"
                :columns="account.gridColumns"
                :data="account.data"
                :page-count="account.pageCount"
                @jump-page="accountPageGo" 
                @prev-page="accountPageGo" 
                @next-page="accountPageGo"
                @search="accountSearch"
                @check-all="accountCheckAll"
                @check="accountCheckRow"
                @select="accountSelectRow"
              >
                <span class="btn btn-dark" @click="add">{{display.table.buttons.add}}</span>
                <span class="btn btn-dark" @click="remove">{{display.table.buttons.delete}}</span>
                <span class="btn btn-dark" @click="changeAccountStatus('enable')">{{display.account.userState.enable}}</span>
                <span class="btn btn-dark" @click="changeAccountStatus('disable')">{{display.account.userState.disable}}</span>
              </grid>
           </div>
         </div>
          <div class="v-drag" onselectstart="return false;" @mousedown="bindDrag($event)">
            <div class="mid" onselectstart="return false;"></div>
            <div class="v-drag-shadow" onselectstart="return false;"><div onselectstart="return false;"></div></div>
          </div>
         <div class="log-content">
          <div class="log-table">
              <grid
                :need-index="true"
                :need-searcher="true"
                :searcher-placeholder="display.table.logPlaceholder"
                :columns="logInfo.gridColumns"
                :data="logInfo.data"
                :page-count="logInfo.pageCount"
                @jump-page="logPageGo" 
                @prev-page="logPageGo" 
                @next-page="logPageGo"
                @search="logSearch"
              >
             <div class="grid-top-item title">
               <span class="log-title" v-html="logTitle"></span>
             </div>
             <div class="grid-top-item date">
                <label>{{display.dateLabel}}:</label>
                 <el-date-picker
                    v-model="logInfo.startDate"
                    align="left"
                    type="date" 
                    size="small"
                    @change="getTime"
                    :placeholder="display.startDate"
                    :picker-options="logInfo.startPickerOptions"
                    >
                  </el-date-picker>
             </div>
             <div class="grid-top-item date start">
              <span>--</span>
              <el-date-picker v-model="logInfo.endDate" align="left" type="date" @change="getendTime" size="small" :placeholder="display.startDate" :picker-options="logInfo.endPickerOptions">
             </el-date-picker>
            </div>
            </grid>
          </div>
         </div>
      </div>
      <el-dialog :title="display.tips.title" :visible.sync="isTipDialogShow" class="popup dark" :show-close="false">
        <span>{{popMsgs}}</span>
        <span slot="footer" class="dialog-footer" v-show="isTipneedBtn">
          <el-button @click="isTipDialogShow = false">{{display.tips.cancelBtn}}</el-button>
          <el-button type="primary" @click="popConfirm">{{display.tips.confirmBtn}}</el-button>
        </span>
      </el-dialog>
      <el-dialog :title="display.account.resetPassword" :visible.sync="isResetDialogShow" custom-class="reset white"  size='xs' :close-on-click-modal="false" :show-close="false">
      <div class="formContent">
        <label ><span>{{display.newPassword}}：</span><input type="password" v-model="firstPassword" /></label>
        <label ><span>{{display.confirmPassword}}：</span><input type="password" v-model="secondPassword" /></label>
        <p v-show="comparePwd">{{display.tips.passwordCompareMsg}}</p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="isResetDialogShow = false">{{display.tips.cancelBtn}}</el-button>
        <el-button type="primary" @click="confirmResetPassword">{{display.tips.commitBtn}}</el-button>
      </div>
    </el-dialog>
    <el-dialog :title="display.tips.chooseOrgination" :visible.sync="isSelectOrigination"  custom-class="reset white"  size='sm' :close-on-click-modal="false" :show-close="false">
       <el-tree :data="organizationList" :props="orgProps" :highlight-current=true  :expand-on-click-node=false :default-expand-all=true  @node-click="handleOrgClick"></el-tree>
       <span slot="footer" class="dialog-footer">
          <el-button @click="isSelectOrigination = false">{{display.tips.cancelBtn}}</el-button>
          <el-button type="primary" @click="confirmDept">{{display.tips.confirmBtn}}</el-button>
        </span>
    </el-dialog>
    <el-dialog :title="display.roleTable.dialogTitle" :visible.sync="isSelectRole" custom-class="role-select-pop white"  size='sm' :close-on-click-modal="false" :show-close="false">
            <div class="role-content">
        <div class="search-field clearfix">
          <div>
            <input type="text"  :placeholder="display.roleTable.placeholder" @keyup.13="getAllroleList" v-model="roleSearchText" /><span class="search-btn" @click="getAllroleList"><i class="iconfont icon-search"></i></span>
          </div>
        </div>
        <div class="role-table">
          <table>
            <thead>
              <tr>
                <th class="role-check-all">
                  <div class="th-inner"><input type="checkbox"  @click="selectAllRole"  v-model="isSelectAllRole" /></div>
                </th>
                <th>
                  <div class="th-inner">{{display.roleTable.nameCols}}</div>
                </th>
                <th>
                  <div class="th-inner">{{display.roleTable.authority}}</div>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item,index) in roleList" :key="index">
                <td class="bt-tab-item">
                  <div class="td-inner"><input type="checkbox" v-model="item.checked"  @click.stop="checkRole(item)"/></div>
                </td>
                <td class="bt-tab-item">{{item.roleName}}</td>
                <td class="bt-tab-item">{{item.roleDesc}}</td>
              </tr>
              <tr v-if="isRoleEmpty">
                <td colspan="3" class="emptyTd">{{display.noRecords}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="isSelectRole = false">{{display.tips.cancelBtn}}</el-button>
          <el-button type="primary" @click="confirmRole">{{display.tips.confirmBtn}}</el-button>
        </span>
    </el-dialog>

  </div>
  
</template>
<script>
import Grid from "@/components/common/Grid";
import endpoints from "@/api/endpoints";
import { clone, parseToDateTime, convertPropertiesToAttributes } from "@/utils";
import { mapGetters } from "vuex";

export default {
  name: "Account",
  props: [],
  components: {
    Grid
  },
  computed: {
    ...mapGetters({
      loginInfo: "getUser"
    }),
    logTitle() {
      return (
        this.display.titleL +
        "<strong>" +
        this.currentAccount.name +
        "</strong>" +
        this.display.titleR
      );
    }
  },
  data() {
    return {
      display: {
        tips: {
          title: "提示",
          quitEditingMsg: "确认要放弃编辑吗？",
          cancelBtn: "取消",
          confirmBtn: "确定",
          commitBtn: "确定",
          chooseOrgination: "部门选择",
          passwordCompareMsg: "两次输入的密码不一致！",
          completeAccountInfo: "请完善账户资料！",
          isSureToDelete: "确定要删除用吗？",
          addSuccess: "添加成功！",
          editSuccess: "修改成功！",
          enableSuccess: "启用成功！",
          disableSuccess: "停用成功！",
          deleteOne: "每次只能删除一个用户！",
          selectOne: "请至少选择一个用户！"
        },
        roleTable: {
          dialogTitle: "角色列表",
          nameCols: "角色",
          authority: "权限",
          placeholder: "角色,权限",
          coloumNames: {
            changeName: "变更账户",
            changeContent: "变更账户",
            accountState: "状态",
            accountState: "时间"
          }
        },
        titleL: "用户【",
        titleR: "】历史信息",
        null: "无",
        editBtn: "编辑",
        addBtn: "添加",
        cancelBtn: "取消",
        deleteBtn: "删除",
        confirmBtn: "确定",
        enableBtn: "启用",
        disenableBtn: "停用",
        asideTitle: "详情",
        startDate: "开始日期",
        endDate: "结束日期",
        dateLabel: "选择日期",
        asideInnerTitle: "账户信息",
        newPassword: "新密码",
        noRecords: "暂无记录",
        confirmPassword: "确认密码",
        account: {
          code: "用户编码",
          name: "用户名",
          dept: "所属部门",
          leader: "直属领导",
          phone: "电话",
          mobile: "手机号",
          email: "邮箱",
          state: "用户状态",
          resetPassword: "重置密码",
          originPassword: "初始密码",
          role: "角色",
          userState: {
            enable: "启用",
            disable: "停用"
          }
        },
        table: {
          buttons: {
            add: "添加",
            delete: "删除"
          },
          accountPlaceholder: "账户名,编号,手机号",
          logPlaceholder: "账户名,状态"
        }
      },
      account: {
        data: [],
        pageCount: 0,
        pageNo: 1,
        pageSize: 2,
        condition: "",
        selectIds: [],
        gridColumns: [
          {
            attributeName: "name",
            displayName: "账户名",
            colWidth: 100
          },
          {
            attributeName: "userNo",
            displayName: "员工编号",
            colWidth: 100
          },
          {
            attributeName: "mobile",
            displayName: "手机号",
            colWidth: 100
          },
          {
            attributeName: "roleNames",
            displayName: "账户角色",
            colWidth: 200
          },
          {
            attributeName: "statusFormatter",
            displayName: "账户状态",
            colWidth: 100
          }
        ]
      },
      logInfo: {
        data: [],
        pageCount: 0,
        pageNo: 1,
        pageSize: 6,
        fuzzy: "",
        start: "",
        end: "",
        startDate: "",
        endDate: "",
        defalutStart: "2016-01-01",
        startPickerOptions: {
          disabledDate: time => {
            let beginDateVal = this.logInfo.endDate;
            if (beginDateVal) {
              return time.getTime() > beginDateVal;
            }
          }
        },
        endPickerOptions: {
          disabledDate: time => {
            let beginDateVal = this.logInfo.startDate;
            if (beginDateVal) {
              return time.getTime() < beginDateVal;
            }
          }
        },
        gridColumns: [
          {
            attributeName: "userName",
            displayName: "变更账户",
            width: 250
          },
          {
            attributeName: "optContent",
            displayName: "变更内容",
            width: 250
          },
          {
            attributeName: "statusFormatter",
            displayName: "账户状态",
            width: 250
          },
          {
            attributeName: "createDateFormatter",
            displayName: "时间",
            width: 250
          }
        ]
      },
      valite: {
        userNo: true,
        name: true,
        phone: true,
        mobile: true,
        email: true,
        password: true,
        organization: true
      },
      startDate: "11",
      endDate: "",
      logSearchText: "",
      organizationList: [],
      roleList: [],
      isSelectAllRole: false,
      selectRoleIds: [],
      isRoleEmpty: false,
      checkAllRoleBol: false,
      roleSearchText: "",
      leaderList: [],
      isAdd: false,
      isEdit: false,
      isResetDialogShow: false,
      isSelectOrigination: false,
      isSelectRole: false,
      comparePwd: false,
      firstPassword: "",
      secondPassword: "",
      popMsgs: "",
      popTipType: "",
      isTipDialogShow: false,
      isTipneedBtn: false,
      TipBtnFnId: "",
      orgProps: {
        children: "childs",
        label: "name"
      },
      selDeptId: "",
      selorgName: "",
      newAccount: {
        orgId: "",
        type: 2,
        userNo: "zs001",
        name: "王文荣",
        deptId: "212",
        orgName: "研发",
        leaderId: "张思",
        phone: "0377-83848821",
        mobile: "12536269083",
        email: "waglsd@163.com",
        status: "0",
        password: "123456",
        roleIds: [],
        roleNames: "舒思盾，是的，放大镜，大幅度、dfd/d、fdf/"
      },
      currentAccount: {},
      editAccount: {}
    };
  },
  mounted() {
    this.getAccountList();
    this.getOrginationList();
    this.getAllroleList();
    this.initColumnWidth();
  },
  methods: {
    getTime(date) {
      this.logInfo.start = date;
    },
    getendTime(date) {
      this.logInfo.end = date;
    },
    initColumnWidth() {
      var ww = document.getElementsByClassName("account-table")[0].offsetWidth;
      this.account.gridColumns.forEach((item, index) => {
        item.width = (ww - 100 - 20) / 5;
      });
      // user i18n data from???
      // this.account.gridColumns[0]. this.display.roleTable.coloumNames.changeName;
      this.logInfo.gridColumns.forEach((item, index) => {
        item.width = (ww - 50 - 20) / 4;
      });
    },
    chooseDept() {
      this.isSelectOrigination = true;
      this.selDeptId = "";
      this.selorgName = "";
      if (this.isAdd) this.valite.organization = false;
    },
    popConfirm() {
      this.isTipDialogShow = false;
      if (this.TipBtnFnId == "remove") {
        this.removeRequest();
      } else if (this.TipBtnFnId == "dropEdit") {
        this.isEdit = false;
        this.add();
      }
    },
    popTips(msg, fnId) {
      var self = this;
      this.popMsgs = msg;
      this.isTipDialogShow = true;
      if (fnId) {
        this.isTipneedBtn = true;
        this.TipBtnFnId = fnId;
      } else {
        this.isTipneedBtn = false;
        this.TipBtnFnId = "";
        setTimeout(function() {
          self.isTipDialogShow = false;
          this.popMsgs = "";
        }, 1200);
      }
    },
    edit() {
      this.isAdd = false;
      this.isEdit = true;
      this.editAccount = clone(this.currentAccount);
      for (var key in this.valite) {
        this.valite[key] = true;
      }
    },
    add() {
      if (this.isEdit) {
        this.popTips(this.display.tips.quitEditingMsg, "dropEdit");
      } else {
        for (var key in this.valite) {
          this.valite[key] = false;
        }
        this.selectRoleIds = [];
        this.checkAllRoleBol = false;
        this.isAdd = true;
        this.isEdit = false;
        this.newAccount = {
          orgId: "",
          type: 2,
          userNo: "",
          name: "",
          deptId: "",
          orgName: "",
          leaderId: "",
          phone: "",
          mobile: "",
          email: "",
          status: "0",
          password: "",
          roleIds: [],
          roleNames: ""
        };
      }
    },
    remove() {
      if (!this.account.selectIds.length) {
        this.popTips(this.display.tips.selectOne);
      } else if (this.account.selectIds.length === 1) {
        this.popTips(this.display.tips.isSureToDelete, "remove");
      } else if (this.account.selectIds.length > 1) {
        this.popTips(this.display.tips.deleteOne);
      }
    },
    removeRequest() {
      this.$api
        .request(endpoints.deleteAccount, {
          id: this.account.selectIds[0]
        })
        .then(res => {
          if (res != null) {
            this.getAccountList();
          }
        });
    },
    cancel() {
      this.isAdd = false;
      this.isEdit = false;
      if (this.isAdd) {
        this.newAccount = {};
      } else {
        this.editAccount = clone(this.currentAccount);
      }
    },
    confirm() {
      var self = this,
        verified = true;
      //verified params
      if (this.isAdd) {
        for (var key in self.valite) {
          if (self.valite[key]) {
            verified = false;
          }
        }
      } else {
        for (var key in self.valite) {
          if (!self.valite[key]) {
            verified = false;
          }
        }
      }

      if (verified) {
        if (this.isAdd) {
          self.$api.request(endpoints.addAccount, self.newAccount).then(res => {
            if (res != null) {
              this.isAdd = false;
              self.getAccountList();
              self.popTips(self.display.tips.addSuccess);
            }
          });
        } else {
          self.$api
            .request(endpoints.updateAccountInfo, self.editAccount)
            .then(res => {
              if (res != null) {
                this.isEdit = false;
                self.getAccountList();
                self.popTips(self.display.tips.editSuccess);
              }
            });
        }
        self.getAccountList();
      } else {
        self.popTips(self.display.tips.completeAccountInfo);
      }
    },
    editRole() {
      this.isSelectRole = true;
      if (this.isAdd) {
        this.selectRoleIds = this.newAccount.roleIds;
      } else {
        this.selectRoleIds = this.editAccount.roleIds;
      }
      this.selectRoleIds.forEach((id, index) => {
        this.roleList.forEach(role => {
          if (role.id == id) {
            role.checked = true;
          }
        });
      });
    },
    checkRole(item) {
      if (!item.checked) {
        this.selectRoleIds.push(item.id);
      } else {
        for (var i = 0; i < this.selectRoleIds.length; i++) {
          if (this.selectRoleIds[i] == item.id) {
            this.selectRoleIds.splice(i, 1);
            break;
          }
        }
      }
      item.checked = !item.checked;
    },
    selectAllRole() {
      this.selectRoleIds = [];
      if (this.isSelectAllRole) {
        //uncheck
        this.roleList.forEach((item, index) => {
          item.checked = false;
        });
      } else {
        this.roleList.forEach((item, index) => {
          item.checked = true;
          this.selectRoleIds.push(item.id);
        });
      }
    },
    confirmRole() {
      var roleNames = "",
        self = this;
      this.isSelectRole = false;
      this.roleList.forEach((role, index) => {
        if (self.selectRoleIds.indexOf(role.id) > -1) {
          roleNames += role.roleName + ",";
        }
      });
      roleNames = roleNames.substring(0, roleNames.length - 1);
      if (this.isAdd) {
        this.newAccount.roleIds = this.selectRoleIds;
        this.newAccount.roleList = this.selectRoleIds;
        this.newAccount.roleNames = roleNames;
      } else {
        this.editAccount.roleIds = this.selectRoleIds;
        this.editAccount.roleNames = roleNames;
      }
    },
    validate(type) {
      var self = this,
        regUserNo = /^[a-zA-Z0-9]{3,16}$/,
        regMobile = /^1[34578]{1}\d{9}$/,
        regEmail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/,
        regPhone = /(^[0-9]…{3,4}-[0-9]…{3,8}$)|(^[0-9]…{3,8}$)|(^([0-9]…{3,4})[0-9]…{3,8}$)|(^0…{0,1}13[0-9]…{9}$)/,
        regPassword = /^[a-zA-Z\d_]{6,16}$/;
      setTimeout(() => {
        if (this.isAdd) {
          switch (type) {
            case "userNo":
              if (
                self.newAccount.userNo.length &&
                regUserNo.test(self.newAccount.userNo)
              ) {
                self.valite.userNo = false;
              } else {
                self.valite.userNo = true;
              }
              break;
            case "name":
              if (
                self.newAccount.name != "" &&
                self.newAccount.name.length < 14
              ) {
                self.valite.name = false;
              } else {
                self.valite.name = true;
              }
              break;
            case "mobile":
              if (regMobile.test(self.newAccount.mobile)) {
                self.valite.mobile = false;
              } else {
                self.valite.mobile = true;
              }
              break;
            case "email":
              if (regEmail.test(self.newAccount.email)) {
                self.valite.email = false;
              } else {
                self.valite.email = true;
              }
              break;
            case "phone":
              if (regPhone.test(self.newAccount.phone)) {
                self.valite.phone = false;
              } else {
                self.valite.phone = true;
              }
              break;
            case "password":
              if (regPassword.test(self.newAccount.password)) {
                self.valite.password = false;
              } else {
                self.valite.password = true;
              }
              break;
            default:
              break;
          }
        } else {
          //verify  editAccount
          switch (type) {
            case "userNo":
              self.valite.userNo = false;
              if (
                self.editAccount.userNo.length &&
                regUserNo.test(self.editAccount.userNo)
              ) {
                self.valite.userNo = true;
              }
              break;
            case "name":
              self.valite.name = false;
              if (
                self.editAccount.name != "" &&
                self.editAccount.name.length < 14
              ) {
                self.valite.name = true;
              }
              break;
            case "mobile":
              self.valite.mobile = false;
              if (regMobile.test(self.editAccount.mobile)) {
                self.valite.mobile = true;
              }
              break;
            case "email":
              self.valite.email = false;
              if (regEmail.test(self.editAccount.email)) {
                self.valite.email = true;
              }
              break;
            case "phone":
              self.valite.phone = false;
              if (regPhone.test(self.editAccount.phone)) {
                self.valite.phone = true;
              }
              break;
            case "password":
              self.valite.password = false;
              if (regPassword.test(self.editAccount.password)) {
                self.valite.password = true;
              }
              break;
            default:
              break;
          }
        }
      }, 100);
    },
    goResetPassword() {
      this.firstPassword = "";
      this.secondPassword = "";
      this.isResetDialogShow = true;
    },
    handleOrgClick(item) {
      this.selDeptId = item.id;
      this.selorgName = item.name;
    },
    confirmDept() {
      this.isSelectOrigination = false;
      if (this.isAdd) {
        if (this.selDeptId != "") {
          this.newAccount.deptId = this.selDeptId;
          this.newAccount.orgName = this.selorgName;
          this.valite.organization = false;
        } else {
          this.valite.organization = true;
        }
      } else {
        if (this.selDeptId != "") {
          this.editAccount.deptId = this.selDeptId;
          this.editAccount.orgName = this.selorgName;
          this.valite.organization = true;
        } else {
          this.valite.organization = false;
        }
      }
      this.getLeaderList();
    },
    confirmResetPassword() {
      var self = this;
      var userId = this.isEdit ? this.editAccount.id : this.currentAccount.id;
      if (
        this.firstPassword.length > 6 &&
        this.firstPassword === this.secondPassword
      ) {
        this.comparePwd = false;
        self.$api
          .request(endpoints.updateAccountInfo, {
            id: userId,
            password: self.firstPassword
          })
          .then(res => {
            if (res != null) {
              this.isResetDialogShow = false;
            }
          });
      } else {
        this.comparePwd = true;
      }
    },
    getLeaderList(deptId) {
      //TODO:  get leaderList by orgId or departmentId  wait for discuss
      var self = this;
      self.$api
        .request(endpoints.getLeaderList, {
          deptId: ""
        })
        .then(res => {
          if (res != null) {
            self.leaderList = res;
          } else {
            self.leaderList = [];
          }
        });
    },
    getAccountList(pageNumber) {
      var self = this;
      var pageNo = pageNumber || this.account.pageNo;
      self.$api
        .request(endpoints.getAccountList, {
          pageSize: self.account.pageSize,
          pageNo: pageNo,
          condition: self.account.condition
        })
        .then(res => {
          if (res != null) {
            self.account.data = res.list;
            self.account.selectIds = [];
            if (self.account.data.length) {
              self.account.data.forEach((el, index) => {
                var roleList = el.roleList;
                if (roleList.length) {
                  var str = "";
                  for (var i = 0; i < roleList.length; i++) {
                    if (i === 0) {
                      str += roleList[i].roleName;
                    } else {
                      str += "," + roleList[i].roleName;
                    }
                  }
                  el.roleNames = str;
                } else {
                  el.roleNames = self.display.null;
                }
                el.statusFormatter =
                  el.status == 0
                    ? self.display.account.userState.enable
                    : self.display.account.userState.disable;
              });
              self.currentAccount = clone(self.account.data[0]);
              self.logInfo.userId = self.currentAccount.userId;
              self.getUserLogList();
            } else {
              self.currentAccount = [];
              self.logInfo.userId = "";
              self.logInfo.data = "";
            }
            self.account.pageCount = res.pages;
          }
        });
    },
    getUserLogList(params) {
      var self = this,
        pageNo = params || this.logInfo.pageNo;
      self.$api
        .request(endpoints.getUserLogList, {
          userId: self.currentAccount.id,
          pageSize: self.logInfo.pageSize,
          pageNo: pageNo,
          fuzzy: self.logInfo.fuzzy,
          startDate: self.logInfo.start,
          endDate: self.logInfo.end
        })
        .then(res => {
          if (res != null) {
            self.logInfo.data = res.list;
            if (self.account.data.length) {
              self.logInfo.data.forEach((item, index) => {
                item.statusFormatter =
                  item.status == 0
                    ? self.display.account.userState.enable
                    : self.display.account.userState.disable;
                item.createDateFormatter = parseToDateTime(item.createDate);
              });
            }
            self.logInfo.pageCount = res.pages;
          }
        });
    },
    getOrginationList() {
      var self = this;
      self.$api.request(endpoints.getOrganizationList, {}).then(res => {
        if (res != null) {
          self.organizationList = res;
        }
      });
    },
    getAllroleList() {
      var self = this;
      self.$api
        .request(endpoints.getRoles, {
          pageNo: 1,
          pageSize: 1000,
          condition: self.roleSearchText
        })
        .then(res => {
          if (res != null) {
            res.list.forEach(item => {
              item.checked = false;
            });
            self.roleList = res.list;
          }
        });
    },
    accountPageGo(params) {
      this.getAccountList(params.pageIndex);
    },
    changeAccountStatus(type) {
      var self = this,
        status = type === "enable" ? 0 : 1,
        msg =
          type === "enable"
            ? this.display.tips.enableSuccess
            : this.display.tips.disableSuccess;
      if (self.account.selectIds.length) {
        this.$api
          .request(endpoints.enableAccount, {
            status: status,
            ids: this.account.selectIds
          })
          .then(res => {
            if (res != null) {
              //TODO: change selectAll state waitting for Grid changed
              self.getAccountList();
              self.popTips(msg);
            }
          });
      } else {
        self.popTips(self.display.tips.selectOne);
      }
    },
    accountSearch(params) {
      if (params) {
        this.account.condition = params.searchBy;
      } else {
        this.account.condition = "";
      }
      this.getAccountList();
    },
    accountCheckAll(params) {
      this.account.selectIds = [];
      if (params.allChecked) {
        params.data.forEach((item, index) => {
          this.account.selectIds.push(item.id);
        });
      }
    },
    accountCheckRow(params) {
      if (params.checked) {
        this.account.selectIds.push(params.currentItem.id);
      } else {
        for (var i = 0; i < this.account.selectIds.length; i++) {
          if (this.account.selectIds[i] === params.currentItem.id) {
            this.account.selectIds.splice(i, 1);
          }
        }
      }
    },
    accountSelectRow({ previousItem, currentItem }) {
      if (this.isAdd || this.isEdit) {
        previousItem._selected = true;
        currentItem._selected = false;
      } else {
        this.currentAccount = clone(currentItem);
        this.getUserLogList();
      }
    },
    logSearch(params) {
      if (params) {
        this.logInfo.fuzzy = params.searchBy;
      } else {
        this.logInfo.fuzzy = "";
      }
      this.getUserLogList();
    },
    logPageGo(params) {
      this.getUserLogList(params.pageIndex);
    },
    bindDrag(e) {}
  }
};
</script>

<style lang="scss" scoped>
.wrap {
  width: 100%;
  height: 100%;
  .left-wrap {
    margin-right: 300px;
    height: 100%;
    overflow-y: auto;
    .user-content {
      background-color: #ffffff;
      height: 60%;
      .account-table {
        height: 100%;
      }
    }
    .log-content {
      height: 38%;
      background-color: #ffffff;
      .log-title {
        display: inline-block;
        line-height: 28px;
        height: 28px;
        margin-right: 10px;
      }
      .log-table {
        height: 100%;
        .grid-top-item {
          // border: 1px solid red;
          display: inline-block;
          width: 260px;
          vertical-align: top;
        }
        .grid-top-item.title {
          width: 180px;
        }
        .grid-top-item.date.start {
          width: 240px;
        }
      }
    }
  }
  .right-wrap {
    float: right;
    width: 300px;
    height: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    -o-box-sizing: border-box;
    -ms-box-sizing: border-box;
    background-color: #383f52;
    .aside-title {
      background-color: #ffffff;
      padding: 10px 0 20px 0;
      div {
        background-color: #383f52;
        h3 {
          line-height: 38px;
          color: #ffffff;
          text-align: center;
          font-weight: bold;
          letter-spacing: 10px;
        }
      }
    }
    .aside-content {
      .aside-actions {
        margin: 10px 0 0 20px;
      }
      .aside-field-wrap {
        color: #ffffff;
        margin-left: 10px;
        .inner-title {
          margin: 10px 0;
          span {
            font-size: 22px;
            margin-right: 10px;
            vertical-align: middle;
          }
          h3 {
            display: inline-block;
            font-size: 16px;
            font-weight: bold;
            vertical-align: middle;
          }
        }
        .aside-fields {
          color: #ffffff;
          .field-item {
            margin: 15px 0;
            label {
              display: inline-block;
              width: 30%;
              width: 100px;
              margin-right: 1%;
              vertical-align: middle;
              line-height: 28px;
              height: 28px;
              text-align: right;
            }
            .field-cell-edit {
              width: 150px;
              height: 28px;
              line-height: 28px;
              border-radius: 5px;
              border: 1px solid #8b8b92;
              text-indent: 8px;
              padding: 0;
              outline: none;
            }
            .required {
              line-height: 28px;
              vertical-align: middle;
            }
            .warning {
              color: yellow;
            }
            .field-cell-detail {
              display: inline-block;
              width: 56%;
              text-indent: 8px;
              padding: 0;
              height: 28px;
              line-height: 28px;
              .resetPassword {
                color: #abb6d5;
                display: inline-block;
                border-bottom: 1px solid #ffffff;
                text-decoration: none;
                line-height: 18px;
                text-indent: 0;
                padding: 0 2px;
              }
            }
          }
          .field-item.role-names {
            .field-cell-detail {
              min-height: 100px;
            }
            .field-cell-edit {
              min-height: 100px;
              border-radius: 10px;
              background-color: #fff;
              display: inline-block;
              color: #333;
            }
            label {
              vertical-align: top;
            }
            .required {
              vertical-align: top;
            }
          }
          .select-role-btn {
            span {
              display: inline-block;
              background-color: #fff;
              padding: 6px 20px;
              color: #000000;
              font-weight: 800;
              font-size: 18px;
              border-radius: 4px;
              margin-left: 106px;
              cursor: pointer;
            }
          }
        }
      }
    }
  }
}
.reset {
  .el-dialog__body {
    background-color: #ffffff;
    .formContent {
      width: 80%;
      color: #333333;
      margin: 10px auto;
      label {
        display: inline-block;
        width: 100%;
        height: 28px;
        margin-bottom: 20px;
        span {
          display: inline-block;
          width: 100px;
          text-align: right;
        }
        input {
          width: 200px;
          height: 28px;
          line-height: 28px;
          outline: none;
          border: 1px solid #cccccc;
          padding: 4px;
          border-radius: 6px;
        }
      }
      p {
        color: red;
        text-indent: 100px;
        font-size: 12px;
      }
    }
  }
}
.el-tree-el-dialog__wrapper {
  .el-dialog__body {
    .el-tree {
      color: #333333;
    }
  }
}
.role-select-pop {
  .el-dialog__body {
    .role-content {
      .search-field {
        div {
          width: 184px;
          float: right;
          border: 1px solid #cccccc;
          input {
            width: 161px;
            height: 25px;
            line-height: 28px;
            text-indent: 10px;
            font-size: 14px;
            font-family: "helvetica";
            outline: none;
            padding: 0;
            vertical-align: top;
            margin-left: 1px;
            border: 0;
          }
          .search-btn {
            display: inline-block;
            width: 28px;
            height: 29px;
            border-radius: 2px;
            cursor: pointer;
            vertical-align: top;
            background-color: #383f52;
            color: #ffffff;
            margin-left: -6px;
            text-align: center;
            i {
              line-height: 28px;
            }
          }
          .search-btn:hover {
            background-color: #bf0535;
          }
        }
      }
      .role-table {
        height: 300px;
        overflow: auto;
        table {
          border: 1px solid #ccc;
          width: 100%;
          thead {
            tr {
              border-bottom: 1px solid #cccccc;
              th {
                text-align: left;
                background-color: #808080;
                color: #ffffff;
                display: table-cell;
                padding: 6px 0;
                box-sizing: border-box;
              }
              th:first-child {
                div {
                  text-align: center;
                }
              }
            }
          }
          tbody {
            tr {
              border-bottom: 1px solid #cccccc;
              td:first-child {
                width: 50px;
                text-align: center;
              }
              td {
                border-right: 1px solid #dddddd;
                color: #333333;
                text-align: left;
                display: table-cell;
                padding: 6px 0;
                box-sizing: border-box;
              }
            }
            tr:hover {
              background-color: #cccccc;
            }
          }
        }
      }
    }
  }
}
</style>
