<template>
<el-dialog class="editor" :title="$t_('editing')" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-area" ref="wrapper" >
      <tabs
        :tabs="searchTabs"
        :active-index="searcher.activeIndex"
        @click="activateTab"
        />
        <editor-logger :logs="logs" :above="true"/>
      <div class="search-area" ref="searcher">
        <fields-renderer
          :entry="searchCondition"
          :is-data-bean="true"
          :fields="searcher.activeIndex ? portfolioFields : standardFields"
          :adding="true"
          :column-count="2"
          />
      </div>
      <div class="btn-area"  ref="button">
        <span class="btn btn-dark" @click="searchFactors">{{ $t_('search') }}</span>
        <span v-show="factors.length">({{recordCount}})</span>
      </div>
      <div class="list-area"  ref="listArea">
        <transfer
          :options="factors"
          :selectedOptions="factorIds"
          v-model="selectedFactors"
          title="Risk Factors"
          ref="transfer"
          />
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
	  </div>
  </el-dialog>
</template>

<script>
import Transfer from "@/components/common/Transfer";
import Tabs from "@/components/common/Tabs";
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import { generateTreeSelectorOption } from "@/components/sections/FieldsRenderer";
import { mapGetters } from "vuex";
import { DATA_KEYS, DATA_TYPES, RESPONSE_CODE } from "@/consts";

const TAB_HEIGHT = 30;
export default {
  name: "FactorSelector",
  components: { Transfer, Tabs, FieldsRenderer, EditorLogger },
  props: {
    visible: Boolean,
    factorIds: {
      type: Array,
      require: true
    }
  },
  data() {
    return {
      searcher: {
        activeIndex: 0
      },
      logs: [],
      searchCondition: {},
      factors: [],
      selectedFactors: [],
      recordCount: null
    };
  },
  computed: {
    searchTabs() {
      return ["Standard", "Search by Portfolio"];
    },
    standardFields() {
      return [
        {
          attributeName: "ID",
          name: "ID",
          dataType: "STRING",
          editableInNew: true,
          enumRef: "",
          visible: true,
          occurs: {}
        },
        {
          attributeName: "Name",
          name: "Name",
          dataType: "STRING",
          editableInNew: true,
          enumRef: "",
          visible: true,
          occurs: {}
        },
        {
          attributeName: "Type",
          name: "Type",
          dataType: "STRING",
          editableInNew: true,
          enumRef: "global.Product Type",
          visible: true,
          occurs: {}
        },
        {
          attributeName: "Risk Group Type",
          name: "Risk Group Type",
          dataType: "STRING",
          editableInNew: true,
          enumRef: "global.Risk Group Type",
          visible: true,
          occurs: {}
        }
      ];
    },
    portfolioFields() {
      let field = {
        attributeName: "Portfolio ID",
        name: "Portfolio ID",
        dataType: "STRING",
        editableInNew: true,
        reference: true,
        visible: true,
        occurs: {}
      };
      field.options = generateTreeSelectorOption(field, this.$api);
      return [field];
    }
  },
  watch: {
    visible(val) {
      if (val) {
        this.searcher.activeIndex = 0;
        this.reset();
      }
    }
  },
  methods: {
    reset() {
      this.selectedFactors = [];
      this.searchCondition = {};
      this.factors = [];
      this.logs = [];
      this.$nextTick(() => {
        this.$refs.transfer.reset();
        this.resetListHeight();
      });
    },
    save() {
      this.$emit("save", this.selectedFactors);
    },
    close() {
      this.reset();
      this.$emit("close");
    },
    activateTab({ index }) {
      this.searcher.activeIndex = index;
      this.reset();
    },
    resetListHeight() {
      let height = 0,
        padding = 10,
        totalHeight = this.$refs.wrapper.clientHeight - padding,
        searchHeight = this.$refs.searcher.clientHeight,
        buttonHeight = this.$refs.button.clientHeight;
      height = totalHeight - TAB_HEIGHT - searchHeight - buttonHeight;
      this.$refs.listArea.style.height = height + "px";
    },
    searchFactors() {
      let defaultCondition = null,
        dataType = null,
        searchBy = [];
      if (!this.searcher.activeIndex) {
        for (let key in this.searchCondition) {
          if (this.searchCondition[key]) {
            searchBy.push({
              key,
              searchType: "String",
              value: this.searchCondition[key]
            });
          }
        }
        dataType = DATA_TYPES.MARKETDATA;
      } else {
        let id = this.searchCondition["Portfolio ID"];
        defaultCondition = {
          searchType: "LEAVES",
          searchValues: [id]
        };
        dataType = DATA_TYPES.RISK_FACTOR;
      }

      let requestParameters = productApiHelper.getRequestData(
        defaultCondition,
        null,
        searchBy,
        null,
        null,
        dataType,
        0
      );
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.factors = data.records;
            this.recordCount = data.recordCount;
          } else {
            this.logs = messages;
          }
        });
    }
  }
};
</script>

<style scoped>
.search-area {
  padding: 5px 0;
  border: 1px solid #ccc;
}
.btn-area {
  padding: 5px;
}
.editor-area {
  margin: 10px 10px 0 10px;
  height: calc(100% - 10px);
  height: -ms-calc(100% - 10px);
  height: -moz-calc(100% - 10px);
  height: -webkit-calc(100% - 10px);
}
.list-area {
  border-bottom: 1px solid #cccccc;
}
</style>