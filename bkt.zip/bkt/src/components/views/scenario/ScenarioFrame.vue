<template>
  <div class="frame" ref="frame">
    <div class="half clearfix" ref="top">
      <div class="scenario-sets" ref="left">
        <grid
          :need-pager="true"
          :need-index="true"
          :need-searcher="true"
          :columns="scenarioSetColumns"
          :data="scenarioSets.data"
          :page-index="scenarioSets.pageIndex"
          :page-count="scenarioSets.pageCount"
          :condition="scenarioSets.searchBy"
          @select="selectScenarioSet"
          @sort="retrieveScenarioSetData"
          @search="retrieveScenarioSetData"
          @prev-page="retrieveScenarioSetData"
          @next-page="retrieveScenarioSetData"
          @jump-page="retrieveScenarioSetData"
          ref="scenarioSets"
          >
          <button-bar
            :padding-right="0"
            :buttons="scenarioSetButtons" />
        </grid>
      </div>
      <resizer axis="x" @resize="resizeX1" />
      <div class="scenarios" ref="middle">
        <grid
          :need-index="true"
          :need-pager="true"
          :need-searcher="true"
          :page-index="scenarios.pageIndex"
          :page-count="scenarios.pageCount"
          :condition="scenarios.searchBy"
          :columns="scenarioColumns"
          :data="scenarios.data"
          @select="selectScenario"
          @sort="retrieveScenarioData"
          @search="retrieveScenarioData"
          @prev-page="retrieveScenarioData"
          @next-page="retrieveScenarioData"
          @jump-page="retrieveScenarioData"
          ref="scenarios"
          >
          <button-bar
            :padding-right="0"
            :buttons="scenarioButtons" />
        </grid>
      </div>
      <resizer axis="x" @resize="resizeX2" />
      <div class="factors" ref="right">
        <grid
          :need-index="true"
          :need-searcher="true"
          :columns="factorColumns"
          :data="factors.data"
          :condition="factors.searchBy"
          @select="selectFactor"
          @search="searchFactorData"
          ref="factors"
          >
          <button-bar
            :padding-right="0"
            :buttons="factorButtons" />
        </grid>
      </div>
      <div style="height:100%;background-color: #fff; opacity: .5;" v-show="coverVisible" ></div>
    </div>
    <resizer axis="y" @resize="resizeY" />
    <div class="half clearfix" ref="bottom">
      <factor-editor
       @edit="editFactor"
       :entry="factors.selectedItem"
       ref="factorEditor"/>
    </div>
    <scenario-editor
      :visible="publicEditor.visible"
      :isAdding="isAdding"
      :product-type="publicEditor.productType"
      :scenario-set="scenarioSets.selectedItem"
      @add="postAddData"
      @edit="postEditData"
      @close="publicEditor.visible=false"
      />
     <factor-selector
      :factorIds="currentScenarioSetFactorIds"
      :visible="factorSelector.visible"
      @close="factorSelector.visible=false"
      @save="saveFactors"
      /> 
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
  </div>
</template>

<script>
import endpoints from "@/api/endpoints";
import Resizer from "@/components/common/Resizer";
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Alert from "@/components/common/Alert";
import ScenarioEditor from "./ScenarioEditor";
import FactorEditor from "./FactorEditor";
import FactorSelector from "./FactorSelector";
import csvParser from "@/utils/csvParser";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import { mapGetters } from "vuex";
import { clone, autoCompleteFields, getColumns } from "@/utils";
import mixin from "../mixin";
import {
  SIZE,
  DATA_TYPES,
  DATA_KEYS,
  PAGE_SIZE,
  EDITOR_STATUS,
  RESPONSE_CODE
} from "@/consts";
const FACTOR_PATTERN = {
  attributes: {
    ID: { value: null },
    Name: { value: "" },
    "Scenario ID": { value: null },
    "Shock Type": { value: null },
    "Shock Unit": { value: null },
    "Shock Value": { value: null },
    "Curve Value": { value: null },
    "Attribute Type": { value: "Surface" }
  },
  id: null,
  virtual: true
};
export default {
  name: "ScenarioFrame",
  components: {
    Resizer,
    Grid,
    ButtonBar,
    Alert,
    ScenarioEditor,
    FactorEditor,
    FactorSelector
  },
  mixins: [mixin],
  data() {
    return {
      scenarioSets: {
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        pageCount: 0,
        pageIndex: 0,
        searchBy: "",
        sortBy: null
      },
      scenarios: {
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        pageCount: 0,
        pageIndex: 0,
        searchBy: "",
        sortBy: null
      },
      factors: {
        data: [],
        pools: [],
        selectedItem: null,
        selectedIndex: -1,
        searchBy: null,
        sortBy: null
      },
      publicEditor: {
        visible: false,
        productType: ""
      },
      factorSelector: {
        visible: false
      },
      coverVisible: false,
      isAdding: true,
      removeType: null,
      status: null,
      alert: {
        visible: false,
        title: "warning",
        message: "",
        log: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeConfirmation.visible = false;
              if (this.removeType === "factor") {
                this.removeSelectedFactor();
              } else {
                this.doRemove();
              }
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      dictionary: "getDicts",
      currentNav: "getCurrentNav",
      attributes: "getAttributes"
    }),
    scenarioSetTemplate() {
      return this.templates[DATA_KEYS.SCENARIO_SET_TEMPLATE];
    },
    scenarioTemplate() {
      return this.templates[DATA_KEYS.SENSITIVE_SCENARIO_TEMPLATE];
    },
    factorTemplate() {
      return this.templates[DATA_KEYS.FACTOR_TEMPLATE];
    },
    scenarioSetSearchableFields() {
      let fields = [];
      if (this.scenarioSetTemplate) {
        this.scenarioSetTemplate.measures.forEach(field => {
          if (field.searchAble) fields.push(field);
        });
      }
      return fields;
    },
    scenarioSearchableFields() {
      let fields = [];
      if (this.scenarioTemplate) {
        this.scenarioTemplate.measures.forEach(field => {
          if (field.searchAble) fields.push(field);
        });
      }
      return fields;
    },
    scenarioSetColumns() {
      let columns = [];
      if (this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT]) {
        columns = getColumns(
          this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT],
          DATA_KEYS.SCENARIO_SET_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    currentScenarioSetFactorIds() {
      let ids = [],
        currentItem = this.scenarioSets.selectedItem;
      if (currentItem) {
        if (currentItem.attributes["Risk Factor IDs"]) {
          ids = currentItem.attributes["Risk Factor IDs"].value || [];
        }
      }
      return ids;
    },
    scenarioSetButtons() {
      return [
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.isAdding = true;
            this.setEditorData(true);
          }
        },
        {
          icon: "icon-bianji",
          active: this.scenarioSets.selectedItem !== null,
          text: "edit",
          callback: () => {
            this.isAdding = false;
            this.setEditorData(true);
          }
        },
        {
          icon: "icon-shanchu",
          active: this.scenarioSets.selectedItem !== null,
          text: "remove",
          callback: () => {
            this.removeType = "scenarioSet";
            this.removeConfirmation.visible = true;
          }
        }
      ];
    },
    scenarioColumns() {
      let columns = [];
      if (this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT]) {
        columns = getColumns(
          this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT],
          DATA_KEYS.SCENARIO_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    scenarioButtons() {
      return [
        {
          icon: "icon-xinjian",
          active: this.scenarioSets.selectedItem !== null,
          text: "add",
          callback: () => {
            this.isAdding = true;
            this.setEditorData(false);
          }
        },
        {
          icon: "icon-bianji",
          active: this.scenarios.selectedItem !== null,
          text: "edit",
          callback: () => {
            this.isAdding = false;
            this.setEditorData(false);
          }
        },
        {
          icon: "icon-shanchu",
          active: this.scenarios.selectedItem !== null,
          text: "remove",
          callback: () => {
            this.removeType = "scenario";
            this.removeConfirmation.visible = true;
          }
        }
      ];
    },
    factorColumns() {
      let columns = [];
      if (this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT]) {
        columns = getColumns(
          this.views[DATA_KEYS.SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT],
          DATA_KEYS.SCENARIO_UNIT_GROUP,
          this.attributes
        );
      }
      return columns;
    },
    factorButtons() {
      return [
        {
          icon: "icon-xinjian",
          active: this.scenarioSets.selectedItem !== null,
          text: "add",
          callback: () => {
            this.factorSelector.visible = true;
          }
        },
        {
          icon: "icon-shanchu",
          active: this.factors.selectedItem !== null,
          text: "remove",
          callback: () => {
            this.removeType = "factor";
            this.removeConfirmation.visible = true;
          }
        }
      ];
    }
  },
  mounted() {
    this.resetStore();
    this.loadScenarioSetData();
  },
  methods: {
    loadScenarioSetData() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.scenarioSets = cacheData.scenarioSets;
        this.scenarios = cacheData.scenarios;
        this.factors = cacheData.factors;
      } else {
        this.retrieveScenarioSetData({});
      }
    },
    retrieveScenarioSetData({ searchBy, sortBy, pageIndex = 1 }) {
      if (searchBy || searchBy === "") this.scenarioSets.searchBy = searchBy;
      if (sortBy) this.scenarioSets.sortBy = sortBy;
      this.scenarioSets.pageIndex = pageIndex;

      let fields = null,
        defaultCondition = {
          attributeName: "Template Name",
          searchValues: ["SCENARIO_SET"],
          searchType: "CUSTOMIZED",
          operator: "EQUAL",
          valueType: "STRING"
        };

      if (this.scenarioSets.searchBy) fields = this.scenarioSetSearchableFields;

      let requestParameters = productApiHelper.getRequestData(
        defaultCondition,
        null,
        this.scenarioSets.searchBy,
        this.scenarioSets.sortBy,
        fields,
        DATA_TYPES.SCENARIO,
        pageIndex
      );
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.scenarioSets.data = data.records;
            this.scenarioSets.pageCount = Math.ceil(
              data.recordCount / PAGE_SIZE
            );
            if (data.records.length) {
              this.$refs.scenarioSets.selectDefault();
            } else {
              this.scenarios.data = [];
              this.scenarios.pageCount = 0;
            }
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.message = "";
          }
        });
    },
    selectScenarioSet({ currentItem, index }) {
      this.scenarioSets.selectedItem = currentItem;
      this.scenarioSets.selectedIndex = index;
      this.retrieveScenarioData({});
      this.loadDefFactorData();
      this.loadMarketFactorData();
    },
    updateScenarioData(editingItem, actionType) {
      if (actionType === "add") {
        this.scenarios.data.unshift(editingItem);
        if (this.factors.selectedItem)
          this.selectFactor({
            currentItem: this.factors.selectedItem,
            index: this.factors.selectedIndex
          });
      } else {
        this.scenarios.data.splice(this.factors.selectedIndex, 1, editingItem);
        this.scenarios.selectedItem = editingItem;
      }
      this.publicEditor.visible = false;
    },
    updateScenarioSetData(editingItem, actionType) {
      if (actionType === "add") {
        this.scenarioSets.data.unshift(editingItem);
        this.$refs.scenarioSets.selectDefault();
      } else {
        this.scenarioSets.data.splice(
          this.scenarioSets.selectedIndex,
          1,
          editingItem
        );
        this.scenarioSets.selectedItem = editingItem;
        this.$set(editingItem, "_selected", true);
      }
      this.publicEditor.visible = false;
    },
    postAddData(editingItem) {
      if (this.publicEditor.productType === "scenarioSet") {
        this.updateScenarioSetData(editingItem, "add");
      } else {
        this.updateScenarioData(editingItem, "add");
      }
    },
    postEditData(editingItem) {
      if (this.publicEditor.productType === "scenarioSet") {
        this.updateScenarioSetData(editingItem, "edit");
      } else {
        this.updateScenarioData(editingItem, "edit");
      }
    },
    setEditorData(flag) {
      //flag: {scenarioSet:true,scenario:false}
      let editingEntry = autoCompleteFields(
        this.isAdding
          ? { attributes: {} }
          : flag
            ? clone(this.scenarioSets.selectedItem)
            : clone(this.scenarios.selectedItem),
        flag ? this.scenarioSetTemplate : this.scenarioTemplate,
        this.isAdding
      );
      this.$store.commit("setEditingEntry", editingEntry);
      this.publicEditor.productType = flag ? "scenarioSet" : "scenario";
      this.publicEditor.visible = true;
    },
    retrieveScenarioData({ searchBy, sortBy, pageIndex = 1 }) {
      if (searchBy || searchBy === "") this.scenarios.searchBy = searchBy;
      if (sortBy) this.scenarios.sortBy = sortBy;
      this.scenarios.pageIndex = pageIndex;

      let fields = null,
        scenarioSetId = this.scenarioSets.selectedItem.id,
        defaultCondition = {
          attributeName: "Template Name",
          searchValues: ["SENSITIVE_SCENARIO"],
          searchType: "CUSTOMIZED",
          operator: "EQUAL",
          valueType: "STRING"
        },
        baseCondition = {
          attributeName: "Scenario Set ID",
          searchValues: [scenarioSetId]
        };

      if (this.scenarios.searchBy) fields = this.scenarioSearchableFields;

      let requestParameters = productApiHelper.getRequestData(
        defaultCondition,
        [baseCondition],
        this.scenarios.searchBy,
        this.scenarios.sortBy,
        fields,
        DATA_TYPES.SCENARIO,
        pageIndex
      );
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.scenarios.data = data.records;
            this.scenarios.pageCount = Math.ceil(data.recordCount / PAGE_SIZE);
            this.scenarios.selectedItem = null;
            this.scenarios.selectedIndex = -1;
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.message = "";
          }
        });
    },
    selectScenario({ currentItem, index }) {
      this.scenarios.selectedItem = currentItem;
      this.scenarios.selectedIndex = index;
    },
    searchFactorData({ searchBy }) {
      this.factors.searchBy = searchBy || "";
      this.loadMarketFactorData();
    },
    loadMarketFactorData() {
      let ids = [],
        current = this.scenarioSets.selectedItem;
      if (current.attributes["Risk Factor IDs"]) {
        ids = current.attributes["Risk Factor IDs"].value || [];
      }
      if (ids.length) {
        let defaultCondition = {
          searchType: "ID",
          searchValues: ids,
          operator: "IN",
          valueType: "String"
        };
        let baseConditions = this.factors.searchBy
          ? [
              {
                attributeName: "ID",
                searchValues: [this.factors.searchBy],
                operator: "LIKE"
              }
            ]
          : null;
        let requestParameters = productApiHelper.getRequestData(
          defaultCondition,
          baseConditions,
          null,
          null,
          null,
          DATA_TYPES.MARKETDATA,
          0
        );
        this.$api
          .request(endpoints.getProductData, requestParameters)
          .then(({ code, data, messages }) => {
            if (code === RESPONSE_CODE.INFO) {
              if (this.factors.searchBy) {
                this.factors.data = data.records;
              } else {
                if (this.scenarios.data.length) {
                  //traversal the request ids,if id not in response,make a virtual data
                  let emptyIds = [],
                    factors = data.records;
                  ids.forEach(id => {
                    let flag = factors.some(
                      factor => factor.attributes["ID"].value === id
                    );
                    if (!flag) {
                      let factorItem = clone(FACTOR_PATTERN);
                      factorItem.attributes["ID"].value = id;
                      factorItem.attributes["Name"].value = id;
                      factorItem.id = id;
                      factors.push(factorItem);
                    }
                  });
                  factors.forEach(factor => {
                    factor.attributes["Risk Factor ID"] = { value: factor.id };
                  });
                  this.factors.data = factors;
                } else {
                  this.factors.data = [];
                }
              }
              if (this.factors.data.length) {
                this.$refs.factors.selectDefault();
              } else {
                this.resetFactor();
              }
            } else {
              this.alert.title = code;
              this.alert.logs = messages;
              this.alert.message = "";
              this.alert.visible = true;
            }
          });
      } else {
        this.factors.data = [];
        this.resetFactor();
      }
    },
    loadDefFactorData() {
      if (!this.scenarioSets.selectedItem) return;
      let scenarioSetId = this.scenarioSets.selectedItem.id,
        baseConditions = [
          {
            attributeName: "Template Name",
            searchValues: ["SCENARIO_UNIT_DEF"]
          },
          {
            attributeName: "Scenario Set ID",
            searchValues: [scenarioSetId]
          }
        ];

      // divide pages when pageSize > 0 && startIndex >= 0
      let requestParameters = productApiHelper.getRequestData(
        null,
        baseConditions,
        null,
        null,
        null,
        DATA_TYPES.SCENARIO,
        0
      );
      this.$api
        .request(endpoints.getProductData, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.factors.pools = data.records;
          } else {
            this.factors.pools = [];
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.message = "";
          }
        });
    },
    selectFactor({ currentItem, index }) {
      this.factors.selectedIndex = index;
      // lookup id in pools(id =scenario.id + factor.id) if not exist push factor_pattern;
      let selectedId = currentItem.id,
        scenarioSetId = this.scenarioSets.selectedItem.id,
        type = currentItem.type;
      let shockValue = clone(currentItem.attributes["Curve Value"]);
      if (shockValue && shockValue.value) {
        let emptyValue = [];
        shockValue.value.dimensions[0].dimension.forEach(term =>
          emptyValue.push("")
        );
        shockValue.value.surfaceValue1D = emptyValue;
      }
      let factorScenario = [];
      this.scenarios.data.forEach(scenario => {
        let flag = false,
          searchId = scenario.id + "_" + selectedId;
        this.factors.pools.forEach(factor => {
          // if item&&item["shock Value"]=null replace  this value with currentFactor["Shock Value"]
          if (factor.id === searchId) {
            flag = true;
            if (!factor.attributes["Shock Value"]) {
              factor.attributes["Shock Value"] = shockValue;
            }
            factorScenario.push(factor);
          }
        });
        if (!flag) {
          let factor = clone(FACTOR_PATTERN),
            groupType = scenario.attributes["Scenario Group Type"].value;
          factor.id = searchId;
          factor.attributes["ID"].value = searchId;
          factor.attributes["Name"].value = selectedId;
          factor.attributes["Shock Value"] = shockValue;
          factor.attributes["Risk Factor ID"] = { value: selectedId };
          factor.attributes["Type"] = { value: type };
          factor.attributes["Scenario Group Type"] = { value: groupType };
          factor.attributes["Template Name"] = { value: "SCENARIO_UNIT_DEF" };
          factor.attributes["Scenario Set ID"] = { value: scenarioSetId };
          factor.attributes["Scenario ID"].value =
            scenario.attributes["Scenario ID"].value;
          factorScenario.push(factor);
        }
      });
      currentItem.scenarios = factorScenario;
      this.factors.selectedItem = currentItem;
      this.$refs.factorEditor.load();
    },
    saveFactors(factors) {
      this.factorSelector.visible = false;
      let editingItem = clone(this.scenarioSets.selectedItem);
      editingItem.attributes["Risk Factor IDs"] = { value: factors };
      let requestParameters = processApiHelper.getUpdateRequestData(
        editingItem,
        this.scenarioSetTemplate,
        DATA_TYPES.SCENARIO
      );
      this.$api
        .request(endpoints.processProduct, requestParameters)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.scenarioSets.selectedItem = data[0];
            this.$set(data[0], "_selected", true);
            this.scenarioSets.data.splice(
              this.scenarioSets.selectedIndex,
              1,
              data[0]
            );
            this.loadMarketFactorData();
          } else {
            this.alert.visible = true;
            this.alert.title = code;
            this.alert.logs = messages;
            this.alert.message = "";
          }
        });
    },
    editFactor({ update, coverStatus }) {
      if (update) this.loadDefFactorData();
      this.coverVisible = coverStatus;
    },
    removeSelectedFactor() {
      /**
       *delete current factor
       *update scenarioSet belong to
       *delete reference in scenario_unit_def
       */
      let defShocks = this.factors.selectedItem.scenarios;
      let deleteParams = null;
      let delFactors = defShocks.filter(item => !item.virtual);
      if (delFactors.length) {
        delFactors.forEach((factor, index) => {
          if (index) {
            deleteParams.inputData += csvParser.parseToCsvContent(
              factor,
              this.factorTemplate
            );
          } else {
            deleteParams = processApiHelper.getDeleteRequestData(
              factor,
              this.factorTemplate,
              DATA_TYPES.SCENARIO
            );
          }
        });
      }
      let scenarioSet = clone(this.scenarioSets.selectedItem),
        scenarioSetId = scenarioSet.id,
        ids = this.scenarioSets.selectedItem.attributes["Risk Factor IDs"]
          .value,
        factorId = this.factors.selectedItem.attributes["ID"].value;
      let restIds = ids.filter(id => id !== factorId);
      let defaultCondition = {
          attributeName: "Template Name",
          searchValues: ["SCENARIO_UNIT_DEF"],
          searchType: "CUSTOMIZED",
          operator: "EQUAL",
          valueType: "STRING"
        },
        baseConditions = [
          {
            attributeName: "Scenario Set ID",
            searchValues: [scenarioSetId]
          },
          {
            attributeName: "Risk Factor ID",
            searchValues: [factorId]
          }
        ],
        deleteParameters = productApiHelper.getRequestData(
          defaultCondition,
          baseConditions,
          null,
          null,
          null,
          DATA_TYPES.SCENARIO,
          0
        );
      scenarioSet.attributes["Risk Factor IDs"] = {
        value: restIds
      };
      deleteParameters.queryResultAction = "DELETE";
      let updateParameters = processApiHelper.getUpdateRequestData(
        scenarioSet,
        this.scenarioSetTemplate,
        DATA_TYPES.SCENARIO
      );
      let deleteReference = this.$api.request(
        endpoints.getProductData,
        deleteParameters
      );
      let updateScenarioSet = this.$api.request(
        endpoints.processProduct,
        updateParameters
      );
      Promise.all([deleteReference, updateScenarioSet]).then(
        ([deleteRes, updateRes]) => {
          if (
            deleteRes.code === RESPONSE_CODE.INFO &&
            updateRes.code === RESPONSE_CODE.INFO
          ) {
            let scenarioIndex = this.scenarioSets.selectedIndex;
            let factorIndex = this.factors.selectedIndex;
            this.scenarioSets.data.splice(scenarioIndex, 1, scenarioSet);
            this.scenarioSets.selectedItem = scenarioSet;

            this.factors.data.splice(factorIndex, 1);
            if (this.factors.data.length) {
              this.$refs.factors.selectDefault();
            } else {
              this.resetFactor();
            }
            if (deleteParams) {
              this.$api
                .request(endpoints.processProduct, deleteParams)
                .then(({ code, data, messages }) => {
                  if (code !== RESPONSE_CODE.INFO) {
                    this.alert.message = "";
                    this.alert.title = "error";
                    this.alert.logs = messages;
                    this.alert.visible = true;
                  }
                });
            }
          } else {
            let messages = deleteRes.messages.concat(updateRes.messages);
            this.alert.title = "error";
            this.alert.message = "";
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        }
      );
    },
    doRemove() {
      let requestData = null;
      if (this.removeType === "scenarioSet") {
        requestData = processApiHelper.getDeleteRequestData(
          this.scenarioSets.selectedItem,
          this.scenarioSetTemplate,
          DATA_TYPES.SCENARIO
        );
        this.$api
          .request(endpoints.processProduct, requestData)
          .then(({ code, data, messages }) => {
            if (code === RESPONSE_CODE.INFO) {
              this.scenarioSets.data.splice(this.scenarioSets.selectedIndex, 1);
              if (this.scenarioSets.data.length) {
                this.$refs.scenarioSets.selectDefault();
              } else {
                this.scenarioSets.selectedItem = null;
                this.scenarioSets.selectedIndex = -1;

                this.scenarios.data = [];
                this.scenarios.selectedItem = null;
                this.scenarios.selectedIndex = -1;

                this.factors.data = [];
                this.resetFactor();
              }
            } else {
              this.alert.visible = true;
              this.alert.title = code;
              this.alert.logs = messages;
              this.alert.message = "";
            }
          });
      } else {
        requestData = processApiHelper.getDeleteRequestData(
          this.scenarios.selectedItem,
          this.scenarioTemplate,
          DATA_TYPES.SCENARIO
        );
        this.$api
          .request(endpoints.processProduct, requestData)
          .then(({ code, data, messages }) => {
            if (code === RESPONSE_CODE.INFO) {
              this.scenarios.data.splice(this.scenarios.selectedIndex, 1);
              this.scenarios.selectedIndex = -1;
              this.scenarios.selectedItem = null;
              if (this.factors.selectedItem) {
                this.selectFactor({
                  currentItem: this.factors.selectedItem,
                  index: this.factors.selectedIndex
                });
              }
            } else {
              this.alert.visible = true;
              this.alert.title = code;
              this.alert.logs = messages;
              this.alert.message = "";
            }
          });
      }
    },
    resetFactor() {
      this.factors.selectedItem = null;
      this.factors.selectedIndex = -1;
      this.$refs.factorEditor.load();
    },
    resetStore() {
      this.$store.commit("setEditingEntry", {});
    },
    resizeX1(offset) {
      //calculate distance first  then assignment directly
      let leftWidth = this.$refs.left.clientWidth,
        middleWidth = this.$refs.middle.clientWidth,
        distance = Math.min(
          Math.max(SIZE.SCENARIO_SET_MIN_WIDTH - leftWidth, offset),
          middleWidth - SIZE.SCENARIO_MIN_WIDTH
        );

      this.$refs.left.style.width = leftWidth + distance + "px";
      this.$refs.middle.style.width = middleWidth - distance + "px";

      this.$refs.scenarioSets.resize();
      this.$refs.scenarios.resize();
    },
    resizeX2(offset) {
      let middleWidth = this.$refs.middle.clientWidth,
        rightWidth = this.$refs.right.clientWidth,
        distance = Math.min(
          Math.max(SIZE.SCENARIO_MIN_WIDTH - middleWidth, offset),
          rightWidth - SIZE.SCENARIO_FACTOR_MIN_WIDTH
        );

      this.$refs.middle.style.width = middleWidth + distance + "px";
      this.$refs.right.style.width = rightWidth - distance + "px";

      this.$refs.scenarios.resize();
      this.$refs.factors.resize();
    },
    resizeY(offset) {
      let topMinHeight = SIZE.GRID.PAGER_HEIGHT + SIZE.GRID.TABLE_MIN_HEIGHT,
        topHeight = this.$refs.top.clientHeight,
        bottomHeight = this.$refs.bottom.clientHeight,
        distance = Math.min(
          Math.max(topMinHeight - topHeight, offset),
          bottomHeight - SIZE.SCENARIO_BOTTOM_MIN_HEIGHT
        );

      this.$refs.top.style.height = topHeight + distance + "px";
      this.$refs.bottom.style.height = bottomHeight - distance + "px";

      this.$nextTick(() => {
        this.$refs.scenarioSets.resize();
        this.$refs.scenarios.resize();
        this.$refs.factors.resize();
        this.$refs.factorEditor.resize();
      });
    },
    getCacheData() {
      return {
        scenarioSets: this.scenarioSets,
        scenarios: this.scenarios,
        factors: this.factors
      };
    }
  }
};
</script>
<style scoped>
.frame {
  height: 100%;
}
.half {
  height: calc(50% - 4px);
  height: -ms-calc(50% - 4px);
  height: -moz-calc(50% - 4px);
  height: -webkit-calc(50% - 4px);
}
.scenario-sets,
.scenarios {
  float: left;
  height: 100%;
  width: calc(30% - 6px);
  width: -ms-calc(30% - 6px);
  width: -moz-calc(30% - 6px);
  width: -webkit-calc(30% - 6px);
}
.factors {
  float: left;
  height: 100%;
  width: calc(40% - 6px);
  width: -ms-calc(40% - 6px);
  width: -moz-calc(40% - 6px);
  width: -webkit-calc(40% - 6px);
}
</style>