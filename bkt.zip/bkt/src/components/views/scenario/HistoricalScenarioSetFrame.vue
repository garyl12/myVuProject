<template>
  <div class="frame" ref="frame">
    <grid
      :need-pager="true"
      :need-index="true"
      :columns="columns"
      :data="grid.data"
      :page-index="grid.pageIndex"
      :page-count="grid.pageCount"
      @select="selectScenario"
      @sort="retrieveData"
      @search="retrieveData"
      @prev-page="retrieveData"
      @next-page="retrieveData"
      @jump-page="retrieveData"
      ref="grid"
      >
      <button-bar
        :padding-right="0"
        :buttons="buttons" />
    </grid>
    <searcher
      :visible="grid.searcherVisible"
      :fields="searchableFields"
      :conditions="grid.searchBy"
      @search="retrieveData"
      @close="grid.searcherVisible=false"
      />
    <alert :config="alert" />
    <alert :config="removeConfirmation" />
    <historical-scenario-set-editor
      :visible="editor.visible"
      :isAdding="editor.isAdding"
      @close="editor.visible =false"
      @add="postAddData"
      @edit="postEditData"
      />
  </div>

</template>

<script>
import HistoricalScenarioSetEditor from "./HistoricalScenarioSetEditor";
import Alert from "@/components/common/Alert";
import Resizer from "@/components/common/Resizer";
import Grid from "@/components/common/Grid";
import ButtonBar from "@/components/common/ButtonBar";
import Searcher from "@/components/common/Searcher";
import endpoints from "@/api/endpoints";
import productApiHelper from "@/utils/productApiHelper";
import processApiHelper from "@/utils/processApiHelper";
import { mapGetters } from "vuex";
import { getColumns, autoCompleteFields, clone } from "@/utils";
import { DATA_KEYS, DATA_TYPES, RESPONSE_CODE } from "@/consts";
import mixin from "../mixin";
export default {
  name: "HistoricalScenarioSetFrame",
  components: {
    HistoricalScenarioSetEditor,
    Alert,
    Resizer,
    Grid,
    ButtonBar,
    Searcher
  },
  mixins: [mixin],
  data() {
    return {
      grid: {
        data: [],
        selectedItem: null,
        selectedIndex: -1,
        pageIndex: 0,
        pageCount: 0,
        searchBy: null,
        sortBy: null,
        searcherVisible: false
      },
      editor: {
        visible: false,
        isAdding: true
      },
      alert: {
        visible: false,
        title: "warning",
        message: "",
        log: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      },
      removeConfirmation: {
        visible: false,
        title: "warning",
        message: "remove_confirmation",
        logs: [],
        buttons: [
          {
            title: "confirm",
            callback: () => {
              this.removeConfirmation.visible = false;
              this.removeScenario();
            }
          },
          {
            title: "cancel",
            callback: () => {
              this.removeConfirmation.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      views: "getViews",
      templates: "getTemplates",
      currentNav: "getCurrentNav",
      attributes: "getAttributes"
    }),
    template() {
      return this.templates[DATA_KEYS.HISTORICAL_SCENARIO_SET_TEMPLATE];
    },
    searchableFields() {
      let fields = [];
      if (this.template) {
        this.template.measures.forEach(measure => {
          if (measure.searchAble) fields.push(measure);
        });
      }
      return fields;
    },
    columns() {
      let columns = [];
      if (this.views[DATA_KEYS.HISTORICAL_SCENARIO_DEFINITION_MANAGEMENT]) {
        this.views[
          DATA_KEYS.HISTORICAL_SCENARIO_DEFINITION_MANAGEMENT
        ][0].attributesInMainGrid
          .split(";")
          .forEach(colName => {
            if (this.attributes[colName]) {
              columns.push(this.attributes[colName]);
            } else {
              columns.push({
                attributeName: colName,
                displayName: colName
              });
            }
          });
      }
      return columns;
    },
    buttons() {
      return [
        {
          icon: "icon-xinjian",
          active: true,
          text: "add",
          callback: () => {
            this.editor.isAdding = true;
            this.editor.visible = true;
            this.setEditorEntry();
          }
        },
        {
          icon: "icon-search",
          active: true,
          text: "search",
          callback: () => {
            this.grid.searcherVisible = true;
          }
        },
        {
          icon: "icon-bianji",
          active: this.grid.selectedItem !== null,
          text: "edit",
          callback: () => {
            this.editor.visible = true;
            this.editor.isAdding = false;
            this.setEditorEntry();
          }
        },
        {
          icon: "icon-shanchu",
          active: this.grid.selectedItem !== null,
          text: "remove",
          callback: () => {
            this.removeConfirmation.visible = true;
          }
        }
      ];
    }
  },
  mounted() {
    this.loadScenarioData();
  },
  methods: {
    loadScenarioData() {
      if (this.cache[this.$route.path]) {
        let cacheData = JSON.parse(this.cache[this.$route.path]);
        this.grid = cacheData.scenario;
      } else {
        this.retrieveData({});
      }
    },
    retrieveData({ searchBy, sortBy, pageIndex = 1 }) {
      if (searchBy) this.grid.searchBy = searchBy;
      if (sortBy) this.grid.sortBy = sortBy;
      this.grid.pageIndex = pageIndex;
      let defaultCondition = {
        attributeName: "Template Name",
        operator: "EQUAL",
        searchType: "CUSTOMIZED",
        valueType: "STRING",
        searchValues: ["HISTORICAL_SCENARIO_SET"]
      };
      let requestParams = productApiHelper.getRequestData(
        defaultCondition,
        null,
        this.grid.searchBy,
        this.grid.sortBy,
        null,
        DATA_TYPES.SCENARIO,
        pageIndex
      );
      this.$api
        .request(endpoints.getProductData, requestParams)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.grid.data = data.records;
            this.grid.pageCount = Math.ceil(data.recordCount / data.pageSize);
            if (data.recordCount) {
              this.$refs.grid.selectDefault();
              this.grid.searcherVisible = false;
            }
          } else {
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        });
    },
    postAddData(currentItem) {
      this.grid.data.unshift(currentItem);
      this.$refs.grid.selectDefault();
      this.editor.visible = false;
      if (!this.grid.pageCount) this.grid.pageCount = 1;
    },
    postEditData(currentItem) {
      this.grid.data.splice(this.grid.selectedIndex, 1, currentItem);
      this.grid.selectedItem = currentItem;
      this.$set(currentItem, "_selected", true);
      this.editor.visible = false;
    },
    removeScenario() {
      let removeParams = processApiHelper.getDeleteRequestData(
        this.grid.selectedItem,
        this.template,
        DATA_TYPES.SCENARIO
      );
      this.$api
        .request(endpoints.processProduct, removeParams)
        .then(({ code, data, messages }) => {
          if (code === RESPONSE_CODE.INFO) {
            this.grid.data.splice(this.grid.selectedIndex, 1);
            if (this.grid.data.length) {
              this.$refs.grid.selectDefault();
            } else {
              this.grid.selectedItem = null;
              this.grid.selectedIndex = -1;
            }
          } else {
            this.alert.title = code;
            this.alert.message = "";
            this.alert.logs = messages;
            this.alert.visible = true;
          }
        });
    },
    setEditorEntry() {
      let entry = this.editor.isAdding
        ? { attributes: {} }
        : clone(this.grid.selectedItem);

      let editingEntry = autoCompleteFields(
        entry,
        this.template,
        this.editor.isAdding
      );
      this.$store.commit("setSelectedEntry", editingEntry);
      this.$store.commit("setEditingTemplate", this.template);
    },
    selectScenario({ currentItem, index }) {
      this.grid.selectedItem = currentItem;
      this.grid.selectedIndex = index;
    },
    getCacheData() {
      return {
        scenario: this.grid
      };
    }
  }
};
</script>

<style scoped>
.frame {
  height: 100%;
}
</style>