<template>
  <el-dialog class="editor" :title="$t_(title)" :visible="visible" 
    top="60px" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
    <div class="editor-inner">
      <editor-logger :logs="logs" />
        <div class="category-group" v-for="(category,index) in categoryGroups" :key ="index" v-show="category.fields.length">
          <div class="section">
            <span class="category-title">{{$t_(category.groupName||"")}}</span>
          </div>
          <fields-renderer
            :fields="category.fields"
            :entry="entry"
            :adding="isAdding"
            ref="fieldsRenderer"
            />
        </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="save">{{$t_("save")}}</el-button>
      <el-button @click="reset()">{{$t_("reset")}}</el-button>
      <el-button @click="close">{{$t_("close")}}</el-button>
	  </div>
    <alert :config="alert"/>
  </el-dialog>
</template>

<script>
import FieldsRenderer from "@/components/sections/FieldsRenderer";
import EditorLogger from "@/components/sections/EditorLogger";
import Alert from "@/components/common/Alert";
import { mapGetters } from "vuex";
import endpoints from "@/api/endpoints";
import { getEditorTitle, clone } from "@/utils";
import { assembleTemplateCategories } from "@/components/sections/FieldsRenderer";
import processApiHelper from "@/utils/processApiHelper";
import productApiHelper from "@/utils/productApiHelper";
import { RESPONSE_CODE, DATA_TYPES, DATA_KEYS } from "@/consts";

export default {
  name: "ScenarioEditor",
  components: {
    FieldsRenderer,
    EditorLogger,
    Alert
  },
  props: {
    visible: {
      type: Boolean,
      required: true
    },
    isAdding: {
      type: Boolean,
      required: true
    },
    productType: {
      type: String,
      required: true
    },
    scenarioSet: Object
  },
  data() {
    return {
      logs: [],
      entry: {},
      alert: {
        logs: [],
        title: "warning",
        message: "ID_duplicated",
        visible: false,
        buttons: [
          {
            title: "OK",
            callback: () => {
              this.alert.visible = false;
            }
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      templates: "getTemplates",
      editingEntry: "getEditingEntry"
    }),
    categoryGroups() {
      if (this.template && this.template.measures) {
        return assembleTemplateCategories(this.template, this.$api);
      }
      return [];
    },
    template() {
      return this.productType === "scenarioSet"
        ? this.templates[DATA_KEYS.SCENARIO_SET_TEMPLATE]
        : this.templates[DATA_KEYS.SENSITIVE_SCENARIO_TEMPLATE];
    },
    title() {
      let status = this.isAdding ? 0 : 1;
      return getEditorTitle(status);
    },
    baseConditions() {
      let baseCondition = {
          attributeName: "ID",
          searchValues: []
        },
        precondition = {
          attributeName: "Scenario Set ID",
          searchValues: [this.scenarioSet.id]
        };
      if (this.entry.attributes) {
        baseCondition.searchValues = [this.entry.attributes["ID"].value];
      }
      return this.productType === "scenarioSet"
        ? [baseCondition]
        : [baseCondition, precondition];
    },
    defaultCondition() {
      let searchValues =
        this.productType === "scenarioSet"
          ? ["SCENARIO_SET"]
          : ["SENSITIVE_SCENARIO"];
      return {
        attributeName: "Template Name",
        operator: "EQUAL",
        searchType: "CUSTOMIZED",
        searchValues: searchValues,
        valueType: "STRING"
      };
    }
  },
  watch: {
    visible(val) {
      this.reset();
    }
  },
  methods: {
    validate() {
      let invalidFields = [];
      this.$refs.fieldsRenderer.forEach(renderer => {
        let temp = renderer.validate();
        if (!temp.isValid) {
          invalidFields = invalidFields.concat(temp.invalidFields);
        }
      });
      if (invalidFields.length) {
        this.logs = [
          {
            msg: this.$t_("field_invalid_message") + invalidFields.join(","),
            type: RESPONSE_CODE.WARNING
          }
        ];
      } else {
        this.logs = [];
      }
      return invalidFields.length === 0;
    },
    validateID() {
      if (this.isAdding) {
        let requestData = productApiHelper.getRequestData(
          this.defaultCondition,
          this.baseConditions,
          null,
          null,
          null,
          DATA_TYPES.SCENARIO
        );
        return this.$api
          .request(endpoints.getProductData, requestData)
          .then(({ data }) => {
            if (data.records.length) {
              this.alert.visible = true;
              return Promise.reject();
            } else {
              return Promise.resolve();
            }
          });
      } else {
        return new Promise(resolve => {
          resolve();
        });
      }
    },
    save() {
      if (!this.validate()) return;
      this.validateID().then(() => {
        if (this.productType !== "scenarioSet" && this.isAdding) {
          let id =
            this.scenarioSet.id +
            "_" +
            this.entry.attributes["Scenario ID"].value;
          this.entry.attributes["ID"] = { value: id };
          this.entry.attributes["Scenario Set ID"] = {
            value: this.scenarioSet.id
          };
        } else {
          if (!this.entry.attributes["Risk Factor IDs"]) {
            this.entry.attributes["Risk Factor IDs"] = {
              value: []
            };
          }
        }
        let requestData = processApiHelper.getUpdateRequestData(
          this.entry,
          this.template,
          DATA_TYPES.SCENARIO
        );
        this.sendRequest(requestData).then(data => {
          if (this.isAdding) {
            this.$emit("add", data[0]);
          } else {
            this.$emit("edit", data[0]);
          }
          this.resetEditor();
        });
      });
    },
    sendRequest(requestData) {
      return this.$api.request(endpoints.processProduct, requestData).then(
        ({ code, data, messages }) => {
          this.logs = messages;
          if (code === RESPONSE_CODE.INFO) {
            return Promise.resolve(data);
          } else {
            return Promise.reject();
          }
        },
        function(err) {
          console.error(err);
          return Promise.reject();
        }
      );
    },
    reset() {
      this.entry = clone(this.editingEntry);
      this.resetEditor();
    },
    resetEditor() {
      this.logs = [];
      this.$nextTick(() => {
        this.$refs.fieldsRenderer.forEach(renderer => renderer.reset());
      });
    },
    close() {
      this.$emit("close");
      this.resetEditor();
    }
  }
};
</script>
<style scoped>
.editor-inner {
  margin: 0 20px;
  padding: 0 10px;
  height: calc(100% - 20px);
  border: 1px solid #ccc;
}
.section {
  border-bottom: 1px solid #ccc;
}
.category-title {
  display: inline-block;
  background-color: #4e586f;
  padding: 6px 12px;
  color: #ffffff;
  border-radius: 2px;
  margin-bottom: 2px;
  margin-top: 6px;
}
</style>
