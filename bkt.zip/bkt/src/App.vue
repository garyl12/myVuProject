<template>
	<div id="app">
		<router-view></router-view>
    <alert :config="sessionAlert" />
    <alert :config="exceptionAlert" />
	</div>
</template>
<script>
import Alert from "@/components/common/Alert";
import interceptor from "@/utils/interceptor";

export default {
  name: "app",
  components: { Alert },
  data() {
    return {
      sessionAlert: {
        visible: false,
        title: "information",
        message: "session_expired",
        buttons: [
          {
            title: "ok",
            callback: () => {
              this.sessionAlert.visible = false;
              this.$router.push({
                path: "/login",
                query: {
                  redirect: this.$route.path
                }
              });
            }
          }
        ]
      },
      exceptionAlert: {
        visible: false,
        title: "exception",
        logs: [],
        buttons: [
          {
            title: "close",
            callback: () => {
              this.exceptionAlert.visible = false;
            }
          }
        ]
      }
    };
  },
  created() {
    interceptor.session.expire = () => {
      this.sessionAlert.title = "information";
      this.sessionAlert.message = "session_expired";
      this.sessionAlert.visible = true;
    };
    interceptor.session.serverNotResponding = () => {
      this.sessionAlert.title = "error";
      this.sessionAlert.message = "server_not_responding";
      this.sessionAlert.visible = true;
      this.sessionAlert.buttons[0].callback = () => {
        this.sessionAlert.visible = false;
      };
    };
    interceptor.exceptionHandler.capture = messages => {
      this.exceptionAlert.visible = true;
      this.exceptionAlert.logs = messages;
    };
    interceptor.i18n.t = key => {
      return this.$t_(key);
    };
  }
};
</script>
<style>
#app {
  width: 100%;
  height: 100%;
}
</style>
