<template>
  <div class="demo">
    <log-alert
      :logs="logs"
      />
  </div>
</template>

<script>
import LogAlert from "@/components/sections/LogAlert";

export default {
  name: "Demo",
  components: {
    LogAlert
  },
  data() {
    return {
      logs: [
        {
          msg: "Nothing is impossible to a willing heart.",
          type: "warning"
        },
        {
          msg: "Nothing is impossible to a willing heart.",
          type: "error"
        },
        {
          msg: "Nothing is impossible to a willing heart.",
          type: "info"
        }
      ],
      exs: [
        "Nothing is impossible to a willing heart.",
        "Nothing is impossible to a willing heart.",
        "Nothing is impossible to a willing heart."
      ]
    };
  },
  mounted() {},
  methods: {}
};
</script>

<style scoped>
.demo {
  height: 400px;
  width: 600px;
  background-color: #fff;
  color: #000;
  overflow: auto;
}
</style>
