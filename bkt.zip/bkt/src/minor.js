import '@/utils/enhance'
import Vue from 'vue'
import i18n from './i18n'
import api from './api/index'
import Popout from '@/components/pages/Popout'
import store from './vuex'
import '@/static/css/reset.css'
import '@/static/css/common.css'
import {
  LOCALE,
  Languages
} from '@/consts'
import filters from '@/filters'

filters.register();
Vue.config.productionTip = false
i18n.locale = localStorage.getItem(LOCALE) || Languages.zhCN
Vue.prototype.$t_ = function (key) {
  if (key) {
    var i18nKey = key.toLowerCase().replace(/[ ]/g, '_')
    var i18nVal = this.$t(i18nKey);
    if (i18nVal === i18nKey) {
      return key;
    } else {
      return i18nVal;
    }
  } else {
    return "";
  }
}
Vue.prototype.$api = api;
new Vue({
  el: '#popout',
  template: '<Popout/>',
  store,
  i18n,
  components: {
    Popout
  }
})
