export const PIE_OPTION_PATTERN = {
  tooltip: {
    formatter: "{a} <br/>{b} : {c} ({d}%)"
  },
  legend: {
    data: []
  },
  series: [{
    name: "",
    type: "pie",
    center: ["50%", "50%"],
    data: []
  }]
};

export const BAR_OPTION_PATTERN = {
  tooltip: {
    trigger: "axis"
  },
  legend: {
    data: []
  },
  xAxis: [{
    type: "category",
    data: []
  }],
  yAxis: [{
    type: "value"
  }],
  series: [{
    name: "",
    type: "bar",
    data: []
  }]
};

export const CURVE_OPTION_PATTERN = {
  series: [],
  grid: {
    top: "30px",
    bottom: "30px",
    right: "50px"
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "line",
      label: {
        show: true,
        textStyle: {
          color: "#fff"
        },
        backgroundColor: "#383f52"
      }
    }
  },
  xAxis: {
    type: "category",
    boundaryGap: false,
    data: [],
    axisLine: {
      lineStyle: {
        color: "#666"
      }
    }
  },
  yAxis: {
    type: "value",
    axisLabel: {
      formatter: "{value}"
    },
    axisLine: {
      lineStyle: {
        color: "#666"
      }
    }
  },
  color: ["#cb400f", "#35e34d", "#0f1ccb", "#cb0fc9"]
}

export const CURVE_YAXIS_DATA_PATTERN = {
  type: "line",
  name: "",
  symbolSize: 0,
  lineStyle: {
    normal: {
      width: 2
    }
  },
  data: []
}
