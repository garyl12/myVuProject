export * from './chartOption'
export * from './size'
export * from './apiConsts'

export const PAGE_SIZE = 100

export const DEFAULT = "DEFAULT"

export const POPOUT_TAB_TYPE = "tabType"

export const POPOUT_TAB_DATA = "tabData"

export const TAB_TYPES = {
  BASIC_INFO: "Basic_Info",
  CASHFLOW: "Cashflow",
  CURVE: "Curve",
  ISSUE_RECORD: "Issue_Record",
  RATING: "Rating",
  VALUATION: "Valuation",
  TERM_STRUCTURE: "Term_Structure",
  UNDERLYING: "Underlying",
  COUNTERPARTY: "Counterparty",
  PORTFOLIO_CHART: "Portfolio_Chart",
  COLLATERAL_BOND_INFO: "Collateral_Bond_Info",
  LOG: "Log"
}

export const EDITOR_TAB_TYPES = {
  BASIC_INFO: "Basic Info",
  CASHFLOW: "Implied Cash Flows",
  CURVE: "Curve",
  ISSUE_RECORD: "Bond Issuence and Gurantee",
  RATING: "Security Rating info",
  THIRD_PARTY_VALUATION: "Thirdparty valuation",
  OPTION_SCHEDULE: "Option Schedule",
  COLLATERAL_BOND_INFO: "Collateral Bond Info"
}

export const DATA_KEYS = {
  CURVE: "CURVE",
  DIMENSIONS: "dimensions",
  CURVE_VALUE: "Curve Value",
  DIMENSION_COUNT: "dimensionCount",
  SURFACE_VALUE_1D: "surfaceValue1D",
  THIRDPARTY_VALUATION: "Thirdparty valuation",
  BKT_VALUATION: "BKT Valuation",
  BOND_ISSUANCE_AND_GUARANTEE: "Bond Issuance And Guarantee",
  SECURITY_RATING_INFO: "Security Rating info",
  CASHFLOW_INFO: "Implied Cash Flows",
  DAY_MILLISECONDS: 86400000,
  COUNTERPARTY: "Counterparty ID",
  UNDERLYING_ID: "Underlying ID",
  UNDERLYING_IDS: "Underlying IDs",
  UNDERLYING_BOND_ID: "Underlying Bond ID",
  BOND_ID: "Bond ID",
  COLLATERAL_BOND_INFO: "Collateral Bond Info",
  VALUATION_ORGANIZATION: "Valuation Organization",
  SCENARIO_SET_TEMPLATE: "SCENARIO_SET",
  SENSITIVE_SCENARIO_TEMPLATE: "SENSITIVE_SCENARIO",
  HISTORICAL_SCENARIO_SET_TEMPLATE: "HISTORICAL_SCENARIO_SET",
  FACTOR_TEMPLATE: "SCENARIO_UNIT_DEF",
  SCENARIO_SET_GROUP: "SCENARIO_SET_GROUP",
  SCENARIO_GROUP: "SCENARIO_GROUP",
  SCENARIO_UNIT_GROUP: "SCENARIO_UNIT_GROUP",
  SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT: "SENSITIVE_SCENARIO_DEFINITION_MANAGEMENT",
  HISTORICAL_SCENARIO_DEFINITION_MANAGEMENT: "HISTORICAL_SCENARIO_DEFINITION_MANAGEMENT"
}

export const LOCALE = "locale"

export const Languages = {
  zhCN: "zh",
  enUS: "en"
}

export const FIELD_TYPES = {
  STRING: "STRING",
  DOUBLE: "DOUBLE",
  BOOLEAN: "BOOLEAN",
  INTEGER: "INTEGER",
  DATE: "DATE",
  TABLE: "TABLE",
  LIST: "LIST",
  SURFACE: "SURFACE"
}

export const EDITOR_TAB_COLUMNS = {
  CASHFLOW: [],
  THIRD_PARTY_VALUATION: [],
  ISSUE_RECORD: ['Issuer ID', 'Issuer Name', 'Issue Type', 'Issue Object', 'First Issue price'],
  RATING: []
}

export const MAIN_MENU_NAMES = {
  INSTRUMENT: "products",
  CURVE: "marketdata"
}

export const REFERENCE_FIELDS = {
  MODEL: "Model",
  PORTFOLIO_ID: "Portfolio ID",
  COUNTERPARTY_ID: "Counterparty ID"
}

export const PORTFOLIO_DATA_KEYS = {
  PORTFOLIO_MANAGEMENT: "PORTFOLIO_MANAGEMENT",
  POSITION_GROUP: "POSITION_GROUP",
  PORTFOLIO_GROUP: "PORTFOLIO_GROUP",
  TEMPLATES: {
    PORTFOLIO: "PORTFOLIO",
    POSITION: "POSITION"
  },
  ID: "ID",
  ROOT_PORTFOLIO_ID: "0",
  PARENT_ID: "Parent ID",
  PORTFOLIO_ID: "Portfolio ID",
  ROOT_PORTFOLIO_ID: "0"
}

export const EDITOR_STATUS = {
  ADDING: 0,
  EDITING: 1,
  CLONING: 2,
  VIEWING: 3,
  EXPORTING: 4,
  DELETING: 5,
}

export const FILE_TYPES = [
  "EXCEL",
  "CSV",
  "PDF",
]

export const REPORT_UNIT_TYPE = {
  "HISTORICAL_VAR_REPORT_DEF": "VAR_REPORT_UNIT",
  "MARKET_RA_REPORT_DEF": "MARKET_RA_REPORT_UNIT",
  "MONTE_CARLO_VAR_REPORT_DEF": "VAR_REPORT_UNIT",
  "ACTUAL_PL_REPORT_DEF": "PL_REPORT_UNIT",
  "THEORETICAL_PL_REPORT_DEF": "PL_REPORT_UNIT",
  "SCENARIO_PL_REPORT_DEF": "SCENARIO_PL_REPORT_UNIT",
  "HISTORICAL_SVAR_REPORT_DEF": "STRESSED_VAR_REPORT_UNIT",
  "MONTE_CARLO_SVAR_REPORT_DEF": "STRESSED_VAR_REPORT_UNIT",
  "STRESS_TEST_REPORT_DEF": "STRESS_TEST_REPORT_UNIT"
}

export const REFERENCE_FIELD_TYPE = {
  TREE: 0,
  TABLE: 1
}
