/***************** API shared consts *****************/
export const RESPONSE_CODE = {
  INFO: "info",
  WARNING: "warning",
  ERROR: "error",
  EXCEPTION: "exception"
}
export const DATA_TYPES = {
  MARKETDATA: "MARKETDATA",
  LEGALENTITY: "LEGALENTITY",
  PORTFOLIO: "PORTFOLIO",
  POSITION: "POSITION",
  SCENARIO: "SCENARIO",
  REPORT: "REPORT",
  REPORT_UNIT: "REPORT_UNIT",
  RISK_FACTOR: "RISK_FACTOR",
  LOG: "DS_ORACLE_DB",
  TASK: "TASK",
  DICT: "DS_ORACLE_DB",
  TIME_INTERVAL: "DS_ORACLE_DB",
  CURRENCY: "SYS_MAINTENANCE",
  NONE: "NONE"
}
/***************** API shared consts *****************/

/***************** process API consts *****************/
export const PROCESS_REQUEST_PARAM = {
  actionType: null,
  dataFormat: "CSV",
  dataType: "NONE",
  inputData: null,
  persistType: null,
  skipOnFail: "true"
}
export const ACTION_TYPES = {
  PERSIST: "PERSIST",
  CALCULATION: "CALCULATION"
}
export const PERSIST_TYPES = {
  UPDATE: "UPDATE",
  DELETE: "DELETE"
}
/***************** process API consts *****************/

/***************** product API consts *****************/
export const PRODUCT_PARAMETER_PATTERN = {
  queryRequests: {
    queryConditions: [{
      searchObjects: []
    }],
    dataType: "",
    startIndex: 0,
    pageNo: 1,
    pageSize: 100,
    orderObjects: []
  },
  queryResultAction: "RETURNCONTENTS",
  outputFormat: "OBJECT"
}
export const CUSTOMIZED_CONDITION_PATTERN = {
  searchType: "CUSTOMIZED",
  searchValues: [],
  operator: "EQUAL",
  valueType: "STRING",
  attributeName: ""
}
export const DEFAULT_CONDITION_PATTERN = {
  searchType: "",
  searchValues: []
}
export const ORDER_PATTERN = {
  orderName: "",
  orderType: []
}
export const LOGIC_OPERATOR = {
  EQUAL: "EQUAL",
  GE: "GE",
  LE: "LE",
  LIKE: "LIKE",
  IN: "IN",
}
export const VALUE_TYPES = {
  INTEGER: "INTEGER",
  LONG: "LONG",
  DOUBLE: "LONG",
  BIGDECIMAL: "BIGDECIMAL",
  DATE: "DATE",
  STRING: "STRING",
  BOOLEAN: "BOOLEAN"
}
export const QUERY_RESULT_ACTION = {
  RETURNCONTENTS: "RETURNCONTENTS",
  DOWNLOAD: "DOWNLOAD"
}
/***************** product API consts *****************/
