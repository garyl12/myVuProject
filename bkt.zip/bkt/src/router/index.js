import Vue from 'vue'
import VueRouter from 'vue-router'
import api from '@/api'
Vue.use(VueRouter)

import Demo from '../Demo.vue'
import Login from '@/components/pages/Login'
import Home from '@/components/pages/Home'
import Help from '@/components/views/system/Help'
import Accounts from '@/components/views/system/Accounts'
import Functions from '@/components/views/system/Functions'
import Roles from '@/components/views/system/Roles'
import Task from '@/components/views/system/Task'
import TaskLog from "@/components/views/system/TaskLog"
import Log from '@/components/views/system/Log'
import Dictionary from '@/components/views/system/Dictionary'
import Template from '@/components/views/system/Template'
import Currency from '@/components/views/system/Currency'
import Calendar from '@/components/views/system/Calendar'
import TimeInterval from '@/components/views/system/TimeInterval'
import InstrumentFrame from '@/components/views/instrument/InstrumentFrame'
import PortfolioFrame from '@/components/views/portfolio/PortfolioFrame'
import PositionFrame from '@/components/views/portfolio/PositionFrame'
import ReportDetail from '@/components/views/report/common/ReportDetail'
import ReportDefinition from '@/components/views/report/common/ReportDefinition'
import ScenarioFrame from '@/components/views/scenario/ScenarioFrame'
import LimitReportDefinition from '@/components/views/report/limit/ReportDefinition'
import LimitReportDetail from '@/components/views/report/limit/ReportDetail'
import HistoricalScenarioSetFrame from '@/components/views/scenario/HistoricalScenarioSetFrame'

const routes = [{
  path: '/',
  redirect: '/login'
}, {
  path: '/demo',
  component: Demo,
  meta: {
    anonymous: true
  }
}, {
  path: '/login',
  component: Login,
  meta: {
    anonymous: true
  }
}, {
  path: '/system',
  component: Home,
  children: [{
    path: 'userandorganization',
    component: Accounts,
  }, {
    path: 'userandorganization/accounts',
    component: Accounts,
  }, {
    path: 'userandorganization/functions',
    component: Functions,
  }, {
    path: 'userandorganization/roles',
    component: Roles,
  }, {
    path: 'systemparameter',
    component: Template
  }, {
    path: 'systemparameter/template',
    component: Template
  }, {
    path: 'systemparameter/dicts',
    component: Dictionary,
  }, {
    path: 'systemparameter/currency',
    component: Currency
  }, {
    path: 'systemparameter/calendar',
    component: Calendar
  }, {
    path: 'systemparameter/timeinterval',
    component: TimeInterval
  }, {
    path: 'task',
    component: Task,
  }, {
    path: 'task/taskjob',
    component: Task,
  }, {
    path: 'task/tasklog',
    component: TaskLog,
  }, {
    path: '/system/log',
    component: Log,
  }, {
    path: 'help',
    component: Help,
  }]
}, {
  path: '/products',
  component: Home,
  children: [{
    path: ':category1',
    component: InstrumentFrame,
    children: [{
      path: ':category2',
      component: InstrumentFrame
    }]
  }]
}, {
  path: '/marketdata',
  component: Home,
  children: [{
    path: ':category1',
    component: InstrumentFrame,
    children: [{
      path: ':category2',
      component: InstrumentFrame,
      children: [{
        path: ':category3',
        component: InstrumentFrame,
      }]
    }]
  }]
}, {
  path: '/portfolio',
  component: Home,
  children: [{
    path: 'portfolio',
    component: PortfolioFrame
  }, {
    path: 'trade',
    component: PositionFrame
  }]
}, {
  path: '/risk',
  component: Home,
  children: [{
    path: ':definition',
    component: ReportDefinition,
    children: [{
      path: ':simulation',
      component: ReportDefinition,
    }]
  }]
}, {
  path: '/profitlossreport',
  component: Home,
  children: [{
    path: ':definition',
    component: ReportDefinition,
  }]
}, {
  path: '/stresstestreport',
  component: Home,
  children: [{
    path: ':definition',
    component: ReportDefinition,
  }]
}, {
  path: '/reportdetail',
  component: Home,
  children: [{
    path: ':id',
    component: ReportDetail,
    meta: {
      notInMenu: true
    }
  }]
}, {
  path: '/scenariospace',
  component: Home,
  children: [{
      path: 'sensitivescenario',
      component: ScenarioFrame
    },
    {
      path: 'historicalscenario',
      component: HistoricalScenarioSetFrame
    }
  ]
}, {
  path: '/limitspace',
  component: Home,
  children: [{
    path: 'limitmanagement',
    component: LimitReportDefinition
  }]
}, {
  path: '/limitreportdetails',
  component: Home,
  children: [{
    path: ':id',
    component: LimitReportDetail,
    meta: {
      notInMenu: true
    }
  }]
}]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) => {
  // if opening a page that one or more routes need authentication directly
  // instead of navigating from login page
  // need to check if user has logged in
  // if hasn't, should redirect to login page
  if (to.matched.some((item) => !item.meta.anonymous)) {
    if (api.authenticated()) {
      next();
    } else {
      next({
        path: '/login',
        query: {
          redirect: to.fullPath
        }
      });
    }
  } else {
    next();
  }
})

export default router
