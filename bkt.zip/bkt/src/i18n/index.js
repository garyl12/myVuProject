import Vue from 'vue'
import VueI18n from 'vue-i18n'
import cn from './resources/zh-CN'
import en from './resources/en-US'
import elEN from 'element-ui/lib/locale/lang/en'
import elCN from 'element-ui/lib/locale/lang/zh-CN'
import {
  Languages
} from '@/consts'

Vue.use(VueI18n)

export default new VueI18n({
  locale: Languages.zhCN,
  messages: {
    zh: {
      ...cn,
      ...elCN
    },
    en: {
      ...en,
      ...elEN
    }
  },
})
