import axios from 'axios'
import Loading from "element-ui/lib/loading";
import {
  baseUrl
} from './endpoints'
import interceptor from '@/utils/interceptor'
import {
  LOCALE,
  RESPONSE_CODE
} from '@/consts'

const AuthTokenHeader = "Access-Token"
let loadingInstance = null;

const initializeLoading = () => {
  loadingInstance = Loading.service({
    lock: true,
    text: interceptor.i18n.t("processing"),
    background: "rgba(255, 255, 255, 0.6)",
    customClass: "loading"
  });
}

const setAccessToken = (token) => {
  if (token) {
    sessionStorage.setItem(AuthTokenHeader, token);
  } else {
    sessionStorage.removeItem(AuthTokenHeader);
  }
}

const processFailedRequest = (status) => {
  loadingInstance.close();
  switch (status) {
    case 401:
      interceptor.session.expire();
      sessionStorage.removeItem(AuthTokenHeader);
      break;
    case 0:
      interceptor.session.serverNotResponding();
      sessionStorage.removeItem(AuthTokenHeader);
      break;
  }
}

export default {
  authenticated() {
    return sessionStorage.getItem(AuthTokenHeader);
  },
  request(endpoint, data) {
    return new Promise((resolve, reject) => {
      initializeLoading();
      axios({
        method: endpoint.method,
        url: (localStorage.getItem("baseUrl") || baseUrl) + endpoint.url,
        data: data || endpoint.data,
        headers: {
          "Access-Token": sessionStorage.getItem(AuthTokenHeader),
          Lang: localStorage.getItem(LOCALE),
        },
      }).then(({
        data,
        headers
      }) => {
        loadingInstance.close();
        interceptor.logger.log(data.messages);
        setAccessToken(headers[AuthTokenHeader.toLowerCase()]);
        if (data.code === RESPONSE_CODE.EXCEPTION) {
          interceptor.exceptionHandler.capture(data.messages);
          reject(data);
        } else {
          resolve(data)
        }
      }, ({
        response = {
          data: null,
          status: 0
        }
      }) => {
        processFailedRequest(response.status);
        reject(response.data);
      });
    });
  },
  upload(endpoint, data) {
    return new Promise((resolve, reject) => {
      initializeLoading();
      axios({
        method: "post",
        url: (localStorage.getItem("baseUrl") || baseUrl) + endpoint.url,
        data: data,
        headers: {
          "Access-Token": sessionStorage.getItem(AuthTokenHeader),
          Lang: localStorage.getItem(LOCALE),
          'Content-Type': 'multipart/form-data'
        },
      }).then(({
        data,
        headers
      }) => {
        loadingInstance.close();
        interceptor.logger.log(data.messages);
        setAccessToken(headers[AuthTokenHeader.toLowerCase()]);
        if (data.code === RESPONSE_CODE.EXCEPTION) {
          interceptor.exceptionHandler.capture(data.messages);
          reject(data);
        } else {
          resolve(data)
        }
      }, ({
        response = {
          data: null,
          status: 0
        }
      }) => {
        processFailedRequest(response.status);
        reject(response.data);
      });
    })
  }
}
