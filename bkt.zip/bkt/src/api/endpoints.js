const endpoints = {
  login: {
    url: "/trams/login",
    method: "post"
  },
  logout: {
    url: "/trams/logout",
    method: "post"
  },
  getAccounts: {
    url: "/trams/accounts",
    method: "post"
  },
  getRegistryData: {
    url: "/trams/system/registry/findValue",
    method: "post",
    data: {
      path: "/System/Global/Market Date"
    }
  },
  getMenu: {
    url: "/trams/auth/sysMenu/listByUserId",
    method: "post"
  },
  getTemplates: {
    url: "/trams/auth/template",
    method: "get",
  },
  getViews: {
    url: "/trams/auth/views/viewsList",
    method: "get",
  },
  getAttributes: {
    url: "/trams/auth/attributes/attributesList",
    method: "get",
  },
  getDicts: {
    url: "/trams/dict/tree",
    method: "post"
  },
  saveDicts: {
    url: "/trams/auth/dict/save",
    method: "post",
    traditional: true
  },
  deleteDicts: {
    url: "/trams/auth/dict/delete",
    method: "post"
  },
  sortDicts: {
    url: "/trams/auth/dict/sort",
    method: "post",
    traditional: true
  },
  getRoles: {
    url: "/trams/auth/role/selectRoleFunAll",
    method: "post",
  },
  removeRole: {
    url: "/trams/auth/role/remove",
    method: "post"
  },
  getDataAuthRangeOptions: {
    url: "/trams/auth/dict/typeList",
    method: "post",
    data: {
      dictType: 'DATA_AUTHORITY_RANGE'
    }
  },
  addRole: {
    url: "/trams/auth/role/add",
    method: "post"
  },
  getRoleFunctions: {
    url: "/trams/auth/function/listByRoleId",
    method: "post"
  },
  getProductData: {
    url: "/trams/product",
    method: "post",
  },
  //account part
  getAccountList: {
    url: "/trams/auth/user/findAll",
    method: "post"
  },
  getUserLogList: {
    url: "/trams/auth/userChangeLog/list",
    method: "post"
  },
  getOrganizationList: {
    url: "/trams/auth/organization/findAll",
    method: "post"
  },
  getLeaderList: {
    url: "/trams/auth/user/findLeader",
    method: "post"
  },
  updateAccountInfo: {
    url: "/trams/auth/user/update",
    method: "post"
  },
  enableAccount: {
    url: "/trams/auth/user/isEnabled",
    method: "post",
    traditional: true
  },
  addAccount: {
    url: "/trams/auth/user/insert",
    method: "post",
    traditional: true
  },
  deleteAccount: {
    url: "/trams/auth/user/delete",
    method: "get"
  },
  getAccountList: {
    url: "/trams/auth/user/findAll",
    method: "post"
  },
  getSysLogList: {
    url: "/trams/auth/systemLog/list",
    method: "post"
  },
  processProduct: {
    url: "/trams/product/process",
    method: "post"
  },
  refreshReportData: {
    url: "/trams/report/refresh",
    method: "post"
  },
  getPricingModels: {
    url: "/trams/pricingModels/findByAppliance",
    method: "post"
  },
  upload: {
    url: "/trams/product/upload",
  },
  downloadFile: {
    url: "/trams/file/download",
    method: "post"
  },
  getTaskRefTemplate: {
    url: "/trams/task/job/list",
    method: "get"
  },
  startTask: {
    url: "/trams/task/schedule/run",
    method: "post"
  },
  pauseTask: {
    url: "/trams/task/schedule/pause",
    method: "post"
  },
  resumeTask: {
    url: "/trams/task/schedule/resume",
    method: "post"
  },
  terminateTask: {
    url: "/trams/task/schedule/shutdown",
    method: "post"
  }
}

export default endpoints

const baseUrlRegexp = /^https?:\/\/[\w:\.]+/g

export const baseUrl = window.location.href.match(baseUrlRegexp)[0]
