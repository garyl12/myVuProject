const state = {
  current: {},
  visitedNavs: [],
  allNavs: []
}

const mutations = {
  setCurrentNav(state, nav) {
    state.current = nav;
  },
  setAllNavs(state, navs) {
    state.allNavs = navs;
  },
  pushVisitedNavs(state, val) {
    state.current = val;
    var navs = state.visitedNavs,
      i = 0,
      isExisting = false;
    for (; i < navs.length; i++) {
      // check if the pending navigator is existing
      if (navs[i].id === val.id) {
        isExisting = true;
        if (i > 7) {
          // if existing but not among the first 8, remove it from original position, and top it
          navs.splice(i, 1);
          isExisting = false;
        } else {
          // if existing and it's among the first 8, replace old navigator with the pending one
          // to update name of the navigator
          navs.splice(i, 1, val);
        }
        break;
      }
    }
    if (!isExisting) navs.unshift(val);
  },
  topNavAtIndex(state, index) {
    var nav = state.visitedNavs.splice(index, 1)[0];
    state.visitedNavs.unshift(nav);
    state.current = state.visitedNavs[0];
  },
  removeNavAtIndex(state, index) {
    if (state.visitedNavs.length > 1) {
      if (state.visitedNavs[index].id === state.current.id) {
        state.visitedNavs.splice(index, 1);
        state.current = state.visitedNavs[0];
      } else {
        state.visitedNavs.splice(index, 1);
      }
    }
  }
}

const getters = {
  getCurrentNav: state => state.current,
  getVisitedNavs: state => state.visitedNavs,
  getAllNavs: state => state.allNavs
}

export default {
  state,
  mutations,
  getters
}
