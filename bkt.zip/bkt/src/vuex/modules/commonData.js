const state = {
  views: [],
  templates: {},
  dicts: [],
  attributes: {},
  mapping: {},
  marketDate: 0,
  currentUser: ""
}

const mutations = {
  setViews(state, val) {
    state.views = val;
  },
  setTemplates(state, val) {
    state.templates = val;
  },
  setDicts(state, val) {
    state.dicts = val;
  },
  setAttributes(state, val) {
    state.attributes = val;
  },
  setMarketDate(state, val) {
    state.marketDate = val;
    localStorage.setItem('marketDate', val);
  },
  setUser(state, val) {
    let userStr = JSON.stringify(val);
    state.currentUser = userStr
    localStorage.setItem("currentUser", userStr);
  },
  setMapping(state, val) {
    state.mapping = val;
  },
}

const getters = {
  getViews: state => state.views,
  getTemplates: state => state.templates,
  getDicts: state => state.dicts,
  getMarketDate: state => new Date(state.marketDate || Number(localStorage.getItem('marketDate'))),
  getAttributes: state => state.attributes,
  getMapping: state => state.mapping,
  getUser: state => JSON.parse(state.currentUser || localStorage.getItem("currentUser"))
}

export default {
  state,
  mutations,
  getters
}
