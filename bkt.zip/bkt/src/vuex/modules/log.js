const MAX_LOG_COUNT = 100

const state = {
  ignoring: {},
  logs: []
}

const mutations = {
  clearLogs(state) {
    state.logs = [];
  },
  pushLog(state, logs) {
    logs.forEach(log => {
      let ignoring = state.ignoring[log.type];
      if (!ignoring) {
        // if log reaches maximum count, flush oldest
        if (state.logs.length === MAX_LOG_COUNT) {
          let oldest = state.logs.shift();
        }
        state.logs.push(log);
      }
    })
  },
  setIgnoring(state, ignoring) {
    state.ignoring = ignoring;
  }
}

const getters = {
  getLogs: state => state.logs,
}

export default {
  state,
  mutations,
  getters
}
