const state = {
  selectedEntry: {},
  editingTemplate: {},
  editingEntry: {},
  cache: {}
}

const mutations = {
  setSelectedEntry(state, entry) {
    state.selectedEntry = entry;
  },
  setEditingEntry(state, entry) {
    state.editingEntry = entry;
  },
  setEditingTemplate(state, template) {
    state.editingTemplate = template;
  },
  cacheFrame(state, {
    url,
    data
  }) {
    state.cache[url] = data;
  },
  clearFrameCache(state, url) {
    if (url) {
      state.cache[url] = null;
    } else {
      state.cache = {};
    }
  }
}

const getters = {
  getSelectedEntry: state => state.selectedEntry,
  getEditingEntry: state => state.editingEntry,
  getEditingTemplate: state => state.editingTemplate,
  getFrameCache: state => state.cache
}

export default {
  state,
  mutations,
  getters
}
