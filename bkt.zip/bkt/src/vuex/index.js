import Vue from 'vue'
import Vuex from 'vuex'
import navigation from './modules/navigation'
import commonData from './modules/commonData'
import frame from './modules/frame'
import log from './modules/log'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    navigation,
    log,
    commonData,
    frame
  }
})
