import '@/utils/enhance'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './vuex'
import i18n from './i18n'
import api from './api/index'
import ElDialog from 'element-ui/lib/dialog'
import ElDatePicker from 'element-ui/lib/date-picker'
import ElButton from 'element-ui/lib/button';
import { i18n as ElI18n } from 'element-ui/lib/locale';
import 'element-ui/lib/theme-chalk/button.css'
import 'element-ui/lib/theme-chalk/loading.css'
import 'element-ui/lib/theme-chalk/input.css'
import 'element-ui/lib/theme-chalk/icon.css'
import 'element-ui/lib/theme-chalk/date-picker.css'
import 'element-ui/lib/theme-chalk/dialog.css'
import '@/static/css/reset.css'
import '@/static/css/common.css'
import '@/static/css/field-common.css'
import {
  LOCALE,
  Languages
} from '@/consts'
import filters from '@/filters'

filters.register();
[ElDialog, ElDatePicker, ElButton].forEach((component) => {
  Vue.use(component);
  if (component === ElDatePicker) {
    ElI18n((key, value) => i18n.t(key, value));
  }
})
Vue.config.productionTip = false
Vue.prototype.$api = api;
Vue.prototype.$t_ = function (key) {
  if (key) {
    var i18nKey = key.toLowerCase().replace(/[ ]/g, '_')
    var i18nVal = this.$t(i18nKey);
    if (i18nVal === i18nKey) {
      return key;
    } else {
      return i18nVal;
    }
  } else {
    return "";
  }
}

i18n.locale = localStorage.getItem(LOCALE) || Languages.zhCN

new Vue({
  el: '#app',
  template: '<App/>',
  router,
  store,
  i18n,
  components: {
    App
  }
})
