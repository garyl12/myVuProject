export default {
  parseToCsvContentMulti(dataArray, template) {
    let content = "";
    dataArray.forEach((data, index) => {
      content += this.parseToCsvContent(data, template, index === 0);
    });
    return content;
  },
  parseToCsvContent(data, template, includingTemplate = true) {
    var content = "",
      row1Content = "",
      row2Content = "",
      row3Content = "",
      subName = "",
      row1Data = ["@templateid=" + template.id],
      row2Data = [template.id],
      row3Data = [""],
      curveDataList = [],
      tableDataList = [];
    template.measures.forEach((measure) => {
      if (measure.output) return;
      row1Data.push("");
      switch (measure.dataType) {
        case "TABLE":
          if (data.attributes[measure.name]) {
            tableDataList.push({
              measureName: measure.name,
              subMeasures: measure.subMeasures,
              value: data.attributes[measure.name].value || []
            });
          }
          break;
        case "SURFACE":
          //TODO: transform array to proper format
          subName = measure.name;
          if (data.attributes[measure.name] && data.attributes[measure.name].value) {
            curveDataList.push({
              measureName: measure.name,
              subMeasures: measure.subMeasures,
              value: data.attributes[measure.name].value || {}
            });
          }
          break;
        default:
          row2Data.push(measure.name);
          if (measure.list) {
            row3Data.push("\"{0}\"".format(((data.attributes[measure.name] || {
              value: []
            }).value || []).join(';')));
          } else {
            row3Data.push("\"{0}\"".format((data.attributes[measure.name] || {
              value: ""
            }).value));
          }
          break;
      }
    });
    row1Content = row1Data.join(",") + "\r\n";
    row2Content = row2Data.join(",") + "\r\n";
    row3Content = row3Data.join(",") + "\r\n";
    content = (includingTemplate ? row1Content : "") + row2Content + row3Content +
      this.parseTableDataToCsvContent(tableDataList) +
      this.parseCurveDataToCsvContent(curveDataList, subName);
    return content;
  },
  parseTableDataToCsvContent(dataList) {
    var content = "";
    dataList.forEach((piece) => {
      var sub = "",
        subHeaders = ["sub(" + piece.measureName + ")"];
      piece.records = [];
      //transform object matrix to object list
      piece.value.forEach((attributes) => {
        var record = {};
        for (let key in attributes) {
          record[key] = attributes[key];
        }
        piece.records.push(record);
      })
      if (!piece.records.length) return;
      //transform object list to string matrix
      piece.matrix = [];
      piece.subMeasures.forEach((measure) => {
        if (measure.output) return;
        subHeaders.push(measure.name);
        piece.records.forEach((record, index) => {
          piece.matrix[index] = piece.matrix[index] || [""];
          piece.matrix[index].push("\"{0}\"".format((record[measure.name] || {
            value: ""
          }).value));
        });
      });
      sub += subHeaders.join(',') + "\r\n";
      piece.matrix.forEach((row) => {
        sub += row.join(",") + "\r\n";
      })
      content += sub + "\r\n";
    })
    return content;
  },
  parseCurveDataToCsvContent(dataList, subName) {
    var content = "",
      sub = "",
      curveData = {},
      subHeaders = ["sub(" + subName + ")", "index", "row", "value", "column"],
      matrix = [];
    if (dataList.length) {
      curveData = dataList[0];
      curveData.value.surfaceValue1D.forEach((item, index) => {
        var arr = [];
        arr.push('');
        arr.push(curveData.value.dimensions[0].dimension[index]);
        arr.push('');
        arr.push(item);
        matrix.push(arr);
      })
      sub += subHeaders.join(',') + "\r\n";
      matrix.forEach((row) => {
        sub += "," + row.join(",") + "\r\n";
      })
      content += sub;
    }

    return content;
  }
}
