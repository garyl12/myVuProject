let scrollBarWidth;

export default function () {
    if (scrollBarWidth !== undefined) return scrollBarWidth;

    const div = document.createElement('div'),
        style = {
            width: "30px",
            height: "30px",
            overflow: "scroll",
            position: "absolute",
            top: "-30px",
            left: "-30px"
        };
    for (let attr in style) {
        div.style[attr] = style[attr];
    }
    document.body.appendChild(div);
    scrollBarWidth = div.offsetHeight - div.clientHeight;
    document.body.removeChild(div);
    return scrollBarWidth;
};
