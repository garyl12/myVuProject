import moment from 'moment';
const dayMilliseconds = 24 * 60 * 60 * 1000;
const specialTermPattern = /^[otsOTS][nN]|SPOT$/;
const numberTermPattern = /^[-+]?\d+(\.?\d*)?$/;
const numberWithStringTermPattern = /^[-+]?\d+(\.?\d*)?[dwmyDWMY]$/;

const termParser = {
  "D": function (day, currentDate) {
    let termIntValue = day < 0 ? Math.ceil(day) : Math.floor(day);
    return moment(currentDate).add(termIntValue, "day").toDate();
  },
  "W": function (week, currentDate) {
    let termIntValue = new Number(week) < 0 ? Math.ceil(week) : Math.floor(week);
    return moment(currentDate).add(termIntValue * 7, "day").toDate();
  },
  "M": function (month, currentDate) {
    let termIntValue = new Number(month) < 0 ? Math.ceil(month) : Math.floor(month);
    return moment(currentDate).add(termIntValue, "month").toDate();
  },
  "Y": function (years, currentDate) {
    let termIntValue = new Number(years) < 0 ? Math.ceil(years) : Math.floor(years);
    let nextDate = moment(currentDate).add(termIntValue, "year").toDate();
    if (years - termIntValue == 0) {
      return nextDate;
    } else {
      let isNegativeTerm = years < 0;
      let tempNextYear = isNegativeTerm ? moment(nextDate).add(-1, "year").toDate() : moment(nextDate).add(1, "year").toDate();
      let termContainsFeb29 = isNegativeTerm ? containsFeb29(tempNextYear, nextDate) : containsFeb29(nextDate, tempNextYear);
      let base = termContainsFeb29 ? 366 : 365;
      let convertStandardTermToDays = base * (years - termIntValue);
      convertStandardTermToDays = convertStandardTermToDays < 0 ? Math.ceil(convertStandardTermToDays) : Math.floor(convertStandardTermToDays);
      return moment(nextDate).add(convertStandardTermToDays, "day").toDate();
    }
  },
  "ON": function (term, currentDate) {
    return moment(currentDate).add(1, "day").toDate();
  },
  "TN": function (term, currentDate) {
    return moment(currentDate).add(2, "day").toDate();
  },
  "SN": function (term, currentDate) {
    return moment(currentDate).add(3, "day").toDate();
  },
  "SPOT": function (term, currentDate) {
    return moment(currentDate).add(0, "day").toDate();
  }
}

const containsFeb29 = function (from, to) {
  if (from == null || to == null) {
    return false;
  }
  let startYear = from.getFullYear();
  let endYear = to.getFullYear();
  for (let year = startYear; year <= endYear; year++) {
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
      let feb29 = moment(year + "-02-29").toDate();
      if (feb29.getTime() >= from.getTime() && feb29.getTime() < to.getTime()) {
        return true;
      }
    }
  }
  return false;
}

const getDateTime = function (millisecond) {
  var date = new Date(parseInt(millisecond));
  var YY = date.getFullYear();
  var MM = date.getMonth() + 1;
  var DD = date.getDate();
  var hh = date.getHours();
  var mm = date.getMinutes();
  var ss = date.getSeconds();
  return [
    YY,
    (MM > 9 ? '' : '0') + MM,
    (DD > 9 ? '' : '0') + DD,
    (hh > 9 ? '' : '0') + hh,
    (mm > 9 ? '' : '0') + mm,
    (ss > 9 ? '' : '0') + ss
  ];
}

export const convertStandardTermToDays = function (term, currentDate) {
  if (currentDate == null) {
    currentDate = new Date();
  }
  var date = nextDate(term, currentDate);
  if (date == null) {
    return null;
  } else {
    return Math.floor((date.getTime() - currentDate.getTime()) / (24 * 60 * 60 * 1000));
  }
}

export const nextDate = function (term, currentDate) {
  if (term == null || currentDate == null) {
    return null;
  }
  term = "" + term;
  if (term.match(specialTermPattern)) {
    return termParser[term.toUpperCase()](null, currentDate);
  }
  if (term.match(numberTermPattern)) {
    let termIntValue = new Number(term) < 0 ? Math.ceil(term) : Math.floor(term);
    return moment(currentDate).add(termIntValue, "day").toDate();
  }
  if (!term.match(numberWithStringTermPattern)) {
    throw new Error("invalid term string");
  }
  var type = term.substring(term.length - 1).toUpperCase();
  var termValue = new Number(term.substring(0, term.length - 1));
  return termParser[type](termValue, currentDate);
}

export const convertStandardTermToDate = function (term, currentDate) {
  return getDateTime(nextDate(term, currentDate).getTime()).splice(0, 3).join("-");
}

export const parseToDate = function (millisecond, separator) {
  return getDateTime(millisecond).slice(0, 3).join(separator || '-');
}

export const parseToTime = function (millisecond) {
  return getDateTime(millisecond).slice(3).join('-');
}

export const getFutureDate = function (days) {
  var now = new Date().getTime();
  var millisecond = parseInt(days) * dayMilliseconds + now;
  return getDateTime(millisecond).slice(0, 3).join("-");
}

export const parseToDateTime = function (millisecond) {
  var dateTimeArr = getDateTime(millisecond);
  return dateTimeArr.slice(0, 3).join('-') + ' ' + dateTimeArr.slice(3).join('-');
}

export const validateStandardTerm = function (standardTerm) {
  var standardTermRegexp = /(^[1-9]\d*[MWD]?$)|(^[otsOTS][nN]|SPOT$)|^\d+(\.\d{1,4})?Y$/i
  return standardTermRegexp.test(standardTerm)
}