export default {
  logger: {
    log(logs) {}
  },
  session: {
    expire() {},
    serverNotResponding() {}
  },
  exceptionHandler: {
    capture(message) {}
  },
  i18n: {
    t() {}
  }
}
