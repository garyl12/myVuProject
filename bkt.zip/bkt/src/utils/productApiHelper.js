import {
  clone
} from '@/utils'
import {
  PRODUCT_PARAMETER_PATTERN,
  CUSTOMIZED_CONDITION_PATTERN,
  LOGIC_OPERATOR,
  QUERY_RESULT_ACTION,
  PAGE_SIZE,
  FIELD_TYPES
} from '@/consts'

export default {
  getRequestData(defaultCondition, baseConditions, searchBy, sortBy, fields, dataType, pageIndex, pageSize) {
    let data = clone(PRODUCT_PARAMETER_PATTERN),
      queryConditions = [];
    if (fields && searchBy) {
      // using Grid default searcher, count of query conditions should be the same as count of fields
      fields.forEach(field => {
        queryConditions.push({
          searchObjects: []
        })
      })
    } else {
      queryConditions = [{
        searchObjects: []
      }];
    }
    if (defaultCondition) {
      queryConditions.forEach(q =>
        q.searchObjects.push({
          ...defaultCondition
        }));
    }
    if (baseConditions) {
      baseConditions.forEach(condition => {
        let searchObj = clone(CUSTOMIZED_CONDITION_PATTERN);
        searchObj.attributeName = condition.attributeName;
        searchObj.searchValues = condition.searchValues;
        searchObj.operator = condition.operator || "EQUAL";
        queryConditions.forEach(q => q.searchObjects.push(searchObj));
      })
    }
    if (searchBy) {
      if (searchBy instanceof Array) {
        // condition from searcher
        searchBy.forEach(field => {
          if (
            field.valueType === FIELD_TYPES.INTEGER ||
            field.valueType === FIELD_TYPES.DOUBLE ||
            field.valueType === FIELD_TYPES.DATE
          ) {
            if (field.value.max) {
              let searchObj = clone(CUSTOMIZED_CONDITION_PATTERN);
              searchObj.attributeName = field.key;
              searchObj.valueType = field.valueType;
              searchObj.searchValues.push(field.value.max);
              searchObj.operator = LOGIC_OPERATOR.LE;
              queryConditions.forEach(q => q.searchObjects.push(searchObj));
            }
            if (field.value.min) {
              let searchObj = clone(CUSTOMIZED_CONDITION_PATTERN);
              searchObj.attributeName = field.key;
              searchObj.valueType = field.valueType;
              searchObj.searchValues.push(field.value.min);
              searchObj.operator = LOGIC_OPERATOR.GE;
              queryConditions.forEach(q => q.searchObjects.push(searchObj));
            }
          } else {
            let searchObj = clone(CUSTOMIZED_CONDITION_PATTERN);
            searchObj.attributeName = field.key;
            searchObj.valueType = field.valueType;
            searchObj.searchValues.push(field.value);
            searchObj.operator = LOGIC_OPERATOR.LIKE;
            queryConditions.forEach(q => q.searchObjects.push(searchObj));
          }
        })
      } else {
        // condition from default searcher
        if (fields) {
          fields.forEach((field, index) => {
            let searchObj = clone(CUSTOMIZED_CONDITION_PATTERN);
            searchObj.attributeName = field.attributeName;
            searchObj.valueType = field.dataType;
            searchObj.operator =
              (field.dataType === FIELD_TYPES.INTEGER ||
                field.dataType === FIELD_TYPES.DOUBLE ||
                field.dataType === FIELD_TYPES.DATE) ?
                LOGIC_OPERATOR.EQUAL : LOGIC_OPERATOR.LIKE;
            searchObj.searchValues.push(searchBy);
            queryConditions[index].searchObjects.push(searchObj);
          })
        }
      }
    }
    data.queryRequests.queryConditions = queryConditions;
    if (sortBy) {
      let orderObj = {
        orderName: sortBy.attributeName,
        orderType: sortBy._order ? "asc" : "desc"
      };
      data.queryRequests.orderObjects.push(orderObj);
    }
    data.queryRequests.pageNo = pageIndex;
    data.queryRequests.startIndex = (pageIndex - 1) * (pageSize || PAGE_SIZE);
    data.queryRequests.pageSize = pageSize || PAGE_SIZE;
    data.queryRequests.dataType = dataType;
    return data;
  },
  changeToExportRequestData(requestData, fileType) {
    requestData.queryResultAction = QUERY_RESULT_ACTION.DOWNLOAD;
    requestData.outputFormat = fileType;
    requestData.queryRequests.pageSize = null;
    requestData.queryRequests.pageNo = null;
    return requestData;
  }
}
