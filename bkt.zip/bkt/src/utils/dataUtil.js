export const autoCompleteFields = function (product, template, setDefault = false) {
  template.measures.forEach(field => {
    product.attributes[field.name] = product.attributes[field.name] ?
      product.attributes[field.name] : {
        value: setDefault ? (field.list ? (field.defaultValue ? field.defaultValue.split(";") : []) : field.defaultValue) : null
      };
  });
  return product;
}

export const parseBeanToEntityAttributes = function (object, attributeList) {
  attributeList.forEach(attributeName => {
    let value = object[attributeName];
    object[attributeName] = {
      value
    }
  })
  return object;
}

export const parseObjectToValueObject = function (object) {
  for (let key in object) {
    let value = object[key];
    object[key] = {
      value: value
    }
  }
  return object;
}

export const parseEntityToBean = function (entity) {
  var bean = {};
  for (var attr in entity.attributes) {
    bean[attr] = (entity.attributes[attr] || {}).value
  }
  return bean;
}

export const parseEntityTableFieldValueToEntity = function (data) {
  var gridData = [];
  data.forEach((row) => {
    var gridRow = {
      attributes: {}
    };
    for (let key in row) {
      gridRow.attributes[key] = row[key];
    }
    gridData.push(gridRow);
  });
  return gridData;
}

export const parseBeanToEntityTableFieldValue = function (bean) {
  var fieldValue = {};
  for (var attr in bean) {
    fieldValue[attr] = {
      value: bean[attr],
      type: "STRING"
    }
  }
  return fieldValue;
}

export const parseEntityTableFieldValueToBean = function (data) {
  let bean = {};
  data.forEach(cell => {
    bean[cell.id] = cell.value;
  })
  return bean;
}

export const parseBeanToEntity = function (bean, attributeList) {
  var entity = {
    attributes: {}
  };
  if (attributeList) {
    attributeList.forEach(attr => {
      entity.attributes[attr] = {
        value: bean[attr]
      }
    })
  } else {
    for (var attr in bean) {
      entity.attributes[attr] = {
        value: bean[attr]
      }
    }
  }
  return entity;
}

export const convertListToMap = function (list, keyAttr, valueAttr) {
  var obj = {};
  (list || []).forEach(item => {
    if (item[keyAttr]) {
      obj[item[keyAttr]] = valueAttr ? item[valueAttr] : item;
    }
  })
  return obj;
}

export const convertPropertiesToAttributes = function (arr) {
  var newArr = [];
  arr.forEach(item => {
    var template = {
      attributes: {}
    };
    for (var prop in item) {
      template.attributes[prop] = {
        value: item[prop]
      };
    }
    newArr.push(template);
  })
  return newArr;
}

export const getColumns = function (views, groupID, attributes) {
  let view = null,
    columns = [];
  views.forEach(v => {
    if (v.groupID === groupID) {
      view = v;
    }
  });
  if (view) {
    let headers = view.attributesInMainGrid.split(";");
    if (headers.length) {
      headers.forEach(col => {
        if (attributes[col]) {
          attributes[col].columnWidth = 120;
          columns.push(attributes[col]);
        } else {
          let colItem = {
            displayName: col,
            attributeName: col
          };
          columns.push(colItem);
        }
      });
    }
  }
  return columns;
}

export const getViewName = function (navName, mapping, views) {
  if (navName) {
    let viewName = navName.toUpperCase().replace(/ /g, "_");
    if (views[viewName]) return viewName;
    return getViewName(mapping[navName], mapping, views);
  }
  return null;
}
