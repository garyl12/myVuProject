export const merge = function (base, extension, overwrite) {
  for (let attr in extension) {
    if (attr in base) {
      if (typeof base[attr] === 'object' && typeof extension[attr] === 'object') {
        merge(base[attr], extension[attr], overwrite);
      } else {
        if (overwrite) {
          if (typeof extension[attr] === 'object') {
            base[attr] = clone(extension[attr]);
          } else {
            base[attr] = extension[attr];
          }
        }
      }
    } else {
      base[attr] = extension[attr];
    }
  }
  return base;
}

export const guid = function () {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
      v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export const clone = function (value) {
  if (Array.isArray(value)) {
    return value.map(clone)
  } else if (value && typeof value === 'object') {
    var res = {};
    for (var key in value) {
      res[key] = clone(value[key]);
    }
    return res
  } else {
    return value
  }
}

const numberRegexp = /^(\-|\+)?\d+(\.\d+)?$/;
export const isNumber = function (input) {
  return numberRegexp.test(input);
}