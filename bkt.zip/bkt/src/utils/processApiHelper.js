import csvParser from "@/utils/csvParser";
import {
  clone
} from '@/utils'
import {
  PROCESS_REQUEST_PARAM,
  ACTION_TYPES,
  PERSIST_TYPES
} from '@/consts'

const getRequestData = function (entry, template, dataType) {
  let inputData = csvParser.parseToCsvContent(entry, template);
  let data = clone(PROCESS_REQUEST_PARAM);
  data.inputData = inputData;
  if (dataType) {
    data.dataType = dataType
  }
  return data;
}

const getRequestDataMulti = function (entries, template, dataType) {
  let inputData = csvParser.parseToCsvContentMulti(entries, template);
  let data = clone(PROCESS_REQUEST_PARAM);
  data.inputData = inputData;
  if (dataType) {
    data.dataType = dataType
  }
  return data;
}

export default {
  getDeleteRequestData(entry, template, dataType) {
    let data = getRequestData(entry, template, dataType);
    data.actionType = ACTION_TYPES.PERSIST;
    data.persistType = PERSIST_TYPES.DELETE;
    return data;
  },
  getCalculateRequestData(entry, template, dataType) {
    let data = getRequestData(entry, template, dataType);
    data.actionType = ACTION_TYPES.CALCULATION;
    data.persistType = PERSIST_TYPES.UPDATE;
    return data;
  },
  getUpdateRequestData(entry, template, dataType) {
    let data = getRequestData(entry, template, dataType);
    data.actionType = ACTION_TYPES.PERSIST;
    data.persistType = PERSIST_TYPES.UPDATE;
    return data;
  },
  getUpdateRequestDataMulti(entries, template, dataType) {
    let data = getRequestDataMulti(entries, template, dataType);
    data.actionType = ACTION_TYPES.PERSIST;
    data.persistType = PERSIST_TYPES.UPDATE;
    return data;
  }
}
