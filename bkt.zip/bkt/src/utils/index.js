export * from './shared'
export * from './dateUtil'
export * from './dataUtil'
import {
  EDITOR_STATUS
} from "@/consts";
import endpoints from '@/api/endpoints'
import {
  baseUrl
} from '@/api/endpoints'

export const getEditorTitle = function (status) {
  let title = "";
  switch (status) {
    case EDITOR_STATUS.ADDING:
      title = "adding";
      break;
    case EDITOR_STATUS.EDITING:
      title = "editing";
      break;
    case EDITOR_STATUS.CLONING:
      title = "cloning";
      break;
    case EDITOR_STATUS.VIEWING:
      title = "viewing";
      break;
  }
  return title;
}

export const assembleUrl = function (url, paramObject) {
  url += "?";
  if (paramObject) {
    for (let key in paramObject) {
      url += encodeURIComponent(key) + "=" + encodeURIComponent(paramObject[key]) + "&";
    }
  }
  return url.substr(0, url.length - 1);
}

export const assembleDownloadUrl = function (paramObject) {
  let url = baseUrl + endpoints.downloadFile.url;
  return assembleUrl(url, paramObject);
}
