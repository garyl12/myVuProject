const kDividingRegexp = /\d{1,3}(?=(\d{3})+$)/g;

export default {
  divideByThousands(value) {
    if (isNaN(Number(value))) return;
    let separateNum = value.toString().split("."),
      integer = separateNum[0].replace(kDividingRegexp, function (s) {
        return s + ','
      })
    separateNum[0] = integer;
    return separateNum.join(".");
  },
  formatDisplay(value, format, needSymbol = true) {
    let [decimalCount, thousandSymbol, rate] = format.split(";"),
      formatVal = Number(value), rateSymbol = null, rateFactor = null;
    if (isNaN(formatVal)) {
      return;
    }
    if (rate) {
      [rateSymbol, rateFactor] = rate.split("/");
      formatVal = this.transformDecimal(formatVal, Number(rateFactor));
    }
    if (decimalCount) {
      formatVal = formatVal.toFixed(decimalCount);
    }
    if (thousandSymbol === "k") {
      formatVal = this.divideByThousands(formatVal);
    }
    if (rateSymbol && needSymbol) {
      formatVal += rateSymbol;
    }
    return formatVal;
  },
  transformDecimal(number, rate) {
    let result = number;
    let power = Math.log10(rate);
    if (power) {
      let symbol = number < 0 ? "-" : "";
      let original = Math.abs(number).toString();
      if (original.indexOf("e") !== -1) {
        // if original number is using scientific notation
        // base number is before 'e'
        // power number is after 'e' 
        let [b, e] = original.split("e");
        original = b;
        power += Number(e);
      }
      let destination = "";
      let index = original.indexOf('.');
      index = index === -1 ? original.length : index;
      original = original.replace('.', '');
      index += power;
      if (index <= 0) {
        // need to add 0 to the front
        while (index++ < 0) {
          destination += "0";
        }
        destination = "0." + destination + original;
      } else if (index < original.length) {
        destination = original.substr(0, index) + "." + original.substr(index);
      } else {
        // need to add 0 to the end
        while (index-- > original.length) {
          destination += "0"
        }
        destination = original + destination;
      }
      result = Number(symbol + destination);
    }
    return result;
  },
  getNumberRegexp(decimalCount) {
    let regexPattern = "(^[+-]?\\d+$)|(^[+-]?\\d+\\.\\d+$)";
    switch (decimalCount) {
      case -1:
        break;
      case 0:
        regexPattern = "^[+-]?\\d+$";
        break;
      case 1:
        regexPattern = "(^[+-]?\\d+$)|(^[+-]?\\d+\\.\\d$)";
        break;
      default:
        regexPattern =
          "(^[+-]?\\d+$)|(^[+-]?\\d+\\.\\d{1," + decimalCount + "}$)";
        break;
    }
    return new RegExp(regexPattern)
  }
}
